﻿// (C) SocketCoder.Com 
// WCS Packet
// Last Modify: 5/July/2014
using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Security.Cryptography;

namespace MeidaStreaming
{
    public class RoomCodeData
    {
        private string SalatKey = "C12865456tghgkjgSSdd";// You Can Change it to what you want and it should be private, if you Change it from here you should change it also on the WCS client. 
        private char MidChar = '`';

        public string RoomID {get;set;}
        public string UserName { get; set; }
        public string ServerIP  { get; set; } 

        public string GenerateRoomCode(string Server_IP, string Room_ID, string User_Name)
        {
            return base64Encode(Server_IP + MidChar + Room_ID + MidChar + User_Name + MidChar + GenerateSalatCode(Room_ID, User_Name, SalatKey));
        }

        public bool Parse(string RoomCode)
        {
            try
            {
                string RoomCodeString = base64Decode(RoomCode);
                string[] RoomCodeArray = RoomCodeString.Split(MidChar);
                if (RoomCodeArray.Length == 4)
                {
                    ServerIP = RoomCodeArray[0];
                    RoomID = RoomCodeArray[1];
                    UserName = RoomCodeArray[2];
                    string SalatCode = RoomCodeArray[3];

                    if (CheckReceivedSalatCode(RoomID, UserName, SalatKey, SalatCode)) return true;
                    else
                    {
                        RoomID = "";
                        UserName = "";
                        return false;
                    }
                }
                else return false;
            }
            catch { return false; }
        }

        private string GenerateSalatCode(string roomid, string username,string salatkey)
        {
            try
            {
                using (SHA1Managed sha1 = new SHA1Managed())
                {
                    byte[] DataBytes = System.Text.UTF8Encoding.Unicode.GetBytes(roomid + username + salatkey);
                    var hash = sha1.ComputeHash(DataBytes);
                    return Convert.ToBase64String(hash);
                }
            }
            catch { return ""; }
        }
        private bool CheckReceivedSalatCode(string roomid, string username, string salatkey, string GeneratedSalatCode)
        {
            try
            {
             string SalatCode = GenerateSalatCode(roomid, username, salatkey);
             if (SalatCode == GeneratedSalatCode) return true; else return false;
            }
            catch { return false; }
        }

        private string base64Encode(string data)
        {
            try
            {
                byte[] encData_byte = new byte[data.Length];
                encData_byte = System.Text.Encoding.UTF8.GetBytes(data);
                string encodedData = Convert.ToBase64String(encData_byte);
                return encodedData;
            }
            catch
            {
                return "";
            }
        }
        private string base64Decode(string data)
        {
            try
            {
                System.Text.UTF8Encoding encoder = new System.Text.UTF8Encoding();
                System.Text.Decoder utf8Decode = encoder.GetDecoder();

                byte[] todecode_byte = Convert.FromBase64String(data);
                int charCount = utf8Decode.GetCharCount(todecode_byte, 0, todecode_byte.Length);
                char[] decoded_char = new char[charCount];
                utf8Decode.GetChars(todecode_byte, 0, todecode_byte.Length, decoded_char, 0);
                string result = new String(decoded_char);
                return result;
            }
            catch
            {
                return "";
            }
        }
    }


}
