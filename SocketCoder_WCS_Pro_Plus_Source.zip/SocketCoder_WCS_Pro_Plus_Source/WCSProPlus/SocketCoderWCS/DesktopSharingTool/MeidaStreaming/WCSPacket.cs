﻿// (C) SocketCoder.Com 
// WCS Packet
// Last Modify: 5/July/2014
namespace MediaStreaming
{
    using System;
    using System.Collections.Generic;
    using System.Security.Cryptography;

    public class WcsTxtPacket
    {
        public enum TXTPayloadType { TxtChat, Command, Notify };
        public enum Commands { TRoomID, TJoin, TDrop, TCmd, TMsg, TFileSize, TFileExtension, TFileName, CCall, CAccepted, CEnded, CRejected, CBusy, };
        private char MidChar = '`';
        private string PrivateKey = "45H7901aR3"; // You Can Change it to what you want and it should be private, if you Change it from here you should change it also on the server

        public bool IsPublic { get; set; }
        public string PayloadType { get; set; }
        public string To { get; set; }
        public string From { get; set; }
        public string Message { get; set; }
        public string CheckSum { get; set; }
        public string CMD { get; set; }
        public bool SecuirtyPassed { get; set; }

        public byte[]
         Packetizer(string To_User, string From_Me, string TxtMessage, Commands CMD, TXTPayloadType PType, bool Is_Public)
        {
            try
            {
                // WcsTXTPacket = Full Packet Length + Header( *Is Public + PayloadType* + CMDType + To UserName +  From UserName + CheckSum) + TxtMessage   

                string PublicType = "";
                if (Is_Public) PublicType = "1" + PType.ToString(); else PublicType = "0" + PType.ToString();

                string TXTPacket = PublicType + MidChar + CMD.ToString() + MidChar + To_User + MidChar + From_Me + MidChar + GenerateCheckSum(From_Me) + MidChar + TxtMessage;

                byte[] PcketBytes = System.Text.UnicodeEncoding.UTF8.GetBytes(TXTPacket);

                // Set The Packet Size (First 10 bytes)
                string PacketLenString = PcketBytes.Length.ToString();
                string Zero = "";
                while (PacketLenString.Length + Zero.Length < 10)
                {
                    Zero += "0";
                }
                PacketLenString = Zero + PacketLenString;
                byte[] LenBytes = System.Text.UnicodeEncoding.UTF8.GetBytes(PacketLenString);

                return AppendPayloadArray(LenBytes, PcketBytes);
            }
            catch { return new byte[0]; }
        }

        public WcsTxtPacket Parse(byte[] FullBuffer)
        {
            try
            {
                WcsTxtPacket PTD = new WcsTxtPacket();

                // Get Packet Size
                byte[] LengthHeader = new byte[10];
                Buffer.BlockCopy(FullBuffer, 0, LengthHeader, 0, LengthHeader.Length);
                int PacketLen = 0;
                int.TryParse(System.Text.UnicodeEncoding.UTF8.GetString(LengthHeader, 0, LengthHeader.Length), out PacketLen);

                if (PacketLen > 0)
                {
                    byte[] PacketBytes = new byte[PacketLen];
                    Buffer.BlockCopy(FullBuffer, LengthHeader.Length, PacketBytes, 0, PacketLen);

                    // Encoding Bytes to String
                    string PacketTXT = System.Text.UnicodeEncoding.UTF8.GetString(PacketBytes, 0, PacketBytes.Length);

                    // Convert string to array of string
                    string[] PacketArray = PacketTXT.Split(MidChar);

                    if (PacketArray.Length == 6)
                    {
                        string FullPType = PacketArray[0].ToString();
                        string ISPublicString = FullPType.Substring(0, 1);
                        if (ISPublicString == "1") PTD.IsPublic = true; else PTD.IsPublic = false;
                        PTD.PayloadType = FullPType.Substring(1);

                        PTD.CMD = PacketArray[1].ToString();
                        PTD.To = PacketArray[2].ToString();
                        PTD.From = PacketArray[3].ToString();
                        PTD.CheckSum = PacketArray[4].ToString();
                        PTD.Message = PacketArray[5].ToString();
                        PTD.SecuirtyPassed = CheckCheckSum(PTD.From, PTD.CheckSum);

                        if (PTD.SecuirtyPassed)
                            return PTD;

                        else return new WcsTxtPacket();
                    }
                    else return new WcsTxtPacket();
                }
                else return new WcsTxtPacket();
            }
            catch { return new WcsTxtPacket(); }
        }

        string GenerateCheckSum(string StringData)
        {
            try
            {
                using (SHA1Managed sha1 = new SHA1Managed())
                {
                    byte[] DataBytes = System.Text.UTF8Encoding.Unicode.GetBytes(StringData + PrivateKey);
                    var hash = sha1.ComputeHash(DataBytes);
                    return Convert.ToBase64String(hash);
                }
            }
            catch { return "False"; }
        }

        bool CheckCheckSum(string StringData, string CheckSum)
        {
            try
            {
                using (SHA1Managed sha1 = new SHA1Managed())
                {
                    byte[] DataBytes = System.Text.UTF8Encoding.Unicode.GetBytes(StringData + PrivateKey);
                    var hash = sha1.ComputeHash(DataBytes);
                    string GeneratedCheckSum = Convert.ToBase64String(hash);
                    if (GeneratedCheckSum == CheckSum) return true; else return false;
                }
            }
            catch { return false; }
        }

        private Byte[] AppendPayloadArray(Byte[] FirstBuffer, Byte[] SecondBuffer)
        {
            try
            {
                Byte[] FinalArr = new Byte[FirstBuffer.Length + SecondBuffer.Length];
                Buffer.BlockCopy(FirstBuffer, 0, FinalArr, 0, FirstBuffer.Length);
                Buffer.BlockCopy(SecondBuffer, 0, FinalArr, FirstBuffer.Length, SecondBuffer.Length);
                return FinalArr;
            }
            catch { return new Byte[0]; }
        }

        public byte[] GenerateKeepAlivePacket()
        {
            return System.Text.UnicodeEncoding.Unicode.GetBytes("#");
        }

    }

    public class WcsBinaryPacket
    {
        public enum BinaryPayloadType { Voice, Video, Drawing, DesktopShare, File };
        private string PrivateKey = "C56A901aB3"; // You Can Change it to what you want and it should be private, if you Change it from here you should change it also on the server
        private char MidChar = '`';

        public string To { get; set; }
        public string From { get; set; }
        public byte[] DataBuffer { get; set; }

        public int AudioFormatBits { get; set; }
        public int AudioFormatSamples { get; set; }
        public int AudioFormatChannels { get; set; }

        public string CheckSum { get; set; }
        public string PayloadType { get; set; }
        public bool IsPublic { get; set; }

        public bool SecuirtyPassed { get; set; }

        public byte[]
        Packetizer(string To_User, string From_User, byte[] Data_Buffer, int AudioFormat_Bits, int AudioFormat_Samples, int AudioFormat_Channels, BinaryPayloadType Payload_Type, bool Is_Public)
        {
            try
            {
                // WcsBinaryPacket = Header Len (10) + Header(*Is Public + PayloadType* + AudioFormat (Bits+Samples+Channels) + To UserName +  From UserName +  Data Buffer Size + CheckSum ) + Data Buffer   

                // Packet Header
                string PublicType = "";
                if (Is_Public) PublicType = "1" + Payload_Type.ToString(); else PublicType = "0" + Payload_Type.ToString();

                string Header = PublicType + MidChar + AudioFormat_Bits.ToString() + MidChar + AudioFormat_Samples.ToString() + MidChar + AudioFormat_Channels.ToString() + MidChar + To_User + MidChar + From_User + MidChar + Data_Buffer.Length + MidChar + GenerateCheckSum(From_User);

                byte[] PcketHeaderBytes = System.Text.UnicodeEncoding.UTF8.GetBytes(Header);

                // Set The Packet Size (First 10 bytes)
                string PacketLenString = PcketHeaderBytes.Length.ToString();
                string Zero = "";
                while (PacketLenString.Length + Zero.Length < 10)
                {
                    Zero += "0";
                }
                PacketLenString = Zero + PacketLenString;
                byte[] LenBytes = System.Text.UnicodeEncoding.UTF8.GetBytes(PacketLenString);

                byte[] FullHeaderBytes = AppendPayloadArray(LenBytes, PcketHeaderBytes);

                return AppendPayloadArray(FullHeaderBytes, Data_Buffer);

            }
            catch { return new byte[0]; }
        }

        public WcsBinaryPacket Parse(byte[] FullBuffer)
        {
            try
            {
                //// Get The Header Size
                byte[] LengthHeader = new byte[10];
                Buffer.BlockCopy(FullBuffer, 0, LengthHeader, 0, LengthHeader.Length);

                int HeaderLen = 0;
                int.TryParse(System.Text.UnicodeEncoding.UTF8.GetString(LengthHeader, 0, LengthHeader.Length), out HeaderLen);

                byte[] PacketHeaderBytes = new byte[HeaderLen];

                if (HeaderLen > 10)
                    Buffer.BlockCopy(FullBuffer, 10, PacketHeaderBytes, 0, HeaderLen);
                else return new WcsBinaryPacket();

                // Encoding Bytes to String
                string PacketHeader = System.Text.UnicodeEncoding.UTF8.GetString(PacketHeaderBytes, 0, PacketHeaderBytes.Length);

                // Convert string to array of string
                string[] PacketArray = PacketHeader.Split(MidChar);

                if (PacketArray.Length == 8)
                {
                    WcsBinaryPacket PBD = new WcsBinaryPacket();
                    string FullPType = PacketArray[0].ToString();
                    string ISPublicString = FullPType.Substring(0, 1);
                    if (ISPublicString == "1") PBD.IsPublic = true; else PBD.IsPublic = false;
                    PBD.PayloadType = FullPType.Substring(1);

                    // Audio Format String
                    PBD.AudioFormatBits = int.Parse(PacketArray[1]);
                    PBD.AudioFormatSamples = int.Parse(PacketArray[2]);
                    PBD.AudioFormatChannels = int.Parse(PacketArray[3]);

                    PBD.To = PacketArray[4].ToString();
                    PBD.From = PacketArray[5].ToString();

                    int DataBufferLen = 0;
                    int.TryParse(PacketArray[6].ToString(), out DataBufferLen);

                    if (DataBufferLen > 0)
                        PBD.DataBuffer = new byte[DataBufferLen];
                    else return new WcsBinaryPacket();

                    if (FullBuffer.Length >= (HeaderLen + DataBufferLen + 10))
                        Buffer.BlockCopy(FullBuffer, HeaderLen + 10, PBD.DataBuffer, 0, DataBufferLen);
                    else return new WcsBinaryPacket();

                    PBD.CheckSum = PacketArray[7].ToString();
                    PBD.SecuirtyPassed = CheckCheckSum(PBD.From, PBD.CheckSum);

                    if (PBD.SecuirtyPassed)
                        return PBD;
                    else return new WcsBinaryPacket();
                }
                else return new WcsBinaryPacket();

            }
            catch { return new WcsBinaryPacket(); }
        }

        string GenerateCheckSum(string StringData)
        {
            try
            {
                using (SHA1Managed sha1 = new SHA1Managed())
                {
                    byte[] DataBytes = System.Text.UTF8Encoding.Unicode.GetBytes(StringData + PrivateKey);
                    var hash = sha1.ComputeHash(DataBytes);
                    return Convert.ToBase64String(hash);
                }
            }
            catch { return "False"; }
        }

        bool CheckCheckSum(string StringData, string CheckSum)
        {
            try
            {
                using (SHA1Managed sha1 = new SHA1Managed())
                {
                    byte[] DataBytes = System.Text.UTF8Encoding.Unicode.GetBytes(StringData + PrivateKey);
                    var hash = sha1.ComputeHash(DataBytes);
                    string GeneratedCheckSum = Convert.ToBase64String(hash);
                    if (GeneratedCheckSum == CheckSum) return true; else return false;
                }
            }
            catch { return false; }
        }
        private Byte[] AppendPayloadArray(Byte[] FirstBuffer, Byte[] SecondBuffer)
        {
            try
            {
                Byte[] FinalArr = new Byte[FirstBuffer.Length + SecondBuffer.Length];
                Buffer.BlockCopy(FirstBuffer, 0, FinalArr, 0, FirstBuffer.Length);
                Buffer.BlockCopy(SecondBuffer, 0, FinalArr, FirstBuffer.Length, SecondBuffer.Length);
                return FinalArr;
            }
            catch { return new Byte[0]; }
        }
    }
}