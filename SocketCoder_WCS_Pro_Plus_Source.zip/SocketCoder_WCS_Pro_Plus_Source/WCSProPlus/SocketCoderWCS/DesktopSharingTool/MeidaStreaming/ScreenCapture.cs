﻿using System;
using System.Runtime.InteropServices;
using System.Windows.Media.Imaging;
using ImageTools;
using System.IO;
using System.Windows;
using MediaStreaming;

namespace DesktopSharingTool
{
    public static class ScreenCapture
    {
       private static IntPtr hBitmap;
       private static IntPtr ComphBitmap;

       public static Size size = new Size
        {
            Width = User32.GetSystemMetrics(Gdi32.SM_CXSCREEN),
            Height = User32.GetSystemMetrics(Gdi32.SM_CYSCREEN)
        };

        public static WriteableBitmap GetDesktopImage()
        {
            WriteableBitmap bmap = null;

            // initialize unmanager pointers
            IntPtr hDC = IntPtr.Zero,
                   hMemDC = IntPtr.Zero,
                   desktop = IntPtr.Zero;

            try
            {
                // get a reference to desktop
                desktop = User32.GetDesktopWindow();
                // get an handle to Device Context
                hDC = User32.GetDC(desktop);
                // create a new Device Context in memory
                hMemDC = Gdi32.CreateCompatibleDC(hDC);

                // create a bitmap compatible with desktop
                if (hBitmap == IntPtr.Zero)
                 hBitmap = Gdi32.CreateCompatibleBitmap(hDC, size.Width, size.Height);

                if (hBitmap != IntPtr.Zero)
                {
                    // select memory Device Context into the new bitmap
                    IntPtr hOld = (IntPtr)Gdi32.SelectObject(hMemDC, hBitmap);

                    // copy the desktop to the memory handle
                    Gdi32.BitBlt(hMemDC, 0, 0, size.Width, size.Height, hDC, 0, 0, (int)TernaryRasterOperations.SRCCOPY);

                    // select the memory Device Context into the bitmap
                    Gdi32.SelectObject(hMemDC, hOld);

                    // initialize a bitmap info
                    BitmapInfo bi = new BitmapInfo
                    {
                        biSize = Marshal.SizeOf(typeof(BitmapInfo)),
                        biWidth = size.Width,
                        biHeight = size.Height,
                        biPlanes = 1,
                        biBitCount = 32,
                        biCompression = 0,
                        biSizeImage = 0,
                        biXPelsPerMeter = 0,
                        biYPelsPerMeter = 0,
                        biClrUsed = 0,
                        biClrImportant = 0
                    };

                    // calculate byte size of the area
                    int dwBmpSize = ((size.Width * bi.biBitCount + 31) / 32) * 4 * size.Height;
                    byte[] data = new byte[dwBmpSize];

                    // initialize a WriteableBitmap to output the result
                    bmap = new WriteableBitmap(size.Width, size.Height);

                    // copy bitmap to byte array
                    Gdi32.GetDIBits(hMemDC, hBitmap, 0, (uint)size.Height, data, ref bi, 0);

                    // compy byte array to WriteableBitmap
                    for (int i = 0; i < data.Length; i += 4)
                    {
                        int y = size.Height - ((i / 4) / size.Width) - 1;
                        int x = (i / 4) % size.Width;
                        int pixel = data[i + 0] | (data[i + 1] << 8) | (data[i + 2] << 16) | (data[i + 3] << 24);
                        bmap.Pixels[y * size.Width + x] = pixel;
                    }
                }
            }
            finally
            {
                // release unmanaged resources
                if (hMemDC != IntPtr.Zero)
                    Gdi32.DeleteDC(hMemDC);
                if (hDC != IntPtr.Zero)
                    User32.ReleaseDC(desktop, hDC);
            }

            // return bitmap in half size
            int NewW = (bmap.PixelWidth / 2);
            int NewH = (bmap.PixelHeight / 2);
            return JPEGEcoderDecoder.Resize(bmap.ToImage(),NewW ,NewH).ToBitmap();
        }

        public static ExtendedImage GetDesktopImageToCompare()
        {
            ExtendedImage bmap = null;
            // initialize unmanager pointers
            IntPtr hDC = IntPtr.Zero,
                   hMemDC = IntPtr.Zero,
                   desktop = IntPtr.Zero;
            try
            {
                // get a reference to desktop
                desktop = User32.GetDesktopWindow();
                // get an handle to Device Context
                hDC = User32.GetDC(desktop);
                // create a new Device Context in memory
                hMemDC = Gdi32.CreateCompatibleDC(hDC);

                // create a bitmap compatible with desktop
                if (ComphBitmap == IntPtr.Zero)
                  ComphBitmap = Gdi32.CreateCompatibleBitmap(hDC, size.Width, size.Height);

                if (ComphBitmap != IntPtr.Zero)
                {
                    // select memory Device Context into the new bitmap
                    IntPtr hOld = (IntPtr)Gdi32.SelectObject(hMemDC, ComphBitmap);

                    // copy the desktop to the memory handle
                    Gdi32.BitBlt(hMemDC, 0, 0, size.Width, size.Height, hDC, 0, 0, (int)TernaryRasterOperations.SRCCOPY);

                    // select the memory Device Context into the bitmap
                    Gdi32.SelectObject(hMemDC, hOld);

                    // initialize a bitmap info
                    BitmapInfo bi = new BitmapInfo
                    {
                        biSize = Marshal.SizeOf(typeof(BitmapInfo)),
                        biWidth = size.Width,
                        biHeight = size.Height,
                        biPlanes = 1,
                        biBitCount = 32,
                        biCompression = 0,
                        biSizeImage = 0,
                        biXPelsPerMeter = 0,
                        biYPelsPerMeter = 0,
                        biClrUsed = 0,
                        biClrImportant = 0
                    };

                    // calculate byte size of the area
                    int dwBmpSize = ((size.Width * bi.biBitCount + 31) / 32) * 4 * size.Height;
                    byte[] data = new byte[dwBmpSize];

                    // initialize a WriteableBitmap to output the result
                    bmap = new ExtendedImage(size.Width, size.Height);

                    // copy bitmap to byte array
                    Gdi32.GetDIBits(hMemDC, ComphBitmap, 0, (uint)size.Height, data, ref bi, 0);
                    bmap.SetPixels(size.Width, size.Height, data);
                }
            }
            finally
            {
                // release unmanaged resources
                if (hMemDC != IntPtr.Zero)
                    Gdi32.DeleteDC(hMemDC);
                if (hDC != IntPtr.Zero)
                    User32.ReleaseDC(desktop, hDC);
            }

            // return Resized bitmap
            int NewW = (bmap.PixelWidth / 4);
            int NewH = (bmap.PixelHeight / 4);
            return JPEGEcoderDecoder.Resize(ExtendedImage.Transform(bmap, RotationType.None, FlippingType.FlipX), NewW, NewH); 
        }

    }
}
