﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MediaStreaming;
using System.Net.Sockets;
using MeidaStreaming;
using System.IO;
using System.Windows.Media.Effects;
using System.Windows.Threading;
using System.ComponentModel;
using ImageTools;

namespace DesktopSharingTool
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
            DesktopPublisherSocketEventArg.Completed += OnDesktopPublisherCompleted;

            if (App.Current.IsRunningOutOfBrowser)
            {
                PleaseNote.Visibility = System.Windows.Visibility.Collapsed;
                Application.Current.MainWindow.TopMost = true;
                ConnectBTN.IsEnabled = true;
            }
            else
            {
                ConnectBTN.IsEnabled = false;
            }
        }

        // Default Image Quality
        private int Quality = 40;

        // Socket and Publisher Encoder
        private Socket DesktopPublisherSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        private SocketAsyncEventArgs DesktopPublisherSocketEventArg = new SocketAsyncEventArgs();
        private WcsBinaryPacket BinaryPacket = new WcsBinaryPacket();
        private delegate void BytesDelegate(byte[] buffer);
        private delegate void SendRoomIDdelegate();
        private delegate void Enabledelegate(bool value);
        private delegate void ShowMessagedelegate(string MSG);
        private RoomCodeData RoomCode = new RoomCodeData();
        private IPAddress addr = null;
        private Thread th;
        private bool stop = true;

        #region Desktop Sharing Socket Methods
        private void ConnectBTN_Click(object sender, RoutedEventArgs e)
        {
            if (App.Current.IsRunningOutOfBrowser)
            {
                if (RoomCode.Parse(RoomIdTXT.Text))
                {
                    Connect();
                }
                else ShowMessageBox("Wrong Room Code, Please Copy/Paste the Correct Room Code from the WCS System!");
            }
            else ShowMessageBox("This Tool Can be only running on windows desktop mode, Please right click then click on (Install SocketCoder Desktop Sharing Tool) to install it on your desktop");
        }

        void Connect()
        {
            if (DesktopPublisherSocket != null)
            {
                if (!DesktopPublisherSocket.Connected)
                {
                    try
                    {
                        addr = IPAddress.Parse(RoomCode.ServerIP);
                    }
                    catch { ShowMessageBox("Please Enter a Correct IP Address!"); return; }

                    // Desktop Sharing Socket
                    DesktopPublisherSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                    DesktopPublisherSocket.NoDelay = true;

                    SocketAsyncEventArgs DesktopsocketEventArg = new SocketAsyncEventArgs()
                    {
                        RemoteEndPoint = new IPEndPoint(addr, 4532)
                    };
                    DesktopsocketEventArg.Completed += OnDesktopConnectCompleted;
                    DesktopPublisherSocket.ConnectAsync(DesktopsocketEventArg);
                }
            }
        }
        void OnDesktopConnectCompleted(object sender, SocketAsyncEventArgs e)
        {
            if (e.SocketError == SocketError.Success)
            {
                this.Dispatcher.BeginInvoke(new SendRoomIDdelegate(SendDrawing_RoomID));
                this.Dispatcher.BeginInvoke(new Enabledelegate(EnableDrawingControl), true);
            }
            else
            {
                this.Dispatcher.BeginInvoke(new ShowMessagedelegate(ShowMessageBox), "Unable to Connect With The Desktop Sharing Service!");
                this.Dispatcher.BeginInvoke(new Enabledelegate(EnableDrawingControl), false);
            }
        }
        private void EnableDrawingControl(bool value)
        {
            ShareBTN.IsEnabled = StartBTN.IsEnabled = value;
            ConnectBTN.IsEnabled = RoomIdTXT.IsEnabled = !value;
            
            if (value)
            {
                ConnectBTN.Content = "Joined";
                sendingSt.Foreground = new SolidColorBrush(Colors.Green);
                sendingSt.Content = "Connected";
            }
            else
            {
                ConnectBTN.Content = "Join";
                sendingSt.Foreground = new SolidColorBrush(Colors.Red);
                sendingSt.Content = "Disconnected";
            }
        }
        void PublishIt(WriteableBitmap img)
        {
            try
            {
                byte[] buffer = JPEGEcoderDecoder.JpegEncode(img, Quality, true);
                byte[] PayloadedBytes = PayloadBinaryData(buffer, WcsBinaryPacket.BinaryPayloadType.DesktopShare, RoomCode.RoomID, true);
                SendDesktopBytes(PayloadedBytes);
            }
            catch { }
        }
        void SendDesktopBytes(byte[] buffer)
        {
            if (DesktopPublisherSocket.Connected)
                try
                {
                    DesktopPublisherSocketEventArg.SetBuffer(buffer, 0, buffer.Length);
                    DesktopPublisherSocket.SendAsync(DesktopPublisherSocketEventArg);
                }
                catch { }
            else Connect();
        }
        void OnDesktopPublisherCompleted(object sender, SocketAsyncEventArgs e)
        {
            try
            {

            }
            catch { }
        }
        void OnDesktopRoomIDSendCompleted(object sender, SocketAsyncEventArgs e)
        {

        }
        void SendDrawing_RoomID()
        {
            try
            {
                WcsTxtPacket TXT = new WcsTxtPacket();
                byte[] RoomIDBytes = TXT.Packetizer(RoomCode.RoomID, RoomCode.UserName, RoomCode.RoomID, WcsTxtPacket.Commands.TRoomID, WcsTxtPacket.TXTPayloadType.Command, false);
                SendDesktopBytes(RoomIDBytes);
            }
            catch { }
        }
        byte[] PayloadBinaryData(byte[] DataBuffer, WcsBinaryPacket.BinaryPayloadType PayloadType, string SendTo, bool IsPublic)
        {
            try
            {
                return BinaryPacket.Packetizer(SendTo, RoomCode.UserName, DataBuffer, 0,
                    0, 0, PayloadType, IsPublic);
            }
            catch { return new byte[0]; }
        }
        #endregion Desktop Sharing Socket Methods

        private void ShareIt_Click(object sender, RoutedEventArgs e)
        {
            if (App.Current.IsRunningOutOfBrowser)
            {
                Application.Current.MainWindow.Hide();
                Delay(500,
                      () =>
                      {
                          try
                          {
                              WriteableBitmap source = ScreenCapture.GetDesktopImage();

                              if (source != null)
                              {
                                  screenshot.Source = source;
                                  PublishIt(source);
                                  sendingSt.Foreground = new SolidColorBrush(Colors.Green);
                                  sendingSt.Content = "Published";
                              }
                              else
                                  ShowMessageBox("You dont have the right on your computer to take a snapshot!");
                          }
                          catch (Exception ex)
                          {
                              MessageBox.Show(ex.Message);
                          }
                          finally
                          {
                              Application.Current.MainWindow.Show();
                              Application.Current.MainWindow.Activate();
                          }
                      });
            }
        }

        void StartAutoComparing(bool value)
        {
            try
            {
                if (value)
                {
                    stop = false;
                    th = new Thread(new ThreadStart(FindAndSend));
                    th.IsBackground = true;
                    th.Start();
                    StartBTN.IsEnabled = false;
                    StopBtn.IsEnabled = true;
                }
                else
                {
                    stop = true;
                    th.Abort();
                    StartBTN.IsEnabled = true;
                    StopBtn.IsEnabled = false;
                    sendingSt.Foreground = new SolidColorBrush(Colors.Red);
                    sendingSt.Content = "Stopped";
                }
            }
            catch { }
        }
        public void AutoComparing_Tick(object sender, EventArgs e)
        {
            FindAndSend();
        }
        private void StopBtn_Click(object sender, RoutedEventArgs e)
        {
            StartAutoComparing(false);
        }

        private void StartBTN_Click(object sender, RoutedEventArgs e)
        {
            StartAutoComparing(true);
        }

        void FindAndSend()
        {

            ExtendedImage FirstImage = null;
            ExtendedImage LastSentImage = null;
            int Counter  = 1;

            while (!stop)
                try
                {
                    if (LastSentImage != null)
                    {
                        Counter += CompareIt(ScreenCapture.GetDesktopImageToCompare(), LastSentImage);
                    }

                    FirstImage = ScreenCapture.GetDesktopImageToCompare();
                    Thread.Sleep(200);
                    Counter += CompareIt(FirstImage, ScreenCapture.GetDesktopImageToCompare());

                    if (Counter>=1)
                    {
                        Deployment.Current.Dispatcher.BeginInvoke(delegate()
                        {
                            WriteableBitmap sent = ScreenCapture.GetDesktopImage();
                            screenshot.Source = sent;
                            sendingSt.Foreground = new SolidColorBrush(Colors.Green);
                            sendingSt.Content = "Sending...";
                            PublishIt(sent);
                        });

                        Counter = 0;
                        LastSentImage = FirstImage;
                        Thread.Sleep(1500);
                    }
                }
                catch { }
        }

        public int CompareIt(ExtendedImage OrginalImage, ExtendedImage SecoundImage)
        {                
            int Counter = 0;

            try
            {
                int size_H = OrginalImage.PixelHeight;
                int size_W = SecoundImage.PixelWidth;

                float total = size_H * size_W;

                for (int x = 0; x != size_W; x++)
                {

                    for (int y = 0; y != size_H; y++)
                    {
                        // Read Bitmap Pixel Color Then Compare it with the Second image pixel
                        int OrginalImageColor = OrginalImage.Pixels[(int)(y * OrginalImage.PixelWidth + x)];
                        int SecoundImageColor = SecoundImage.Pixels[(int)(y * SecoundImage.PixelWidth + x)];

                        // To Get The Pixel Color:
                        // Color pixel_image1 = Color.FromArgb((byte)(OrginalImageColor >> 24), (byte)(OrginalImageColor >> 16), (byte)(OrginalImageColor >> 8), (byte)(OrginalImageColor));
                        // Color pixel_image2 = Color.FromArgb((byte)(SecoundImageColor >> 24), (byte)(SecoundImageColor >> 16), (byte)(SecoundImageColor >> 8), (byte)(SecoundImageColor));

                        if (OrginalImageColor != SecoundImageColor)
                        {
                            Counter++;
                        }
                    }
                    
                }

            }
            catch { return 1; }

            Deployment.Current.Dispatcher.BeginInvoke(delegate()
            {
               // screenshot.Source = SecoundImage.ToBitmap();
                sendingSt.Foreground = new SolidColorBrush(Colors.Blue);
                sendingSt.Content = "Comparing ..";
            });

            return Counter;
        }

        private void QualitySlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (QualitySlider != null)
            {
                Quality = (int)QualitySlider.Value;
                SelectedQuality.Content = Quality.ToString();
            }
        }

        private void Delay(int timeout, Action action)
        {
            Task task = new Task(
                () =>
                {
                    Thread.Sleep(timeout);

                    Deployment.Current.Dispatcher.BeginInvoke(action);
                });

            task.Start();
        }

        private void ShowMessageBox(string MSG)
        {
            MessageBox.Show(MSG, "WCS Desktop Sharing Tool", MessageBoxButton.OK);
        }

    }
}
