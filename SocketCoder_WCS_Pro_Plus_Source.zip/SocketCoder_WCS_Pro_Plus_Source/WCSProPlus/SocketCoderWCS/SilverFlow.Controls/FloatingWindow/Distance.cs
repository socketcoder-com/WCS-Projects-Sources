﻿namespace SilverFlow.Controls
{
    /// <summary>
    /// Defines displacement used for correction of window position or size.
    /// </summary>
    public class Distance
    {
        /// <summary>
        /// Gets or sets displacement by X coordinate.
        /// </summary>
        /// <value>Displacement by X coordinate.</value>
        public double X { get; set; }

        /// <summary>
        /// Gets or sets displacement by Y coordinate.
        /// </summary>
        /// <value>Displacement by Y coordinate.</value>
        public double Y { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="Distance"/> class.
        /// </summary>
        public Distance()
        {
            X = double.NaN;
            Y = double.NaN;
        }

        /// <summary>
        /// Gets the smaller of two distances.
        /// </summary>
        /// <param name="first">First distance.</param>
        /// <param name="second">Second distance.</param>
        /// <returns>Smallest distance.</returns>
        public static Distance Min(Distance first, Distance second)
        {
            Distance distance = new Distance
            {
                X = MathExtensions.AbsMin(first.X, second.X),
                Y = MathExtensions.AbsMin(first.Y, second.Y)
            };

            return distance;
        }
    }
}
