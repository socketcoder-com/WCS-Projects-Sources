﻿// (C) SocketCoder.Com 
// WCS Packet
// Last Modify: 31/5/2014
namespace MediaStreaming
{
    using System;
    using System.Net;
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Documents;
    using System.Windows.Ink;
    using System.Windows.Input;
    using System.Windows.Media;
    using System.Windows.Media.Animation;
    using System.Windows.Shapes;
    using System.IO;

        public class MemoryAudioSink : AudioSink
        {
            public event EventHandler OnBufferFulfill;

            AudioFormat _format;
            SpeexEncoderDecoder _speexencoder = new SpeexEncoderDecoder();
            public bool IsVoiceSendingStarted = false;

            private int _VoiceQuality = 5;
            public int VoiceQuality
            {
                set
                {
                    _VoiceQuality = this._speexencoder.VoiceQuality = value;
                }
                get
                {
                    return _VoiceQuality;
                }
            }

            protected override void OnCaptureStarted()
            {
                _format = this.CaptureSource.AudioCaptureDevice.DesiredFormat;
            }

            protected override void OnCaptureStopped() { }

            protected override void OnFormatChange(AudioFormat Format) { }

            protected override void OnSamples(long sampleTime, long sampleDuration, byte[] sampleData)
            {
                if (IsVoiceSendingStarted & OnBufferFulfill != null & (sampleData.Length >= _format.SamplesPerSecond * _format.Channels))
                {
                    byte[] EncodedBuffer = _speexencoder.Encode(sampleData);
                    OnBufferFulfill(EncodedBuffer, null);
                }
            }
    }
}