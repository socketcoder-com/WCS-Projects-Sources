﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace SocketCoderWCS.Views.Login
{
    public partial class ConnectionLost : ChildWindow
    {
        public event EventHandler TryAgainClicked;
        private DispatcherTimer AutoConTimer = new DispatcherTimer();
        private int Seconds = 10;

        public ConnectionLost()
        {
            InitializeComponent();

            AutoConTimer.Interval = new TimeSpan(0, 0, 0, 1, 0);
            AutoConTimer.Tick += new EventHandler(Each_Tick);
        }

        public void StartTimer()
        {
            Seconds = 10;
            TimerLB.Content = Seconds.ToString();
            AutoConTimer.Start();
        }

        public void StopTimer()
        {
            AutoConTimer.Stop();
            Seconds = 10;
        }

        public void Each_Tick(object sender, EventArgs e)
        {
            try
            {
                TimerLB.Content = Seconds.ToString();
                Seconds--;

                if (Seconds <= 0)
                {
                    OKButton_Click(null, null);
                }
            }
            catch { }
        }

        private void OKButton_Click(object sender, RoutedEventArgs e)
        {
            StopTimer();
            this.DialogResult = true;
            TryAgainClicked(sender, e);
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to stop the auto connect mode?", "Disable the auto connect mode", MessageBoxButton.OKCancel) == MessageBoxResult.OK)
            {
                StopTimer();
                this.DialogResult = false;
                TryAgainClicked(sender, e);
            }
        }
    }
}

