﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace SocketCoderWCS.Views.Login
{
    public partial class Nickname : ChildWindow
    {
        public Nickname()
        {
            InitializeComponent();
        }
        public string UserName = "";

        private void OKButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (UserName_TXT.Text != "")
                {
                    string RandID = DateTime.Now.ToFileTime().ToString();
                    UserName = UserName_TXT.Text;
                    if (UserName.Length > 16) UserName = UserName.Substring(0, 16);
                    this.DialogResult = true;
                }
            }
            catch { }
        }

        private void ChildWindow_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
        }

    }
}

