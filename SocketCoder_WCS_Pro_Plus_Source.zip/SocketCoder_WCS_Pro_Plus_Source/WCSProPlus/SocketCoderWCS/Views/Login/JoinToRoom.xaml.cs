﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Browser;
using System.Collections.ObjectModel;
using SocketCoderWCS.WCS_Proxy;
using MediaStreaming;

namespace SocketCoderWCS.Views.Login
{
    public partial class Login : ChildWindow
    {
        public Login()
        {
            InitializeComponent();
            NickUserName.Closed += new EventHandler(NickUserName_Closed);
        }

        private string NormalUserRole = "Registered Users";
        private string AdminRole = "IsPresenter";
        private string WebServiceVersion = "4.0.0.0";

        public string UserName = "";
        public string RoomID = "";
        public string MyRole = "";


        LoginUI.LoginForm Loginfrm = new LoginUI.LoginForm();
        LoginUI.LoginRegistrationWindow regWindow = new LoginUI.LoginRegistrationWindow();

        public Nickname NickUserName = new Nickname();

        public bool LgoinIsRequired = true;

        //Global User Permissions
        public GlobalUserPermissions AllowUsing = new GlobalUserPermissions();
        public RoomContants contants = new RoomContants();

        public string QueryStringID = "";
        public bool IsAdmin;

        public ObservableCollection<RoomInRole> RoomContants = new ObservableCollection<RoomInRole>();
        public string AvatarID = "00000";

        public void ShowCPButton()
        {
            try
            {
                if (WebContext.Current.User.IsInRole(AdminRole) & WebContext.Current.User.IsAuthenticated)
                    CPBTN.Visibility = System.Windows.Visibility.Visible;
                else CPBTN.Visibility = System.Windows.Visibility.Collapsed;
            }
            catch { }
        }

        public void ShowErrorMessageBox(string msg)
        {
            try
            {
                ErrorMSG.Foreground = new SolidColorBrush(Colors.Red);
                ErrorMSG.Content = msg;
            }
            catch { }
        }

        private void ShowMessageBox(string MSG)
        {
            ErrorMSG.Foreground = new SolidColorBrush(Colors.Blue);
            ErrorMSG.Content = MSG;
        }

        void GetRoomContants()
        {
            if (RoomID !="")
            try
            {
                ShowMessageBox("Loading please wait...");
                WCS_WebService.WCS_Main_ServiceSoapClient RoomService = new WCS_WebService.WCS_Main_ServiceSoapClient();
                RoomService.GetRoomContentsCompleted += new EventHandler<WCS_WebService.GetRoomContentsCompletedEventArgs>(GetRoomContentsCompleted);
                RoomService.GetRoomContentsAsync(RoomID);
            }
            catch { }
        }

        public void QueryStringLogin(string QSID)
        {
                try
                {
                    WCS_WebService.WCS_Main_ServiceSoapClient RoomService = new WCS_WebService.WCS_Main_ServiceSoapClient();
                    RoomService.GetRoomTitleByRoomIDCompleted += new EventHandler<WCS_WebService.GetRoomTitleByRoomIDCompletedEventArgs>(GetRoomTitleByRoomIDCompleted);
                    RoomService.GetRoomTitleByRoomIDAsync(QSID);
                }
                catch { }
        }
        public void GetAvailableRoomsForGuestUsers()
        {
            try
            {
                ShowMessageBox("Loading please wait...");
                WCS_WebService.WCS_Main_ServiceSoapClient RoomService = new WCS_WebService.WCS_Main_ServiceSoapClient();
                RoomService.Get_AllRoomsNamesCompleted += new EventHandler<WCS_WebService.Get_AllRoomsNamesCompletedEventArgs>(RoomService_Get_AllRoomsNamesCompleted);
                RoomService.Get_AllRoomsNamesAsync();
            }
            catch { }
        }

        void RoomService_Get_AllRoomsNamesCompleted(object sender, WCS_WebService.Get_AllRoomsNamesCompletedEventArgs e)
        {
            try
            {
                // Fill The Available Rooms
                WCS_WebService.ArrayOfAnyType arr = e.Result;
                foreach (string RoomeName in arr)
                {
                    if (!RoomsCombo.Items.Contains(RoomeName))
                        RoomsCombo.Items.Add(RoomeName);
                }
                RoomsCombo.IsEnabled = true;
                ShowMessageBox("");
            }
            catch { }
        }
        public void NormalLogin()
        {
                try
                {
                    ShowMessageBox("Loading please wait...");

                    WCS_WebService.WCS_Main_ServiceSoapClient RoomService = new WCS_WebService.WCS_Main_ServiceSoapClient();
                    UserName = WebContext.Current.User.Name;
                    UserName = UserName.Replace('`', '*');
                    UserName = UserName.Replace('#', '*');
                    if (UserName.Length > 16) UserName = UserName.Substring(0, 16);

                    // Check The available Rooms for the User Role 
                    foreach (string Role in WebContext.Current.User.Roles)
                    {
                        RoomService.Get_Rooms_ListCompleted += new EventHandler<WCS_WebService.Get_Rooms_ListCompletedEventArgs>(GetRoomsCompleted);
                        RoomService.Get_Rooms_ListAsync(Role);
                        MyRole = Role;
                    }

                }
                catch { }
        }
        void GetRoomTitleByRoomIDCompleted(object sender, WCS_WebService.GetRoomTitleByRoomIDCompletedEventArgs e)
        {
            try
            {
                if (e.Result != null)
                {
                    RoomID = e.Result;
                    RoomID = RoomID.Replace('`', '*');
                    RoomID = RoomID.Replace('#', '*');
                    RoomsCombo.Items.Add(RoomID);
                    RoomsCombo.SelectedValue = RoomID;
                    RoomsCombo.IsEnabled = false;
                }
            }
            catch { }
        }
        void GetRoomContentsCompleted(object sender, WCS_WebService.GetRoomContentsCompletedEventArgs e)
        {
            try
            {
                WCS_WebService.ArrayOfAnyType arr = e.Result;

                contants.ShowPrivateChat = bool.Parse(arr[0].ToString());
                contants.ShowText = bool.Parse(arr[1].ToString());
                contants.ShowVideo = bool.Parse(arr[2].ToString());
                contants.ShowVoice = bool.Parse(arr[3].ToString());
                contants.ShowPresentation = bool.Parse(arr[4].ToString());
                contants.ShowWhiteboard = bool.Parse(arr[5].ToString());
                contants.ShowFilesSharing = bool.Parse(arr[6].ToString());
                contants.ShowUsersList = bool.Parse(arr[7].ToString());
                LgoinIsRequired = bool.Parse(arr[8].ToString());

                if (LgoinIsRequired & RoomID != "" & !WebContext.Current.User.IsAuthenticated)
                {
                    Loginfrm.SetParentWindow(regWindow);
                    regWindow.Show();
                    regWindow.Closed += (s, args) =>
                    {
                        if (WebContext.Current.User.IsAuthenticated)
                        {
                            UserName = WebContext.Current.User.Name;
                            if (UserName.Length > 16) UserName = UserName.Substring(0, 16);
                        }
                    };
                }
                else if (!LgoinIsRequired & RoomID != "" & !WebContext.Current.User.IsAuthenticated)
                {
                    NickUserName.Show();

                }
                else if (!WebContext.Current.User.IsInRole(AdminRole) & WebContext.Current.User.IsInRole(NormalUserRole) & WebContext.Current.User.IsAuthenticated)
                {

                    this.DialogResult = true;
                }
                else if (WebContext.Current.User.IsInRole(AdminRole) & WebContext.Current.User.IsAuthenticated)
                {
                    IsAdmin = true;
                    this.DialogResult = true;
                }
            }
            catch { }
            finally { ShowMessageBox(""); }
        }

        void NickUserName_Closed(object sender, EventArgs e)
        {
            UserName = NickUserName.UserName;
            this.DialogResult = true;
        }

        private void JoinBTN_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (RoomsCombo.Items.Count > 0)
                {
                    if (RoomsCombo.SelectedValue != null)
                    {
                        ErrorMSG.Content = "";
                        RoomID = RoomsCombo.SelectedValue.ToString();
                        RoomID = RoomID.Replace('`', '*');
                        RoomID = RoomID.Replace('#', '*');
                        ReadRolePermissions();
                    }
                    else ShowErrorMessageBox("Please Select a Room!");
                }
                else ShowErrorMessageBox("No Any Room is available for your current Role!");
            }
            catch { }

        }

        private void ChildWindow_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            try
            {
                if (!WebContext.Current.User.IsAuthenticated & LgoinIsRequired) e.Cancel = true;

                if (WebContext.Current.User.IsAuthenticated & UserName == "")
                {
                    e.Cancel = true;
                    NickUserName.Show();
                }
            }
            catch { }
        }
        private string CheckQueryString()
        {
            try
            {
               return HtmlPage.Document.QueryString["RoomID"].ToString();
            }
            catch { return ""; }
        }
        private void ChildWindow_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                ShowMessageBox("Loading please wait...");

                WCS_WebService.WCS_Main_ServiceSoapClient RoomService = new WCS_WebService.WCS_Main_ServiceSoapClient();

                // Check If You have the last WCS Version
                RoomService.CheckVersionCompleted += new EventHandler<WCS_WebService.CheckVersionCompletedEventArgs>(CheckVersionCompleted);
                RoomService.CheckVersionAsync(WebServiceVersion);

                // Check If In ban list
                RoomService.Check_If_Banned_UserCompleted += new EventHandler<WCS_WebService.Check_If_Banned_UserCompletedEventArgs>(CheckIfInBanCompleted);
                RoomService.Check_If_Banned_UserAsync(WebContext.Current.User.Name);

            }
            catch { }
        }

        void CheckIfInBanCompleted(object sender, WCS_WebService.Check_If_Banned_UserCompletedEventArgs e)
        {
            try
            {
                if (e.Result)
                {
                    JoinBTN.IsEnabled = false;
                    ShowErrorMessageBox("Your User Name or IP has blocked by the system administrator!");
                }
            }
            catch { }
            finally { ShowMessageBox(""); }
        }

        void GetRoomsCompleted(object sender, WCS_WebService.Get_Rooms_ListCompletedEventArgs e)
        {
            try
            {
                // Fill The Available Rooms
                WCS_WebService.ArrayOfAnyType arr = e.Result;
                foreach (string RoomeName in arr)
                {
                    if (!RoomsCombo.Items.Contains(RoomeName))
                        RoomsCombo.Items.Add(RoomeName);
                }
                RoomsCombo.IsEnabled = true;
            }
            catch { }
            finally { ShowMessageBox(""); }
        }
        void CheckVersionCompleted(object sender, WCS_WebService.CheckVersionCompletedEventArgs e)
        {
            try
            {
                if (!e.Result)
                {
                    JoinBTN.IsEnabled = false;
                    ShowErrorMessageBox("There is a new version available, Please remove this version if it out of browser or clear the cash if it in browser");
                }
            }
            catch { }
            finally { ShowMessageBox(""); }
        }

        // Read Permissions
        void ReadRolePermissions()
        {
            try
            {
                ShowMessageBox("Loading please wait...");
                WCS_WebService.WCS_Main_ServiceSoapClient RoomService = new WCS_WebService.WCS_Main_ServiceSoapClient();
                RoomService.GetRolePermissionCompleted += new EventHandler<WCS_WebService.GetRolePermissionCompletedEventArgs>(GetGlobalUserPermissionsCompleted);
                RoomService.GetRolePermissionAsync(RoomID, NormalUserRole);
            }
            catch { }
        }
        void GetGlobalUserPermissionsCompleted(object sender, WCS_WebService.GetRolePermissionCompletedEventArgs e)
        {
            try
            {
                WCS_WebService.ArrayOfAnyType arr = e.Result;

                AllowUsing.AllowTXT = bool.Parse(arr[0].ToString());
                AllowUsing.AllowCAM = bool.Parse(arr[1].ToString());
                AllowUsing.AllowMic = bool.Parse(arr[2].ToString());
                AllowUsing.ALLOWWB = bool.Parse(arr[3].ToString());
                AllowUsing.AllowFiles = bool.Parse(arr[4].ToString());

                GetRoomContants();
            }
            catch { }
            finally { ShowMessageBox(""); }
        }

        private void CPBTN_Click(object sender, RoutedEventArgs e)
        {
            ControlPanel cp = new ControlPanel();
            cp.Show();
        }
    }
}

