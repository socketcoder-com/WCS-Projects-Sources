﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using WcsSecurity;

namespace SocketCoderWCS.Views.Login
{
    public partial class ControlPanel : ChildWindow
    {
        public ControlPanel()
        {
            InitializeComponent();
            GetBanUsersList();
            GetBanIPList();
        }

        private const string CPAdminRole = "IsPresenter";
        private const string SalatKey = "SO54454eAsxcv545404588R5T6z";

        void GetBanUsersList()
        {
            try
            {
                WCS_WebService.WCS_Main_ServiceSoapClient RoomService = new WCS_WebService.WCS_Main_ServiceSoapClient();
                RoomService.GetBanUsersListCompleted += new EventHandler<WCS_WebService.GetBanUsersListCompletedEventArgs>(BanUsersListCompleted);
                RoomService.GetBanUsersListAsync(WcsCryptography.GeneratePasswordHashCode(SalatKey));
            }
            catch { }
        }

        void BanUsersListCompleted(object sender, WCS_WebService.GetBanUsersListCompletedEventArgs e)
        {
            try
            {
                if (BanUsersList_Combo != null)
                {
                    BanUsersList_Combo.Items.Clear();
                    WCS_WebService.ArrayOfAnyType arr = e.Result;
                    foreach (string UserName in arr)
                    {
                        if (UserName != "")
                            if (!BanUsersList_Combo.Items.Contains(UserName))
                            {
                                BanUsersList_Combo.Items.Add(UserName);
                            }
                    }
                }
            }
            catch { }
        }
        void GetBanIPList()
        {
            try
            {
                WCS_WebService.WCS_Main_ServiceSoapClient RoomService = new WCS_WebService.WCS_Main_ServiceSoapClient();
                RoomService.GetBanIPListCompleted += new EventHandler<WCS_WebService.GetBanIPListCompletedEventArgs>(BanIPListCompleted);
                RoomService.GetBanIPListAsync(WcsCryptography.GeneratePasswordHashCode(SalatKey));
            }
            catch { }
        }
        void BanIPListCompleted(object sender, WCS_WebService.GetBanIPListCompletedEventArgs e)
        {
            try
            {
                if (BanIPList_Combo != null)
                {
                    BanIPList_Combo.Items.Clear();
                    WCS_WebService.ArrayOfAnyType arr = e.Result;
                    foreach (string IPAddress in arr)
                    {
                        if (IPAddress != "")
                            if (!BanIPList_Combo.Items.Contains(IPAddress))
                            {
                                BanIPList_Combo.Items.Add(IPAddress);
                            }
                    }
                }
            }
            catch { }
        }

        private void IsIitAdminRole(string RoomID,string RoleName)
        {
            try
            {
                WCS_WebService.WCS_Main_ServiceSoapClient RoomService = new WCS_WebService.WCS_Main_ServiceSoapClient();
                RoomService.CheckIfARoomAdminCompleted += new EventHandler<WCS_WebService.CheckIfARoomAdminCompletedEventArgs>(IsIitAdminRoleCompleted);
                RoomService.CheckIfARoomAdminAsync(RoleName, RoomID);
            }
            catch { }
        }
        void IsIitAdminRoleCompleted(object sender, WCS_WebService.CheckIfARoomAdminCompletedEventArgs e)
        {
            try
            {
                if (e.Result)
                {
                    UpdateRoleButton.IsEnabled = false;
                }
                else
                {
                    UpdateRoleButton.IsEnabled = true;
                }
            }
            catch { }
        }
        void ShowLogin()
        {
            try
            {
                MessageBox.Show("Your user name is not allowed to use the Control Panel!");
             DialogResult = false;
            }
            catch { }
          }
        bool IsAuthenticated()
        {
          return WebContext.Current.User.IsInRole(CPAdminRole);
        }

        int GetNumber(string Num)
        {
            if (Num.Trim(' ').Length != 0)
                try
                {
                    int number = int.Parse(Num);
                    if (number >= 0) return number;
                    else return 0;
                }
                catch
                {
                    return 0;
                }
            else return 0;
        }
        private void CreateRoomButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                if (IsAuthenticated())
                {
                    WCS_WebService.WCS_Main_ServiceSoapClient RoomService = new WCS_WebService.WCS_Main_ServiceSoapClient();

                    if (RoomNameTXT_Create.Text.Trim(' ').Length > 1 & AdminRoleCombo_Create.SelectedValue !=null & UserRoleCombo_Create.SelectedValue != null)
                    {
                        RoomService.CreateRoomCompleted += new EventHandler<WCS_WebService.CreateRoomCompletedEventArgs>(CreateRoomCompleted);
                        RoomService.CreateRoomAsync(RoomNameTXT_Create.Text, UserRoleCombo_Create.SelectedValue.ToString(), AdminRoleCombo_Create.SelectedValue.ToString(), (bool)LgoinIsRequired_Create.IsChecked, GetNumber(MaxUsersNumber_Create.Text),
                            (bool)Private_checkBox_Create.IsChecked,
                            (bool)Text_checkBox_Create.IsChecked,
                            (bool)Video_checkBox_Create.IsChecked,
                            (bool)Voice_checkBox_Create.IsChecked,
                            (bool)Presentations_checkBox_Create.IsChecked,
                            (bool)WB_checkBox_Create.IsChecked,
                            (bool)Files_checkBox_Create.IsChecked,
                            (bool)true, WcsCryptography.GeneratePasswordHashCode(RoomNameTXT_Create.Text.Length.ToString()));
                    }
                    else MessageBox.Show("All fields are required!");
                }
                else ShowLogin();
            }
            catch { }
        }
        void CreateRoomCompleted(object sender, WCS_WebService.CreateRoomCompletedEventArgs e)
        {
            try
            {
                if (e.Result.Contains("*"))
                {

                    FillRoomsID();
                    MessageBox.Show("The Room has created successfully");

                    string RoomID = e.Result.Trim('*');
                    string URL = System.Windows.Browser.HtmlPage.Document.DocumentUri.ToString();
                    if (URL.Contains("#"))
                        URL = URL.Substring(0, URL.IndexOf("#"));
                    InvitationURLTXT.Text = URL + "?RoomID=" + RoomID;
                    Roomhyperlink.NavigateUri = new Uri(InvitationURLTXT.Text);
                }
                else
                {
                    MessageBox.Show("You Cannot Create This Room, Because " + e.Result);
                }
            }
            catch { }
        }
        private void UpdateRoleButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (IsAuthenticated())
                {
                    WCS_WebService.WCS_Main_ServiceSoapClient RoomService = new WCS_WebService.WCS_Main_ServiceSoapClient();
                    if (RoomID_UpdateRolesCombo.SelectedValue != null & UserRoles_UpdateCombo.SelectedValue != null)
                    {
                        RoomService.UpdateRoomPermissionsCompleted += new EventHandler<WCS_WebService.UpdateRoomPermissionsCompletedEventArgs>(UpdateRoomPermissionsCompleted);
                        RoomService.UpdateRoomPermissionsAsync(RoomID_UpdateRolesCombo.SelectedValue.ToString(), UserRoles_UpdateCombo.SelectedValue.ToString(), (bool)AllowText.IsChecked, (bool)AllowVoice.IsChecked, (bool)AllowVideo.IsChecked, (bool)AllowFilesSharing.IsChecked,
                            (bool)AllowWhiteboard.IsChecked, GetNumber(MaxOnlineUsers_Update.Text), WcsCryptography.GeneratePasswordHashCode(RoomID_UpdateRolesCombo.SelectedValue.ToString().Length.ToString()));

                    }
                    else MessageBox.Show("All fields are required!");
                }
                else ShowLogin();
            }
            catch { }
        }
        void UpdateRoomPermissionsCompleted(object sender, WCS_WebService.UpdateRoomPermissionsCompletedEventArgs e)
        {
            try
            {
                if (e.Result == "Done")
                {
                    MessageBox.Show("The Room role permissions has updated successfully");
                }
                else
                {
                    MessageBox.Show("You Cannot update this room role permissions, Because " + e.Result);
                }
            }
            catch { }
        }
        private void RemoveRoomBTN_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (IsAuthenticated())
                {

                    if (RoomNameCombo_Delete.SelectedValue != null)
                    {
                        WCS_WebService.WCS_Main_ServiceSoapClient RoomService = new WCS_WebService.WCS_Main_ServiceSoapClient();
                        RoomService.RemoveRoomCompleted += new EventHandler<WCS_WebService.RemoveRoomCompletedEventArgs>(RemoveRoomCompleted);
                        RoomService.RemoveRoomAsync(RoomNameCombo_Delete.SelectedValue.ToString(),
                            WcsCryptography.GeneratePasswordHashCode(RoomNameCombo_Delete.SelectedValue.ToString().Length.ToString()));
                    }
                    else MessageBox.Show("All fields are required!");
                }
                else ShowLogin();
            }
            catch { }
        }
        void RemoveRoomCompleted(object sender, WCS_WebService.RemoveRoomCompletedEventArgs e)
        {
            try
            {
                if (e.Result == "Done")
                {
                    FillRoomsID();
                    MessageBox.Show("The Room has removed successfully");
                }
                else
                {
                    MessageBox.Show("You Cannot remove This Room, Because " + e.Result);
                }
            }
            catch { }
        }
        void FillRoomsID()
        {
            try
            {
                WCS_WebService.WCS_Main_ServiceSoapClient RoomService = new WCS_WebService.WCS_Main_ServiceSoapClient();
                RoomService.Get_AllRoomsNamesCompleted += new EventHandler<WCS_WebService.Get_AllRoomsNamesCompletedEventArgs>(FillRoomsICompleted);
                RoomService.Get_AllRoomsNamesAsync();
            }
            catch { }
        }
        void FillRoomsICompleted(object sender, WCS_WebService.Get_AllRoomsNamesCompletedEventArgs e)
        {
            try
            {
                RoomID_UpdateRolesCombo.Items.Clear();
                RoomNameCombo_Delete.Items.Clear();
                RoomsCombo_Update.Items.Clear();

                WCS_WebService.ArrayOfAnyType arr = e.Result;
                foreach (string RoomeName in arr)
                {
                    RoomID_UpdateRolesCombo.Items.Add(RoomeName);
                    RoomNameCombo_Delete.Items.Add(RoomeName);
                    RoomsCombo_Update.Items.Add(RoomeName);
                }
            }
            catch { }
        }
        void FillRolesNames()
        {
            try
            {
                WCS_WebService.WCS_Main_ServiceSoapClient RoomService = new WCS_WebService.WCS_Main_ServiceSoapClient();
                RoomService.Get_Roles_ListCompleted += new EventHandler<WCS_WebService.Get_Roles_ListCompletedEventArgs>(FillRolesNamesCompleted);
                RoomService.Get_Roles_ListAsync();
            }
            catch { }
        }
        void FillRolesNamesCompleted(object sender, WCS_WebService.Get_Roles_ListCompletedEventArgs e)
        {
            try
            {
                WCS_WebService.ArrayOfAnyType arr = e.Result;
                foreach (string RoleName in arr)
                {
                    UserRoleCombo_Create.Items.Add(RoleName);
                    AdminRoleCombo_Create.Items.Add(RoleName);
                    UserRoleCombo_Update.Items.Add(RoleName);
                    AdminRoleCombo_Update.Items.Add(RoleName);
                }
            }
            catch { }
        }
        void FillRolesNames(string RoomID)
        {
            try
            {
                WCS_WebService.WCS_Main_ServiceSoapClient RoomService = new WCS_WebService.WCS_Main_ServiceSoapClient();
                RoomService.GetRoomRolesCompleted += new EventHandler<WCS_WebService.GetRoomRolesCompletedEventArgs>(FillRolesNamesByRoomIDCompleted);
                RoomService.GetRoomRolesAsync(RoomID);
            }
            catch { }
        }
        void FillRolesNamesByRoomIDCompleted(object sender, WCS_WebService.GetRoomRolesCompletedEventArgs e)
        {
            try
            {
                WCS_WebService.ArrayOfAnyType arr = e.Result;
                UserRoles_UpdateCombo.Items.Clear();
                foreach (string RoleName in arr)
                {
                    UserRoles_UpdateCombo.Items.Add(RoleName);
                }
            }
            catch { }
        }
        void ReadPermissions()
        {

        }
        private void LayoutRoot_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                FillRoomsID();
                FillRolesNames();
            }
            catch { }
        }

        private void UpdateRoomButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (IsAuthenticated())
                {
                    if (RoomsCombo_Update.SelectedValue != null & UserRoleCombo_Update.SelectedValue != null & AdminRoleCombo_Update.SelectedValue != null & NewRoomNameTXT_RoomUpdate.Text.Trim(' ').Length >= 1)
                    {
                        WCS_WebService.WCS_Main_ServiceSoapClient RoomService = new WCS_WebService.WCS_Main_ServiceSoapClient();
                        RoomService.UpdateRoomRole_With_ContentsCompleted += new EventHandler<WCS_WebService.UpdateRoomRole_With_ContentsCompletedEventArgs>(UpdateRoomRoleCompleted);
                        RoomService.UpdateRoomRole_With_ContentsAsync(RoomsCombo_Update.SelectedValue.ToString(), NewRoomNameTXT_RoomUpdate.Text, UserRoleCombo_Update.SelectedValue.ToString(), AdminRoleCombo_Update.SelectedValue.ToString(),
                            (bool)LoginIsRequired_Update.IsChecked,
                            (bool)Private_checkBox_Update.IsChecked,
                            (bool)Text_checkBox_Update.IsChecked,
                            (bool)Video_checkBox_Update.IsChecked,
                            (bool)Voice_checkBox_Update.IsChecked,
                            (bool)Presentations_checkBox_Update.IsChecked,
                            (bool)WB_checkBox_Update.IsChecked,
                            (bool)Files_checkBox_Update.IsChecked,
                            (bool)true, WcsCryptography.GeneratePasswordHashCode(RoomsCombo_Update.SelectedValue.ToString().Length.ToString()));
                    }
                    else MessageBox.Show("All fields are required!");
                 }
                else ShowLogin();
            }
            catch { }
        }
        void UpdateRoomRoleCompleted(object sender, WCS_WebService.UpdateRoomRole_With_ContentsCompletedEventArgs e)
        {
            try
            {
                if (e.Result == "Done")
                {
                    FillRoomsID();
                    MessageBox.Show("The Room roles has updated successfully");
                }
                else
                {
                    MessageBox.Show("You Cannot update This Room roles, Because " + e.Result);
                }
            }
            catch { }
        }

        void GetRoomContants(string RoomID)
        {
            try
            {
                WCS_WebService.WCS_Main_ServiceSoapClient RoomService = new WCS_WebService.WCS_Main_ServiceSoapClient();
                RoomService.GetRoomContentsCompleted += new EventHandler<WCS_WebService.GetRoomContentsCompletedEventArgs>(GetRoomContentsCompleted);
                RoomService.GetRoomContentsAsync(RoomID);

                RoomService.GetRoomIDByRoomTitleCompleted += new EventHandler<WCS_WebService.GetRoomIDByRoomTitleCompletedEventArgs>(GetRoomIDCompleted);
                RoomService.GetRoomIDByRoomTitleAsync(RoomID);

            }
            catch { }
        }
        void GetRoomContentsCompleted(object sender, WCS_WebService.GetRoomContentsCompletedEventArgs e)
        {
            try
            {
                WCS_WebService.ArrayOfAnyType arr = e.Result;
                Private_checkBox_Update.IsChecked = bool.Parse(arr[0].ToString());
                Text_checkBox_Update.IsChecked = bool.Parse(arr[1].ToString());
                Video_checkBox_Update.IsChecked = bool.Parse(arr[2].ToString());
                Voice_checkBox_Update.IsChecked = bool.Parse(arr[3].ToString());
                Presentations_checkBox_Update.IsChecked = bool.Parse(arr[4].ToString());
                WB_checkBox_Update.IsChecked = bool.Parse(arr[5].ToString());
                Files_checkBox_Update.IsChecked = bool.Parse(arr[6].ToString());
                OnlineUsers_checkBox_Update.IsChecked = bool.Parse(arr[7].ToString());
                LoginIsRequired_Update.IsChecked = bool.Parse(arr[8].ToString());

                AdminRoleCombo_Update.SelectedValue = arr[9].ToString();
                UserRoleCombo_Update.SelectedValue = arr[10].ToString();
            }
            catch { }
        }


        private void UserRoles_UpdateCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (e != null)
                    if (RoomID_UpdateRolesCombo.SelectedValue != null & UserRoles_UpdateCombo.SelectedValue != null)
                    {
                        WCS_WebService.WCS_Main_ServiceSoapClient RoomService = new WCS_WebService.WCS_Main_ServiceSoapClient();
                        IsIitAdminRole(RoomID_UpdateRolesCombo.SelectedValue.ToString(), UserRoles_UpdateCombo.SelectedValue.ToString());
                        RoomService.GetRolePermissionCompleted += new EventHandler<WCS_WebService.GetRolePermissionCompletedEventArgs>(GetRolePermissionCompleted);
                        RoomService.GetRolePermissionAsync(RoomID_UpdateRolesCombo.SelectedValue.ToString(), UserRoles_UpdateCombo.SelectedValue.ToString());
                    }
            }
            catch { }
        }
        void GetRolePermissionCompleted(object sender, WCS_WebService.GetRolePermissionCompletedEventArgs e)
        {
            try
            {
                WCS_WebService.ArrayOfAnyType arr = e.Result;
                AllowText.IsChecked = bool.Parse(arr[0].ToString());
                AllowVideo.IsChecked = bool.Parse(arr[1].ToString());
                AllowVoice.IsChecked = bool.Parse(arr[2].ToString());
                AllowWhiteboard.IsChecked = bool.Parse(arr[3].ToString());
                AllowFilesSharing.IsChecked = bool.Parse(arr[4].ToString());
                MaxOnlineUsers_Update.Text = arr[5].ToString();
            }
            catch { }
        }
        private void RoomID_UpdateRolesCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (e != null)
                {
                    if (RoomID_UpdateRolesCombo.SelectedValue != null)
                    {
                        FillRolesNames(RoomID_UpdateRolesCombo.SelectedValue.ToString());
                        UserRoles_UpdateCombo.IsEnabled = true;
                    }
                    else UserRoles_UpdateCombo.IsEnabled = false;
                }
            }
            catch { }
        }
        private void RoomsCombo_Update_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (RoomsCombo_Update.SelectedValue != null)
                {
                    NewRoomNameTXT_RoomUpdate.Text = RoomsCombo_Update.SelectedValue.ToString();
                    GetRoomContants(RoomsCombo_Update.SelectedValue.ToString());
                }
            }
            catch { }
        }
        void GetRoomIDCompleted(object sender, WCS_WebService.GetRoomIDByRoomTitleCompletedEventArgs e)
        {
            try
            {
                string RoomID = e.Result;
                string URL = System.Windows.Browser.HtmlPage.Document.DocumentUri.ToString();
                if (URL.Contains("#"))
                    URL = URL.Substring(0, URL.IndexOf("#"));
                Invite_UpdateTXT.Text = URL + "?RoomID=" + RoomID;
                Invite_hyperlink_update.NavigateUri = new Uri(Invite_UpdateTXT.Text);
            }
            catch { }
        }
        private void IP_BanRadioButton_Checked(object sender, RoutedEventArgs e)
        {
            if (IP_BanRadioButton != null)
            {
                UserNameBan_TXT.IsEnabled = false;
                IPAddress_TXT.IsEnabled = true;

                BanIPList_Combo.IsEnabled = true;
                BanUsersList_Combo.IsEnabled = false;
            }
        }
        private void UserName_BanRadioButton_Checked(object sender, RoutedEventArgs e)
        {
            if (UserName_BanRadioButton != null)
            {
                UserNameBan_TXT.IsEnabled = true;
                IPAddress_TXT.IsEnabled = false;

                BanIPList_Combo.IsEnabled = false;
                BanUsersList_Combo.IsEnabled = true;
            }
        }
        private void Add_TO_Ban_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (IsAuthenticated())
                {


                    if (UserNameBan_TXT.IsEnabled)
                    {                        

                        if (UserNameBan_TXT.Text.Trim(' ').Length > 0)
                        {
                            if (!BanUsersList_Combo.Items.Contains(UserNameBan_TXT.Text))
                            {
                                WCS_WebService.WCS_Main_ServiceSoapClient RoomService = new WCS_WebService.WCS_Main_ServiceSoapClient();
                                RoomService.Ban_A_User_or_IPCompleted += new EventHandler<WCS_WebService.Ban_A_User_or_IPCompletedEventArgs>(Ban_A_User_or_IPCompleted);
                                RoomService.Ban_A_User_or_IPAsync(UserNameBan_TXT.Text, false, 
                                      WcsCryptography.GeneratePasswordHashCode(UserNameBan_TXT.Text.Length.ToString()));
                            }
                        }
                        else MessageBox.Show("Please Write a User Name!");
                    }
                    else if (IPAddress_TXT.IsEnabled)
                    {
                        try
                        {
                            // Test is it IP?
                            IPAddress.Parse(IPAddress_TXT.Text);

                            if (!BanIPList_Combo.Items.Contains(IPAddress_TXT.Text))
                            {
                                WCS_WebService.WCS_Main_ServiceSoapClient RoomService = new WCS_WebService.WCS_Main_ServiceSoapClient();
                                RoomService.Ban_A_User_or_IPCompleted += new EventHandler<WCS_WebService.Ban_A_User_or_IPCompletedEventArgs>(Ban_A_User_or_IPCompleted);
                                RoomService.Ban_A_User_or_IPAsync(IPAddress_TXT.Text, true, 
                                    WcsCryptography.GeneratePasswordHashCode(IPAddress_TXT.Text.Length.ToString()));
                            }
                        }
                        catch {MessageBox.Show("Wrong IP!"); }

                    }
                 
                }
                else ShowLogin();
            }
            catch { }
        }
        void Ban_A_User_or_IPCompleted(object sender, WCS_WebService.Ban_A_User_or_IPCompletedEventArgs e)
        {
            try
            {
                if (e.Result == "Done")
                {
                    GetBanUsersList();
                    GetBanIPList();
                    MessageBox.Show("The User has added to the ban list successfully");
                }
                else
                {
                    MessageBox.Show("You Cannot add This user, Because " + e.Result);
                }
            }
            catch { }
        }
        private void Remove_From_Ban_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (IsAuthenticated())
                {
                    if (UserNameBan_TXT.IsEnabled)
                    {
                        if (UserNameBan_TXT.Text.Trim(' ').Length > 0)
                        {
                            WCS_WebService.WCS_Main_ServiceSoapClient RoomService = new WCS_WebService.WCS_Main_ServiceSoapClient();
                            RoomService.Remove_Banned_User_or_IPCompleted += new EventHandler<WCS_WebService.Remove_Banned_User_or_IPCompletedEventArgs>(RemoveBan_A_User_or_IPCompleted);
                            RoomService.Remove_Banned_User_or_IPAsync(UserNameBan_TXT.Text, false, 
                                 WcsCryptography.GeneratePasswordHashCode(UserNameBan_TXT.Text.Length.ToString()));
                        }
                        else MessageBox.Show("Please Write a User Name!");
                    }
                    else if (IPAddress_TXT.IsEnabled)
                    {
                        try
                        {
                            // Test is it IP?
                            IPAddress.Parse(IPAddress_TXT.Text);
                            WCS_WebService.WCS_Main_ServiceSoapClient RoomService = new WCS_WebService.WCS_Main_ServiceSoapClient();
                            RoomService.Remove_Banned_User_or_IPCompleted += new EventHandler<WCS_WebService.Remove_Banned_User_or_IPCompletedEventArgs>(RemoveBan_A_User_or_IPCompleted);
                            RoomService.Remove_Banned_User_or_IPAsync(IPAddress_TXT.Text, true, 
                                WcsCryptography.GeneratePasswordHashCode(IPAddress_TXT.Text.Length.ToString()));
                        }
                        catch { MessageBox.Show("Wrong IP!"); }

                    }

                }
                else ShowLogin();
            }
            catch { }
        }
        void RemoveBan_A_User_or_IPCompleted(object sender, WCS_WebService.Remove_Banned_User_or_IPCompletedEventArgs e)
        {
            try
            {
                if (e.Result == "Done")
                {
                    GetBanUsersList();
                    GetBanIPList();
                    MessageBox.Show("The User has removed from the ban list successfully");
                }
                else
                {
                    MessageBox.Show("You Cannot remove This user frm the ban list, Because " + e.Result);
                }
            }
            catch { }
        }

        private void BanIPList_Combo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (BanIPList_Combo != null)
                    if (BanIPList_Combo.SelectedValue != null)
                        IPAddress_TXT.Text = BanIPList_Combo.SelectedValue.ToString();
            }
            catch { }
        }

        private void BanUsersList_Combo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (BanUsersList_Combo != null)
                    if (BanUsersList_Combo.SelectedValue != null)
                        UserNameBan_TXT.Text = BanUsersList_Combo.SelectedValue.ToString();
            }
            catch { }
        }

        private void ChildWindow_Closed(object sender, EventArgs e)
        {
            if (IsAuthenticated() & !App.Current.IsRunningOutOfBrowser)
            System.Windows.Browser.HtmlPage.Document.Submit();
        }

    
    }
}

