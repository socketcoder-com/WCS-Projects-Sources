﻿// (C) SocketCoder.Com 
// Last Modify: 1/July/2014

using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using MediaStreaming;
using System.IO;

namespace SocketCoderWCS.Views
{
    public partial class CaptureDevicesSettings : ChildWindow
    {
        public CaptureDevicesSettings()
        {
            InitializeComponent();
            FillData();

            audiSink = new MemoryAudioSink();
        }

        #region Global Declarations

        public event EventHandler AllowUsingClicked;
        public event EventHandler DontAllowClicked;

        public MediaElement PlaybackTestME = new MediaElement();
        public StreamingMediaSource PlaybackTestSMSource;

        // Audio Format
        public int SamplesPerSecond;
        public int BitsPerSample;
        public int Channels;

        // Video Format
        public int ImageQuality = 50;
        public int FPMS = 200;

        public CaptureSource Capture_Source = new CaptureSource();
        public MemoryAudioSink audiSink;

        public bool isPlayback = false;
        public bool AllowUsing = false;
        public bool HaveMic = false;
        public bool HaveCam = false;

        // Private
        private delegate void mydelegate(byte[] buffer);
        private delegate void ShowMessagedelegate(string MSG);
        private delegate void Enabledelegate(bool value);
        private MediaElement PlaybackMediaElement = new MediaElement();

        private AudioFormat SelectedFormat;
        private AudioCaptureDevice SelectedAudioDevice;
        private ComboBox AvailableFormatsCombobox = new ComboBox();

        #endregion Global Declarations


        void FillData()
        {
            try
            {
                if (CaptureDeviceConfiguration.GetAvailableAudioCaptureDevices().Count > 0)
                {
                    var audioFormats = (from format in Capture_Source.AudioCaptureDevice.SupportedFormats
                                        where format.WaveFormat == WaveFormatType.Pcm
                                        where format.BitsPerSample == 16
                                        where format.SamplesPerSecond >= 8000
                                        orderby format.Channels, format.BitsPerSample, format.SamplesPerSecond
                                        select format);

                    foreach (AudioFormat format in audioFormats)
                    {
                        FormatComboBox.Items.Add("Bits= " + format.BitsPerSample + " Samples= " + format.SamplesPerSecond + " Channels= " + format.Channels);
                        AvailableFormatsCombobox.Items.Add(format);
                    }

                    SelectedAudioDevice = CaptureDeviceConfiguration.GetDefaultAudioCaptureDevice();
                    SelectedFormat = audioFormats.First();

                    string SelectedFormatString = "Bits= " + SelectedFormat.BitsPerSample + " Samples= " + SelectedFormat.SamplesPerSecond + " Channels= " + SelectedFormat.Channels;
                    FormatComboBox.SelectedValue = SelectedFormatString;

                    BitsPerSample = SelectedFormat.BitsPerSample;
                    SamplesPerSecond = SelectedFormat.SamplesPerSecond;
                    Channels = SelectedFormat.Channels;

                    MicrophonesInDevicesCombobox.Items.Add(SelectedAudioDevice.FriendlyName);
                    MicrophonesInDevicesCombobox.SelectedValue = SelectedAudioDevice.FriendlyName;
                    AvailableFormatsCombobox.SelectedItem = SelectedFormat;
                    HaveMic = true;
                }
                else
                {
                    HaveMic = false;
                    MicrophonesInDevicesCombobox.Items.Add("No any avilable microphone!");
                    MicrophonesInDevicesCombobox.SelectedValue = "No any avilable microphone!";
                }
            }
            catch { HaveMic = false; }

            try
            {
                if (CaptureDeviceConfiguration.GetAvailableVideoCaptureDevices().Count > 0)
                {
                    WebCamsCombo.Items.Add(CaptureDeviceConfiguration.GetDefaultVideoCaptureDevice().FriendlyName);
                    WebCamsCombo.SelectedValue = CaptureDeviceConfiguration.GetDefaultVideoCaptureDevice().FriendlyName;
                    Capture_Source.VideoCaptureDevice = CaptureDeviceConfiguration.GetDefaultVideoCaptureDevice();
                    Capture_Source.VideoCaptureDevice.DesiredFormat = new VideoFormat(PixelFormatType.Format32bppArgb, 150, 130, 10);
                    HaveCam = true;
                }
                else
                {
                    WebCamsCombo.Items.Add("No any avilable webcam!");
                    WebCamsCombo.SelectedValue = "No any avilable webcam!";
                    HaveCam = false;
                }
            }
            catch { }
        }
        bool StartCapturing()
        {
            try
            {
                if ((CaptureDeviceConfiguration.AllowedDeviceAccess | CaptureDeviceConfiguration.RequestDeviceAccess()) & (Capture_Source.State == CaptureState.Stopped || Capture_Source.State == CaptureState.Failed))
                    {
                        if (HaveMic)
                        {
                            Capture_Source.AudioCaptureDevice = SelectedAudioDevice;
                            Capture_Source.AudioCaptureDevice.DesiredFormat = SelectedFormat;
                            BitsPerSample = SelectedFormat.BitsPerSample;
                            SamplesPerSecond = SelectedFormat.SamplesPerSecond;
                            Channels = SelectedFormat.Channels;
                            string SelectedFormatString = "Bits= " + SelectedFormat.BitsPerSample + " Samples= " + SelectedFormat.SamplesPerSecond + " Channels= " + SelectedFormat.Channels;
                            FormatComboBox.SelectedValue = SelectedFormatString;
                            AvailableFormatsCombobox.SelectedIndex = FormatComboBox.SelectedIndex;
                            audiSink.CaptureSource = Capture_Source;
                            Capture_Source.Start();
                            return true;
                        }
                        else if (!HaveMic & HaveCam)
                        {
                            // Just Start The Cam
                            Capture_Source.Start();
                            ShowMessageBox("No any avilable microphone found!, Please note that you will not be able to use the voice chat function");
                            return true;
                        }
                        else
                        {
                            ShowMessageBox("No any avilable capture device found!,Please Connect a microphone and refresh the page then try again or just press on don't allow button to ignore");
                            return false;
                        }

                    }
                    else if (Capture_Source.State == CaptureState.Started) return true;
                    else if (Capture_Source.State == CaptureState.Failed)
                    {
                        ShowMessageBox("The Capturing Device Failed to Start, may it's in use with another application! ");
                        return false;
                    }
                    else return false;
            }
            catch
            {
                ShowMessageBox("The Capturing Device Failed to Start, may it's in use with another application!");
                return false;
            }
           
        }
        public void StopCapturing()
        {
            if (Capture_Source != null & audiSink != null)
            {
                if (Capture_Source.State == CaptureState.Started) 
                    Capture_Source.Stop();

                if (isPlayback)
                 PlaybackTest(false);

                AllowUsing = false;
            }
        }

        void PlaybackTest(bool value)
        {
            if (value & HaveMic)
            {
                audiSink.IsVoiceSendingStarted = true;
                isPlayback = value;
                StartPlaybackBTN.IsEnabled = !value;
                StopPlaybackBTN.IsEnabled = value;
                AttentionMSG.Visibility = System.Windows.Visibility.Visible;
                MicrophonesInDevicesCombobox.Width = 151;

            }
            else if (!value)
            {
                audiSink.IsVoiceSendingStarted = false;
                isPlayback = value;
                StartPlaybackBTN.IsEnabled = !value;
                StopPlaybackBTN.IsEnabled = value;
                AttentionMSG.Visibility = System.Windows.Visibility.Collapsed;
                MicrophonesInDevicesCombobox.Width = 363;
            }
        }

        private void ShowMessageBox(string MSG)
        {
            MessageBox.Show(MSG, "SocketCoder Capture Devices Settings", MessageBoxButton.OK);
        }

        private void OKButton_Click(object sender, RoutedEventArgs e)
        {
            if (isPlayback)
                PlaybackTest(false);

            if (StartCapturing())
            {
                this.DialogResult = AllowUsing = true;

                if (AllowUsingClicked != null)
                AllowUsingClicked(sender, e);
            }

        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DontAllowClicked(sender, e);
            this.DialogResult = AllowUsing = false;
            StopCapturing();
        }

        private void VoiceQualitySlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (audiSink != null)
            {
                VoiceQLB.Content = audiSink.VoiceQuality = (int)VoiceQualitySlider.Value;
            }
        }

        private void StartPlayback(object sender, RoutedEventArgs e)
        {
            if (HaveMic)
            if (StartCapturing())
                PlaybackTest(true);
            else PlaybackTest(false);
        }

        private void StopPlaybackBTN_Click(object sender, RoutedEventArgs e)
        {
            PlaybackTest(false);
        }

        private void ImageQualitySlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (ImageQualitySlider != null)
            {
                ImageQuality = int.Parse(Math.Ceiling(ImageQualitySlider.Value).ToString());
                ImageQualityLB.Content = ImageQuality;
            }
        }
        private void FPS_Slider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (FPS_Slider != null)
            {
                int iFPS = int.Parse(Math.Ceiling(FPS_Slider.Value).ToString());
                FPMS = 1000 / iFPS;
                FPS_LB.Content = iFPS.ToString();
            }
        }

    }
}

