﻿using SilverFlow.Controls;
using System.Windows.Media;

namespace SocketCoderWCS.Views
{
    public partial class LocalWebCam : FloatingWindow
    {
        public LocalWebCam()
        {
            InitializeComponent();
        }

    }
}
