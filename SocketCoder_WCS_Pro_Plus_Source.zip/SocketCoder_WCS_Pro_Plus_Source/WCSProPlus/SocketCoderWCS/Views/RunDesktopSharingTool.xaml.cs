﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using MeidaStreaming;

namespace SocketCoderWCS.Views
{
    public partial class RunDesktopSharingTool : ChildWindow
    {
        RoomCodeData RoomCode = new RoomCodeData();
        
        public RunDesktopSharingTool(string Room_ID, string User_Name)
        {
            InitializeComponent();
            RoomCodeTXT.Text = RoomCode.GenerateRoomCode(Room_ID, User_Name + " Desktop");
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }
    }
}

