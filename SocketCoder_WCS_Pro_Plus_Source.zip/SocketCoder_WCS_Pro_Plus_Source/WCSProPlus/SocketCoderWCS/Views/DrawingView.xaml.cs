﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.IO;
using System.Windows.Media.Imaging;
using ImageTools.IO.Jpeg;
using ImageTools;

namespace SocketCoderWCS.Views
{
    public partial class DrawingView : UserControl
    {
        public DrawingView(BitmapImage RIMG)
        {
            InitializeComponent();

            ReceivedDrawing.Source = RIMG;
        }
        private void ReceivedDrawing_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ClickCount == 2)
                try
                {
                    SaveFileDialog saveFileDlg = new SaveFileDialog();
                    ImageTools.IO.Jpeg.JpegEncoder EncodeJpeg = new ImageTools.IO.Jpeg.JpegEncoder();
                    EncodeJpeg.Quality = 100;
                    saveFileDlg.DefaultFileName = "Drawing " + DateTime.Now.ToFileTime().ToString();
                    saveFileDlg.Filter = "JPEG Files (*.jpg)|*.jpg";
                    saveFileDlg.DefaultExt = ".jpg";

                    if (saveFileDlg.ShowDialog().Value)
                    {
                        using (Stream dstStream = saveFileDlg.OpenFile())
                        {
                            WriteableBitmap bmp = new WriteableBitmap(ReceivedDrawing, null);
                            EncodeJpeg.Encode(bmp.ToImage(), dstStream);
                        }
                    }
                }
                catch { }
        }
    }
}