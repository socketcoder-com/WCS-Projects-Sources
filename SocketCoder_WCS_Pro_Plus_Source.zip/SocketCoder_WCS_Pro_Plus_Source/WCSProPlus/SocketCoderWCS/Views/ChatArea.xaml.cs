﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Media.Imaging;
using ImageTools;
using System.ComponentModel;
using MediaStreaming;
using SocketCoderWCS.WCS_Proxy;
using System.IO;

namespace SocketCoderWCS.Views
{
    public partial class ChatArea : SilverFlow.Controls.FloatingWindow
    {
        public BackgroundWorker DrawingEncodrThread = new BackgroundWorker();
        public BackgroundWorker DrawingDecoderThread = new BackgroundWorker();
        public event EventHandler SendTextClicked;
        public event EventHandler SendDrawingClicked;

        private WcsPacketizer Packetizer = new WcsPacketizer();
        private string WCSTextServiceName;
        private const string SmileyFlag = "(:SF)"; // To send smiley icon
        private string MsgBold = "1";
        private string MsgItalic = "0";
        private string MsgColor = "0";
        private string UserName = "";
        private string RoomID = "";
        private bool IsPublic = true;
        private string TalkingWith = "";

        private struct ReceivedStream
        {
            public Stream DataStream;
            public string SentFrom;
            public string SentTo;
        }

        public ChatArea(string Talking_With,string User_Name, string Room_ID ,string TextServiceName,bool Is_Public)
        {
            InitializeComponent();

            DrawingEncodrThread.DoWork += new DoWorkEventHandler(DrawingEncoder);
            DrawingDecoderThread.DoWork += new DoWorkEventHandler(DrawingDecoder);

            DrawingArea.OnDrawingSendClicked += new EventHandler(SendDrawingBTN_Click);
            IsPublic = Is_Public;
            UserName = User_Name;
            RoomID = Room_ID;
            WCSTextServiceName = TextServiceName;

            if (IsPublic)
            {
                TalkingWith = Talking_With = Room_ID;
                this.Title = IconText = "Public Text Chat";
            }
            else
            {
                this.Title = ("Text Chatting With " + Talking_With);
                IconText = TalkingWith = Talking_With;
            }

        }

        public void EnableControl(bool value)
        {
              MesgSendTextbox.IsEnabled = value;
              SendRichBTN.IsEnabled = value;
              SmileySendBTN.IsEnabled = value;
              DrawingArea.IsEnabled = value;
              btnClear.IsEnabled = value;
        }

        private void btnClear_Click(object sender, RoutedEventArgs e)
        {
            SpnlMessages.Children.Clear();
            MesgSendTextbox.Text = "";
            MesgSendTextbox.Focus();
        }

        private void SetScrollBarToBottom()
        {
            // set the scroll bar to the bottom
            SvwrMessages.UpdateLayout();
            SvwrMessages.ScrollToVerticalOffset(double.MaxValue);
        }

        public void ShowErrorMessageBox(string MSG)
        {
            string MsgFormat = MsgColor + MsgBold + MsgItalic;
            AddMSGToChatList(WCSTextServiceName, UserName, MsgFormat + MSG);
        }

        private System.Windows.Controls.Image GetSmileyImage(string SType)
        {
            try
            {
                System.Windows.Controls.Image img = new System.Windows.Controls.Image();
                img.Stretch = Stretch.Uniform;
                img.Width = 25;
                img.Height = 25;
                BitmapImage bi = new BitmapImage();
                bi = new BitmapImage(new Uri("/SocketCoderWCS;component/Views/Smiley/" + SType + ".png", UriKind.Relative));
                img.Source = bi;
                return img;
            }
            catch { return null; }
        }
        public void AddMSGToChatList(string MFrom, string SentTO, string MSG)
        {
            try
            {
                // Add Name:
                TextBlock name = new TextBlock();
                if (SentTO == RoomID)
                    name.Text = MFrom + " Sent to All Room Members";
                else if (SentTO == UserName)
                    name.Text = MFrom + " Sent to You";
                else name.Text = MFrom + " Sent to " + SentTO;
                name.FontSize = 14;
                name.FontWeight = FontWeights.Bold;
                name.Foreground = new SolidColorBrush(Colors.Gray);
                SpnlMessages.Children.Add(name);

                if (MSG.Length > SmileyFlag.Length)
                    if (MSG.Substring(0, SmileyFlag.Length) == SmileyFlag)
                    {
                        // Add Smiley:
                         SpnlMessages.Children.Add(GetSmileyImage(MSG.Substring(SmileyFlag.Length, MSG.Length - SmileyFlag.Length)));

                        // Add Sent At Time:
                        TextBlock text = new TextBlock();
                        text.FontSize = 10;
                        text.Text = "Sent at " + DateTime.Now.ToString();
                        text.TextWrapping = TextWrapping.Wrap;
                        SpnlMessages.Children.Add(text);
                        SetScrollBarToBottom();
                        return;
                    }

                // Add Message:
                TextBox TXTBlock = new TextBox();
                TXTBlock.Width = this.Width - 35;
                TXTBlock.FontSize = 12;
                TXTBlock.IsReadOnly = true;
                TXTBlock.AcceptsReturn = true;
                TXTBlock.TextWrapping = TextWrapping.Wrap;
                TXTBlock.Background = new SolidColorBrush(Colors.White);
                TXTBlock.BorderBrush = new SolidColorBrush(Colors.Transparent);

                string TextBlockColor = MSG.Substring(0, 1);
                string TextBlockBold = MSG.Substring(1, 1);
                string TextBlockItalic = MSG.Substring(2, 1);
                MSG = MSG.Substring(3, MSG.Length - 3);

                switch (TextBlockColor)
                {
                    case "0":
                        {
                            TXTBlock.Foreground = new SolidColorBrush(Colors.Black);
                        }
                        break;
                    case "1":
                        {
                            TXTBlock.Foreground = new SolidColorBrush(Colors.Red);
                        }
                        break;
                    case "2":
                        {
                            TXTBlock.Foreground = new SolidColorBrush(Colors.Green);
                        }
                        break;
                    case "3":
                        {
                            TXTBlock.Foreground = new SolidColorBrush(Colors.Blue);
                        }
                        break;
                }

                if (TextBlockBold == "1") TXTBlock.FontWeight = FontWeights.Bold;
                else if (TextBlockBold == "0") TXTBlock.FontWeight = FontWeights.Normal;

                if (TextBlockItalic == "1") TXTBlock.FontStyle = FontStyles.Italic;
                else if (TextBlockItalic == "0") TXTBlock.FontStyle = FontStyles.Normal;

                TXTBlock.Text = MSG;
                SpnlMessages.Children.Add(TXTBlock);

                // Add Sent At Time:
                TextBlock textB = new TextBlock();
                textB.FontSize = 10;
                textB.Text = "Sent at " + DateTime.Now.ToString();
                textB.Foreground = new SolidColorBrush(Colors.Gray);
                SpnlMessages.Children.Add(textB);
                SetScrollBarToBottom();
            }
            catch { }
        }

        public void AddDrawingToChatList(string MFrom, string SentTO, BitmapImage DrawingIMG)
        {
            try
            {
                // Add Name:
                TextBlock name = new TextBlock();
                if (SentTO == RoomID)
                    name.Text = MFrom + " Sent to All Room Members";
                else if (SentTO == UserName)
                    name.Text = MFrom + " Sent to You";
                else name.Text = MFrom + " Sent to " + SentTO;
                name.FontSize = 14;
                name.FontWeight = FontWeights.Bold;
                name.Foreground = new SolidColorBrush(Colors.Gray);
                SpnlMessages.Children.Add(name);

                DrawingView ImgDV = new DrawingView(DrawingIMG);
                SpnlMessages.Children.Add(ImgDV);

                // Add Sent At Time:
                TextBlock text = new TextBlock();
                text.FontSize = 10;
                text.Text = "Sent at " + DateTime.Now.ToString();
                text.TextWrapping = TextWrapping.Wrap;
                SpnlMessages.Children.Add(text);
                SetScrollBarToBottom();

            }
            catch { }
        }
        private void SmileyCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (SmileyCombo != null)
                if (SmileyCombo.SelectedIndex != 0)
                {
                    SmileySendBTN.Visibility = System.Windows.Visibility.Visible;
                }
                else SmileySendBTN.Visibility = System.Windows.Visibility.Collapsed;
        }

        private void cmbFontColors_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (cmbFontColors != null)
            {
                MsgColor = cmbFontColors.SelectedIndex.ToString();
                switch (MsgColor)
                {
                    case "0":
                        {
                            MesgSendTextbox.Foreground = new SolidColorBrush(Colors.Black);
                        }
                        break;
                    case "1":
                        {
                            MesgSendTextbox.Foreground = new SolidColorBrush(Colors.Red);
                        }
                        break;
                    case "2":
                        {
                            MesgSendTextbox.Foreground = new SolidColorBrush(Colors.Green);
                        }
                        break;
                    case "3":
                        {
                            MesgSendTextbox.Foreground = new SolidColorBrush(Colors.Blue);
                        }
                        break;
                }

            }
        }

        private void SendRichBTN_Click(object sender, RoutedEventArgs e)
        {
            string MsgFormat = MsgColor + MsgBold + MsgItalic;
            SendTextMessage(MsgFormat + MesgSendTextbox.Text);
        }
        private void SendTextMessage(string TXTMSG)
        {
                try
                {
                    if (TXTMSG.Length > 3)
                    {
                        AddMSGToChatList(UserName, TalkingWith, TXTMSG);
                        WcsTxtPacket packet = Packetizer.GetObject(TalkingWith, UserName, RoomID, TXTMSG, TXTPayloadType.TxtMsg, IsPublic);
                        SendTextClicked(packet, null);
                    }
                }
                catch { }

                MesgSendTextbox.SelectAll();
                MesgSendTextbox.Text = "";
                MesgSendTextbox.Focus();
        }
        private void MesgSendTextbox_KeyDown(object sender, KeyEventArgs e)
        {
            if (MesgSendTextbox != null)
            {
                if (e.Key == Key.Enter & SendRichBTN.IsEnabled & IsEnterToSend.IsChecked == true)
                {
                    e.Handled = true;
                    string MsgFormat = MsgColor + MsgBold + MsgItalic;
                    SendTextMessage(MsgFormat + MesgSendTextbox.Text);
                }
                else
                    if (MesgSendTextbox.Text.Length > 100)
                        e.Handled = true;
                    else e.Handled = false;
            }
        }

        private void SmileySendBTN_Click(object sender, RoutedEventArgs e)
        {
            if (SmileyCombo.SelectedIndex != 0)
            {
                System.Windows.Controls.Image Smiley = (System.Windows.Controls.Image)SmileyCombo.SelectedValue;
                SendTextMessage(SmileyFlag + Smiley.Tag);
            }
            else SmileySendBTN.Visibility = System.Windows.Visibility.Collapsed;
        }
        private void btnBold_Click(object sender, RoutedEventArgs e)
        {
            if (MsgBold == "1")
            {
                MsgBold = "0";
                MesgSendTextbox.FontWeight = FontWeights.Normal;
            }

            else if (MsgBold == "0")
            {
                MsgBold = "1";
                MesgSendTextbox.FontWeight = FontWeights.Bold;
            }

        }

        private void btnItalic_Click(object sender, RoutedEventArgs e)
        {
            if (MsgItalic == "1")
            {
                MsgItalic = "0";
                MesgSendTextbox.FontStyle = FontStyles.Normal;
            }

            else if (MsgItalic == "0")
            {
                MsgItalic = "1";
                MesgSendTextbox.FontStyle = FontStyles.Italic;
            }
        }

        private void DrawingCheckbox_Checked(object sender, RoutedEventArgs e)
        {
            if (DrawingCheckbox.IsChecked == true)
            {
                DrawingArea.AllowUsingWB = true;
                TypingCheckbox.Visibility = System.Windows.Visibility.Visible;
                DrawingArea.Visibility = System.Windows.Visibility.Visible;
                TextChatPN.Visibility = System.Windows.Visibility.Collapsed;
                TxtTypingArea.Visibility = System.Windows.Visibility.Collapsed;
                SvwrMessages.Height = 145;
                DrawingArea.Clear(false);
            }
            else if (TypingCheckbox.IsChecked == true) 
            {
                TypingCheckbox.Visibility = System.Windows.Visibility.Collapsed;
                DrawingArea.Visibility = System.Windows.Visibility.Collapsed;
                TextChatPN.Visibility = System.Windows.Visibility.Visible;
                TxtTypingArea.Visibility = System.Windows.Visibility.Visible;
                SvwrMessages.Height = 220;
            }

            TypingCheckbox.IsChecked = false;
            DrawingCheckbox.IsChecked = false;
        }


        void DrawingDecoder(object sender, DoWorkEventArgs e)
        {
            WcsBinaryPacket RD = (WcsBinaryPacket)e.Argument;

            if (RD.DataBuffer != null)
            {
                ReceivedStream rbm = new ReceivedStream();
                rbm.DataStream = ImageEcoderDecoder.Decoder(RD.DataBuffer, true);
                rbm.SentFrom = RD.UserName;
                rbm.SentTo = RD.To;
                Deployment.Current.Dispatcher.BeginInvoke(() =>
                {
                    ViewReceivedDrawingImage(rbm);
                });
            }
        }

        private void ViewReceivedDrawingImage(ReceivedStream rbm)
        {
            try
            {
                if (rbm.DataStream != null)
                {
                    BitmapImage bi = new BitmapImage();
                    bi.SetSource(rbm.DataStream);
                    AddDrawingToChatList(rbm.SentFrom, rbm.SentTo, bi);
                }
            }
            catch { }
        }

        void DrawingEncoder(object sender, DoWorkEventArgs e)
        {
            try
            {
                byte[] buffer = ImageEcoderDecoder.PngEncoder((ExtendedImage)e.Argument,true);
                
                    if (buffer.Length > 0)
                    {
                        WcsBinaryPacket packet = Packetizer.GetObject(TalkingWith, UserName, RoomID, buffer, BinaryPayloadType.Drawing, true, IsPublic);
                        
                        DrawingDecoderThread.RunWorkerAsync(packet);

                        if (SendDrawingClicked != null)
                            SendDrawingClicked(packet,null);
                    }
            }
            catch { }
        }

        private void SendDrawingBTN_Click(object sender, EventArgs e)
        {
            DrawingEncodrThread.RunWorkerAsync(DrawingArea.Read_WB().ToImage());
        }

    }
}
