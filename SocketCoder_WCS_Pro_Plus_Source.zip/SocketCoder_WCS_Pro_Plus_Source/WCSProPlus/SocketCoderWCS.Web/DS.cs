﻿namespace SocketCoderWCS.Web {
    
    
    public partial class DS {
    }
}
