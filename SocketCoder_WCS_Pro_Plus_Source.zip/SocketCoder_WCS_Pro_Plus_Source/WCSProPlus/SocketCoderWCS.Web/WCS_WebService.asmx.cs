﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Data;
using System.Collections;
using System.Text;
using System.Security.Cryptography;
using System.IO;

namespace SocketCoderWCS.Web
{
    /// <summary>
    /// Summary description for WCS_Main_Service
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class WCS_Main_Service : System.Web.Services.WebService
    {
        private string WCSVersion = "4.0.0.0";

        #region Secuirty

        private const string SalatKey = "SO54454eAsxcv545404588R5T6z";

        private string GeneratePasswordHashCode(string password)
        {
            try
            {
                using (SHA1Managed sha1 = new SHA1Managed())
                {
                    byte[] DataBytes = System.Text.UTF8Encoding.Unicode.GetBytes(password + SalatKey);
                    var hash = sha1.ComputeHash(DataBytes);
                    return Convert.ToBase64String(hash);
                }
            }
            catch { return ""; }
        }

        private bool CheckPasswordHashCode(string password, string GeneratedCode)
        {
            try
            {
                string NewCode = GeneratePasswordHashCode(password);
                if (NewCode == GeneratedCode) return true; else return false;
            }
            catch { return false; }
        }

        private string base64Encode(string data)
        {
            try
            {
                byte[] encData_byte = new byte[data.Length];
                encData_byte = System.Text.Encoding.UTF8.GetBytes(data);
                string encodedData = Convert.ToBase64String(encData_byte);
                return encodedData;
            }
            catch
            {
                return "";
            }
        }

        private string base64Decode(string data)
        {
            try
            {
                System.Text.UTF8Encoding encoder = new System.Text.UTF8Encoding();
                System.Text.Decoder utf8Decode = encoder.GetDecoder();

                byte[] todecode_byte = Convert.FromBase64String(data);
                int charCount = utf8Decode.GetCharCount(todecode_byte, 0, todecode_byte.Length);
                char[] decoded_char = new char[charCount];
                utf8Decode.GetChars(todecode_byte, 0, todecode_byte.Length, decoded_char, 0);
                string result = new String(decoded_char);
                return result;
            }
            catch
            {
                return "";
            }
        }

        #endregion Secuirty

        #region WCS Web Service

        DSTableAdapters.QueriesTableAdapter qu = new DSTableAdapters.QueriesTableAdapter();
        DSTableAdapters.WCS_RoomsTableAdapter rooms = new DSTableAdapters.WCS_RoomsTableAdapter();
        DSTableAdapters.RolesTableAdapter roles = new DSTableAdapters.RolesTableAdapter();
        DSTableAdapters.WCS_RoomsPermissionsTableAdapter RoomRoles = new DSTableAdapters.WCS_RoomsPermissionsTableAdapter();
        DSTableAdapters.WCS_BanUsersTableAdapter BanList = new DSTableAdapters.WCS_BanUsersTableAdapter();
        DSTableAdapters.WCS_ContentsTableAdapter RoomContents = new DSTableAdapters.WCS_ContentsTableAdapter();

        // Version
        [WebMethod]
        public bool CheckVersion(string Version)
        {
            if (Version == WCSVersion) return true;
            else return false;
        }

        // Room ID Control
        [WebMethod]
        public string GetRoomIDByRoomTitle(string RoomTitle)
        {
                try
                {
                    return qu.GetRoomIDByRoomTitle(RoomTitle);
                }
                catch (Exception ex) { return ex.Message; }
        }

        [WebMethod]
        public string GetRoomTitleByRoomID(string RoomID)
        {
            try
            {
                return qu.GetRoomTitleByRoomID(RoomID);
            }
            catch (Exception ex) { return ex.Message; }
        }

        // Rooms Control
        [WebMethod]
        public ArrayList Get_Rooms_List(string UserRole)
        {
            System.Collections.ArrayList arr = new System.Collections.ArrayList();
            DS.WCS_RoomsDataTable RoomsTable = new DS.WCS_RoomsDataTable();
            try
            {
                rooms.GetRoomsByUserID(RoomsTable, UserRole);
                foreach (DataRow RoomTitle in RoomsTable.Rows)
                {
                    if (!arr.Contains(RoomTitle))
                    arr.Add(RoomTitle["RoomTitle"].ToString());
                }

                rooms.GetRoomsByAdminRole(RoomsTable, UserRole);
                foreach (DataRow RoomTitle in RoomsTable.Rows)
                {
                    if (!arr.Contains(RoomTitle))
                    arr.Add(RoomTitle["RoomTitle"].ToString());
                }
            }
            catch { }
            return arr;
        }

        [WebMethod]
        public ArrayList Get_AllRoomsNames()
        {
            System.Collections.ArrayList arr = new System.Collections.ArrayList();
            DS.WCS_RoomsDataTable RoomsTable = new DS.WCS_RoomsDataTable();
            try
            {
                rooms.GetAllRooms(RoomsTable);
                foreach (DataRow RoomTitle in RoomsTable.Rows)
                {
                    if (!arr.Contains(RoomTitle))
                        arr.Add(RoomTitle["RoomTitle"].ToString());
                }
            }
            catch { }
            return arr;
        }

        [WebMethod]
        public ArrayList Get_Roles_List()
        {
            System.Collections.ArrayList arr = new System.Collections.ArrayList();
            DS.RolesDataTable RolesTable = new DS.RolesDataTable();
            try
            {
                roles.GetRoles(RolesTable);
                foreach (DataRow RoomTitle in RolesTable.Rows)
                {
                    if (!arr.Contains(RoomTitle))
                        arr.Add(RoomTitle["RoleName"].ToString());
                }

            }
            catch { }
            return arr;
        }

        [WebMethod]
        public string CreateRoom(string RoomTitle, string UserRole, string AdminRole,bool IsLoginRequired,int MaxUsersNumber, bool PrivateChatWindow, bool TextChatWindow, bool VideoChatWindow, bool VoiceChatWindow, bool PresentationWindow, bool WhiteboardWindow, bool FilesSharingWindow, bool UsersListWindow, string WebServiceHashCode)
        {
            if (WebServiceHashCode == GeneratePasswordHashCode(RoomTitle.Length.ToString()))
                try
                {
                    if (qu.IsRoomTitleExist(RoomTitle) ==0)
                    {
                        string RoomID = Guid.NewGuid().ToString();
                        qu.AddRoom(RoomID, AdminRole, UserRole, RoomTitle);
                        qu.AddNewRoomPermissions(RoomID, UserRole, TextChatWindow, VideoChatWindow, VoiceChatWindow, WhiteboardWindow, FilesSharingWindow, MaxUsersNumber);
                        qu.AddNewRoomPermissions(RoomID, AdminRole, TextChatWindow, VideoChatWindow, VoiceChatWindow, WhiteboardWindow, FilesSharingWindow, 0);
                        qu.AddRoomContents(RoomID, PrivateChatWindow, TextChatWindow, VideoChatWindow, VoiceChatWindow, PresentationWindow, WhiteboardWindow, FilesSharingWindow, UsersListWindow, IsLoginRequired);
                        return  "*"+ RoomID;
                    }
                    else return "This room is already exist!";
                }
                catch { return "Unexpected ERR"; }
            else return "user not identified";
        }

        [WebMethod]
        public string UpdateRoomContents(string RoomTitle, bool IsLoginRequired, bool PrivateChatWindow, bool TextChatWindow, bool VideoChatWindow, bool VoiceChatWindow, bool PresentationWindow, bool WhiteboardWindow, bool FilesSharingWindow, bool UsersListWindow, string WebServiceHashCode)
        {
            if (WebServiceHashCode == GeneratePasswordHashCode(RoomTitle.Length.ToString()))
                try
                {
                    string RoomID = GetRoomIDByRoomTitle(RoomTitle);
                    qu.UpdateRoomContents(PrivateChatWindow, TextChatWindow, VideoChatWindow, VoiceChatWindow, PresentationWindow, WhiteboardWindow, FilesSharingWindow, UsersListWindow, IsLoginRequired, RoomID);
                    return "Done";
                }
                catch (Exception ex) { return ex.Message; }
            else return "not identified user";
        }

        [WebMethod]
        public string UpdateRoomRole(string RoomTitle,string NewRoomTitle, string NewUserRole, string NewAdminRole, string WebServiceHashCode)
        {
            if (WebServiceHashCode == GeneratePasswordHashCode(RoomTitle.Length.ToString()))
                try
                {
                    string RoomID = GetRoomIDByRoomTitle(RoomTitle);
                    qu.UpdateRoomRole(NewAdminRole, NewUserRole, NewRoomTitle, RoomID);
                    return "Done";
                }
                catch (Exception ex) { return ex.Message; }
            else return "not identified user";
        }

        [WebMethod]
        public string UpdateRoomPermissions(string RoomTitle, string UserRole, bool AllowText, bool AllowVoice, bool AllowVideo, bool AllowFiles, bool AllowWB, int MaxUsersNumber, string WebServiceHashCode)
        {
            if (WebServiceHashCode == GeneratePasswordHashCode(RoomTitle.Length.ToString()))
                try
                {
                    string RoomID = GetRoomIDByRoomTitle(RoomTitle);
                    qu.UpdateRoomsPermissions(AllowText, AllowVideo, AllowVoice, AllowWB, AllowFiles, MaxUsersNumber, RoomID, UserRole);

                    return "Done";
                }
                catch (Exception ex) { return ex.Message; }
            else return "not identified user";
        }

        [WebMethod]
        public string UpdateRoomRole_With_Contents(string RoomTitle, string NewRoomTitle, string NewUserRole, string NewAdminRole, bool LoginIsRequired, bool PrivateChatWindow, bool TextChatWindow, bool VideoChatWindow, bool VoiceChatWindow, bool PresentationsWindow, bool WB_Window, bool Files_Sharing_Window, bool OnlineUsers_Window, string WebServiceHashCode)
        {
            if (WebServiceHashCode == GeneratePasswordHashCode(RoomTitle.Length.ToString()))
                try
                {
                    string RoomID = GetRoomIDByRoomTitle(RoomTitle);
                    qu.UpdateRoomRole(NewAdminRole, NewUserRole, NewRoomTitle, RoomID);
                    qu.UpdateRoomContents(PrivateChatWindow, TextChatWindow, VideoChatWindow, VoiceChatWindow, PresentationsWindow, WB_Window, Files_Sharing_Window, OnlineUsers_Window, LoginIsRequired, RoomID);
                    return "Done";
                }
                catch (Exception ex) { return ex.Message; }
            else return "not identified user";
        }

        [WebMethod]
        public string RemoveRoom(string RoomTitle,string WebServiceHashCode)
        {
            if (WebServiceHashCode == GeneratePasswordHashCode(RoomTitle.Length.ToString()))
                try
                {
                    string RoomID = GetRoomIDByRoomTitle(RoomTitle);
                    qu.DeleteRoomPermissions(RoomID);
                    qu.DeleteRoom(RoomID);
                    qu.DeleteRoomContent(RoomID);

                    return "Done";
                }
                catch (Exception ex) { return ex.Message; }
            else return "not identified user";
        }

        [WebMethod]
        public ArrayList GetRolePermission(string RoomTitle, string RoleName)
        {
            string RoomID = GetRoomIDByRoomTitle(RoomTitle);
            System.Collections.ArrayList arr = new System.Collections.ArrayList();

            DS.WCS_RoomsPermissionsDataTable RoomPermissionTable = new DS.WCS_RoomsPermissionsDataTable();

            try
            {
                RoomRoles.GetRoomPermission(RoomPermissionTable, RoomID, RoleName);
                arr.Add(RoomPermissionTable.Rows[0]["AllowText"].ToString());
                arr.Add(RoomPermissionTable.Rows[0]["AllowVideo"].ToString());
                arr.Add(RoomPermissionTable.Rows[0]["AllowVoice"].ToString());
                arr.Add(RoomPermissionTable.Rows[0]["AllowWhiteboard"].ToString());
                arr.Add(RoomPermissionTable.Rows[0]["AllowFilesSharing"].ToString());
                arr.Add(RoomPermissionTable.Rows[0]["MaxUsers"].ToString());
            }
            catch { }

            return arr;
        }

        [WebMethod]
        public ArrayList GetRoomContents(string RoomTitle)
        {
            string RoomID = GetRoomIDByRoomTitle(RoomTitle);
            System.Collections.ArrayList arr = new System.Collections.ArrayList();
            DS.WCS_ContentsDataTable RoomContentsTable = new DS.WCS_ContentsDataTable();
            DS.WCS_RoomsDataTable RoomsTable = new DS.WCS_RoomsDataTable();
            try
            {
                RoomContents.GetRoomContents(RoomContentsTable, RoomID);
                rooms.GetRoomRoles(RoomsTable, RoomID);


                arr.Add(RoomContentsTable.Rows[0]["PrivateChatWindow"].ToString());
                arr.Add(RoomContentsTable.Rows[0]["TextChatWindow"].ToString());
                arr.Add(RoomContentsTable.Rows[0]["VideoChatWindow"].ToString());
                arr.Add(RoomContentsTable.Rows[0]["VoiceChatWindow"].ToString());
                arr.Add(RoomContentsTable.Rows[0]["PresentationWindow"].ToString());
                arr.Add(RoomContentsTable.Rows[0]["WhiteboardWindow"].ToString());
                arr.Add(RoomContentsTable.Rows[0]["FilesSharingWindow"].ToString());
                arr.Add(RoomContentsTable.Rows[0]["UsersListWindow"].ToString());
                arr.Add(RoomContentsTable.Rows[0]["LgoinIsRequired"].ToString());

                arr.Add(RoomsTable.Rows[0]["AdminRole"].ToString());
                arr.Add(RoomsTable.Rows[0]["UserRole"].ToString());

            }
            catch { }

            return arr;
        }

        [WebMethod]
        public string GetMaxUsersInARoom(string RoomTitle)
        {
            string RoomID = GetRoomIDByRoomTitle(RoomTitle);
            DS.WCS_RoomsPermissionsDataTable RoomPermissionTable = new DS.WCS_RoomsPermissionsDataTable();
            try
            {
                RoomRoles.GetRoomPermission(RoomPermissionTable, RoomID, qu.GetRoomUserRole(RoomTitle).ToString());
                return RoomPermissionTable.Rows[0]["MaxUsers"].ToString();
            }
            catch { return "0"; }
        }

        [WebMethod]
        public ArrayList GetRoomRoles(string RoomTitle)
        {
            string RoomID = GetRoomIDByRoomTitle(RoomTitle);
            System.Collections.ArrayList arr = new System.Collections.ArrayList();

            DS.WCS_RoomsPermissionsDataTable RoomPermissionTable = new DS.WCS_RoomsPermissionsDataTable();

            try
            {

                RoomRoles.GetRoomRoles(RoomPermissionTable, RoomID);

                foreach (DataRow Room_Title in RoomPermissionTable.Rows)
                {
                    if (!arr.Contains(Room_Title))
                        arr.Add(Room_Title["UserRole"].ToString());
                }
            }
            catch { }

            return arr;
        }

        [WebMethod]
        public bool CheckIfARoomAdmin(string UserRole, string RoomTitle)
        {
            try
            {
                string RoomID = GetRoomIDByRoomTitle(RoomTitle);
                int IsAdmin = (int)qu.CheckIfARoomAdmin(RoomID, UserRole);
                if (IsAdmin > 0) return true;
                else return false;
            }
            catch { return false; }
        }

        // Ban List Control
        [WebMethod]
        public string Ban_A_User_or_IP(string UserIdOrIP,bool IsItIP ,string WebServiceHashCode)
        {
            if (WebServiceHashCode == GeneratePasswordHashCode(UserIdOrIP.Length.ToString()))
                try
                {
                    if (IsItIP)
                    {
                        qu.BanIPAddress(UserIdOrIP);
                    }
                    else
                    {
                        qu.BanUserName(UserIdOrIP);
                    }

                    return "Done";
                }
                catch (Exception ex) { return ex.Message; }
            else return "not identified user";
        }

        [WebMethod]
        public string Remove_Banned_User_or_IP(string UserIdOrIP, bool IsItIP, string WebServiceHashCode)
        {
            if (WebServiceHashCode == GeneratePasswordHashCode(UserIdOrIP.Length.ToString()))
                try
                {
                    if (IsItIP)
                    {
                        qu.RemoveBanIPAddress(UserIdOrIP);
                    }
                    else
                    {
                        qu.RemoveBanUserName(UserIdOrIP);
                    }

                    return "Done";
                }
                catch (Exception ex) { return ex.Message; }
            else return "not identified user";
        }

        [WebMethod]
        public ArrayList GetBanUsersList(string WebServiceHashCode)
        {
            if (WebServiceHashCode == GeneratePasswordHashCode(SalatKey))
            {
                System.Collections.ArrayList arr = new System.Collections.ArrayList();
                DS.WCS_BanUsersDataTable BanListTable = new DS.WCS_BanUsersDataTable();
                try
                {
                    BanList.Fill(BanListTable);

                    foreach (DataRow FileName in BanListTable.Rows)
                    {
                        arr.Add(FileName["ByUserName"].ToString());
                    }

                }
                catch { }

                return arr;
            }
            else return new ArrayList();
        }

        [WebMethod]
        public ArrayList GetBanIPList(string WebServiceHashCode)
        {
            if (WebServiceHashCode == GeneratePasswordHashCode(SalatKey))
            {
                System.Collections.ArrayList arr = new System.Collections.ArrayList();
                DS.WCS_BanUsersDataTable BanListTable = new DS.WCS_BanUsersDataTable();
                try
                {
                    BanList.Fill(BanListTable);

                    foreach (DataRow FileName in BanListTable.Rows)
                    {
                        arr.Add(FileName["ByIPAddress"].ToString());
                    }

                }
                catch { }

                return arr;
            }
            else return new ArrayList();
        }

        [WebMethod]
        public string GetMyIP()
        {
            try
            {
                return Context.Request.ServerVariables["REMOTE_ADDR"].ToString();
            }
            catch { return "0.0.0.0"; }
        }

        [WebMethod]
        public bool Check_If_Banned_User(string UserName)
        {
                try
                {
                    int IsBan = 0;
                    string IPAddress = Context.Request.ServerVariables["REMOTE_ADDR"].ToString();
                    IsBan = (int)qu.IsBanByIPAddress(IPAddress);
                    if (IsBan != 0) return true;
                    else
                    {
                        IsBan = (int)qu.IsBanByUserName(UserName);
                        if (IsBan != 0) return true;
                        else return false;
                    }

                }
                catch { return false; }
        }

        // Log Events Control
        [WebMethod]
        public bool AddLogEvent(string UserName, string RoomTitle, string EventType,string EventMSG, string WebServiceHashCode)
        {
            if (WebServiceHashCode == GeneratePasswordHashCode(RoomTitle.Length.ToString()))
                try
                {
                    string RoomID = GetRoomIDByRoomTitle(RoomTitle);
                    qu.InsertUserEvent(RoomID, UserName, EventType, EventMSG, DateTime.Now);
                    return true;
                }
                catch { return false; }
            else return false;
        }
        #endregion  WCS Web Service

    }
}
