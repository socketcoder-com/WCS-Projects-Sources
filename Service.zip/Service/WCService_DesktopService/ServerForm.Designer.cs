namespace SocketCoder_WCService
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.EventslistBox = new System.Windows.Forms.ListBox();
            this.Conncet = new System.Windows.Forms.Button();
            this.button_shutdown = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.SelfHostHttpCheckBox = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // EventslistBox
            // 
            this.EventslistBox.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EventslistBox.FormattingEnabled = true;
            this.EventslistBox.HorizontalScrollbar = true;
            this.EventslistBox.Location = new System.Drawing.Point(3, 50);
            this.EventslistBox.Name = "EventslistBox";
            this.EventslistBox.Size = new System.Drawing.Size(437, 43);
            this.EventslistBox.TabIndex = 10;
            // 
            // Conncet
            // 
            this.Conncet.Location = new System.Drawing.Point(7, 8);
            this.Conncet.Name = "Conncet";
            this.Conncet.Size = new System.Drawing.Size(308, 36);
            this.Conncet.TabIndex = 7;
            this.Conncet.Text = "Start The Server";
            this.Conncet.UseVisualStyleBackColor = true;
            this.Conncet.Click += new System.EventHandler(this.Conncet_Click);
            // 
            // button_shutdown
            // 
            this.button_shutdown.Enabled = false;
            this.button_shutdown.Location = new System.Drawing.Point(321, 8);
            this.button_shutdown.Name = "button_shutdown";
            this.button_shutdown.Size = new System.Drawing.Size(118, 36);
            this.button_shutdown.TabIndex = 19;
            this.button_shutdown.Text = "Shutdown";
            this.button_shutdown.UseVisualStyleBackColor = true;
            this.button_shutdown.Click += new System.EventHandler(this.button_shutdown_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(5, 128);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(434, 13);
            this.label2.TabIndex = 20;
            this.label2.Text = "Notice: We recommend to install the SocketCoder_WCService.MainService for product" +
    "ion";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(50, 145);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(336, 13);
            this.label3.TabIndex = 21;
            this.label3.Text = "The WCService_DesktopService is just for testing while development";
            // 
            // SelfHostHttpCheckBox
            // 
            this.SelfHostHttpCheckBox.AutoSize = true;
            this.SelfHostHttpCheckBox.Checked = true;
            this.SelfHostHttpCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.SelfHostHttpCheckBox.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SelfHostHttpCheckBox.Location = new System.Drawing.Point(7, 99);
            this.SelfHostHttpCheckBox.Name = "SelfHostHttpCheckBox";
            this.SelfHostHttpCheckBox.Size = new System.Drawing.Size(322, 17);
            this.SelfHostHttpCheckBox.TabIndex = 22;
            this.SelfHostHttpCheckBox.Text = "Self Host ClientAccessPolicy.xml File on HTTP Port 80";
            this.SelfHostHttpCheckBox.UseVisualStyleBackColor = true;
            this.SelfHostHttpCheckBox.CheckedChanged += new System.EventHandler(this.SelfHostHttpCheckBox_CheckedChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(443, 165);
            this.Controls.Add(this.SelfHostHttpCheckBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button_shutdown);
            this.Controls.Add(this.EventslistBox);
            this.Controls.Add(this.Conncet);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SocketCoder Web Conferencing Server ";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox EventslistBox;
        private System.Windows.Forms.Button Conncet;
        private System.Windows.Forms.Button button_shutdown;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox SelfHostHttpCheckBox;
    }
}

