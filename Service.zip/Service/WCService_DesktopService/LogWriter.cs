﻿//
//                      (C) SocketCoder.Com 2014
//
using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace SocketCoder_WCService
{
    internal class LogWriter
    {
        public static string CurrentLogFile
        {
            get
            {
                string logfile = AppDomain.CurrentDomain.BaseDirectory + "logfile_" + ((int)DateTime.Now.DayOfWeek).ToString() + ".log";
                return logfile;
            }
        }

        public static void WriteLog(string scope, string content)
        {
            try
            {
                StreamWriter sw = new StreamWriter(LogWriter.CurrentLogFile, true, Encoding.UTF8);
                sw.WriteLine(DateTime.Now.ToString() + "\r\n");
                sw.WriteLine(scope + "\r\n");
                sw.WriteLine(content + "\r\n\r\n");
                sw.Close();
            }
            catch(Exception){}
        }
    }
}
