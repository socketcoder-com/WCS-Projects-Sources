﻿// (C) SocketCoder.Com 
// WCS/WMS Web Conferencing Server
// Last Modify: 17/Aug/2014

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.IO;
using System.ServiceModel.Web;
using System.Threading;
using SocketCoder_WCService;
using System.Collections;
using MediaStreaming;

#region Policy Access Interface
[ServiceContract]
public interface ITcpPolicyRetriever
{
    [OperationContract, WebGet(UriTemplate = "/clientaccesspolicy.xml")]
    Stream GetSilverlightPolicy();
}
#endregion Policy Access Interface

#region Service Callback Interface
[ServiceContract]
public interface IVideoConferenceServiceCallback
{
    [OperationContract(IsOneWay = true)]
    void OnVideoSend(WcsBinaryPacket BinaryPacket);

    [OperationContract(IsOneWay = true)]
    void OnVoiceSend(WcsAudioPacket AudioPacket);

    [OperationContract(IsOneWay = true)]
    void OnTextSend(WcsTxtPacket TxtPacket);

    [OperationContract(IsOneWay = true)]
    void OnSyncUsersList(Dictionary<string, UserInfoPacket> UsersList);

    [OperationContract(IsOneWay = true)]
    void OnCMDSend(WcsPresenterCMDPacket TxtPacket);

    [OperationContract(IsOneWay = true)]
    void OnSubscribeUserPermissions(GlobalUserPermissions GlobalPermissions);

    [OperationContract(IsOneWay = true)]
    void OnDrawingSend(WcsBinaryPacket BinaryPacket);

    [OperationContract(IsOneWay = true)]
    void OnCollaborativeBoardSync(byte[] DataInBytes, string ControlType,string DrawingFrom);

    [OperationContract(IsOneWay = true)]
    void OnDesktopSend(WcsBinaryPacket BinaryPacket);

    [OperationContract(IsOneWay = true)]
    void OnFileUploaded(List<WcsFilePacket> FilesListSync);

}
#endregion Service Callback Interface

#region Main Service Interface
[ServiceContract(Namespace = "SocketCoderWCS", CallbackContract = typeof(IVideoConferenceServiceCallback), SessionMode = SessionMode.Allowed)]
public interface IVideoConferenceService
{
    [OperationContract]
    IssueStatus Subscribe(UserInfoPacket UPacket, RoomInfoPacket URoom);

    [OperationContract]
    void UnSubscribe(WcsTxtPacket TxTPacket);

    [OperationContract]
    void PublishText(WcsTxtPacket TxTPacket);

    [OperationContract]
    IssueStatus SendCMD(WcsTxtPacket TxTPacket);

    [OperationContract]
    IssueStatus SendPresenterCMD(WcsPresenterCMDPacket packet, GlobalUserPermissions global);

    [OperationContract]
    void PublishVideo(WcsBinaryPacket BinartPacket);

    [OperationContract]
    void PublishVoice(WcsAudioPacket AudioPacket);

    [OperationContract]
    void PublishDrawing(WcsBinaryPacket BinartPacket);

    [OperationContract]
    void CollaborativeBoardSync(WcsBinaryPacket packet, string ControlType);

    [OperationContract]
    void PublishDesktop(WcsBinaryPacket BinartPacket);

    [OperationContract]
    void UploadFile(WcsFilePacket FilePacket);

    [OperationContract]
    WcsFilePacket DownloadFile(WcsFilePacket FileID);

    [OperationContract]
    void RemoveFile(WcsFilePacket WcsFileInfo);

    [OperationContract]
    void SynchronizeFilesList(WcsFilePacket UserRoomInfo);

    int MaxFileSize
    {
        [OperationContract]
        get;
    }
}
#endregion Main Service Interface

[ServiceBehavior(ConcurrencyMode = ConcurrencyMode.Multiple, InstanceContextMode = InstanceContextMode.PerSession)]
public class VideoConferenceService : IVideoConferenceService, ITcpPolicyRetriever
{
    private string ServiceName = "WCS Service";
    private string LastVersion = "4.0.0.0";

    private static Dictionary<string, ArrayList> OnlineUsers = new Dictionary<string, ArrayList>(); // Key = RoomID
    private static Dictionary<string, RoomInfoPacket> OnlineRooms = new Dictionary<string, RoomInfoPacket>(); // Key = RoomID
    public static Dictionary<string, WcsFilePacket> UploadedFilesDictionary = new Dictionary<string, WcsFilePacket>(); // Key = FileID
    public static Dictionary<string, GlobalUserPermissions> GlobalRoomPermissions = new Dictionary<string, GlobalUserPermissions>(); // Key = RoomID
    public static Dictionary<string, ArrayList> BlockedUsersList = new Dictionary<string, ArrayList>(); // Key = RoomID , value= UserName 

    private WcsPacketizer Packetizer = new WcsPacketizer();

    #region Internal Classes

    internal class UserInfo
    {
        public string RoomID { get; set; }
        public string UserName { get; set; }
        public UserInRole Role;
        public UserType UType;
        public string AvatarID { get; set; }

        public IVideoConferenceServiceCallback UserSocket { get; set; }

        public UserInfo(string Room_ID, string User_Name, string Avatar_ID, UserInRole User_Role, UserType User_Type, IVideoConferenceServiceCallback User_Socket)
        {
            UType = User_Type;
            Role = User_Role;
            RoomID = Room_ID;
            AvatarID = Avatar_ID;
            UserName = User_Name;
            UserSocket = User_Socket;
        }
    }

    #endregion Internal Classes

    #region Online Rooms/Users Service

    public IssueStatus Subscribe(UserInfoPacket UPacket, RoomInfoPacket URoom)
    {
        try
        {
            if (Packetizer.CheckCheckSum(UPacket) & Packetizer.CheckCheckSum(URoom) & UPacket.UserName != ServiceName)
            {

                UserInfo subscriber = new UserInfo(UPacket.RoomID, UPacket.UserName, UPacket.AvatarID, UPacket.Role, UPacket.UType, OperationContext.Current.GetCallbackChannel<IVideoConferenceServiceCallback>());

                OperationContext.Current.Channel.Faulted += (s, e) =>
                {
                    RemoveSubscriber(subscriber);
                };

                OperationContext.Current.Channel.Closed += (s, e) =>
                {
                    RemoveSubscriber(subscriber);
                };

                // reject the user if he exist in the blocked list
                if (GetUserRole(UPacket.UserName, UPacket.RoomID) == UserInRole.Blocked)
                {
                    return IssueStatus.BlockedUser;
                }

                // reject the user if he use an older client version
                if (UPacket.AgentVersion != LastVersion.ToString())
                {
                    return IssueStatus.OldVersion;
                }

                if (OnlineUsers.ContainsKey(subscriber.RoomID))
                {
                    // reject the user if the room has the maximum number of online users
                    if (OnlineUsers[UPacket.RoomID].Count >= OnlineRooms[UPacket.RoomID].MaxUsers)
                    {

                        return IssueStatus.MaxUsersExceeded;
                    }

                    // reject the user if he exist on the same room using the same userid
                    var query = from UserInfo user in OnlineUsers[UPacket.RoomID].ToArray()
                                where user.UserName == UPacket.UserName
                                select user;
                    if (query.ToArray().Count() > 0)
                    {
                        return IssueStatus.UserIDAlreadyInUse;
                    }

                    OnlineUsers[subscriber.RoomID].Add(subscriber);
                }
                else
                {
                    // If the user is a first user who use this room id then register a new room id
                    OnlineRooms.Add(subscriber.RoomID, URoom);
                    OnlineUsers.Add(subscriber.RoomID, new ArrayList());

                    OnlineUsers[subscriber.RoomID].Add(subscriber);
                }

                try
                {
                    // Send Welcome MSG to the User
                    string MSG = "110" + "Welcome to Room " + UPacket.RoomID + " Joined At " + DateTime.Now.ToShortTimeString();
                    WcsTxtPacket WelcomeMSG = Packetizer.GetObject(UPacket.UserName, ServiceName, UPacket.RoomID, MSG, TXTPayloadType.TxtMsg, true);
                    subscriber.UserSocket.OnTextSend(WelcomeMSG);

                    if (GlobalRoomPermissions.ContainsKey(URoom.RoomID))
                    {
                        subscriber.UserSocket.OnSubscribeUserPermissions(GlobalRoomPermissions[URoom.RoomID]);
                    }

                    // Sync the users list
                    SynchronizeOnlineUsers(UPacket.RoomID);
                }
                catch { RemoveSubscriber(subscriber); }

                return IssueStatus.Done;
            }
            else return IssueStatus.NotValid;
        }
        catch (Exception ex) { LogWriter.WriteLog("OnSubscribe ", ex.Message); }

        return IssueStatus.Error;
    }

    public void UnSubscribe(WcsTxtPacket packet)
    {
        if (Packetizer.CheckCheckSum(packet) & packet.PayloadType == TXTPayloadType.UnSubscribe & packet.UserName != ServiceName)
        {
            if (OnlineUsers.ContainsKey(packet.RoomID))
                try
                {
                    foreach (UserInfo user in OnlineUsers[packet.RoomID].ToArray())
                    {
                        if (user.UserName == packet.UserName)
                            RemoveSubscriber(user);
                    }

                }
                catch { }
        }
    }

    private void SynchronizeOnlineUsers(string RoomID)
    {
        try
        {
            // Send The New Users List to the All Room Members
            if (OnlineUsers.ContainsKey(RoomID))
            {

                Dictionary<string, UserInfoPacket> TempUsersList = new Dictionary<string, UserInfoPacket>();
                foreach (UserInfo subscriber in OnlineUsers[RoomID].ToArray())
                {
                    TempUsersList.Add(subscriber.UserName, Packetizer.GetObject(subscriber.RoomID, subscriber.UserName, subscriber.AvatarID, subscriber.Role, subscriber.UType, LastVersion));
                }

                if (TempUsersList.Count > 0)
                {
                    if (OnlineUsers.ContainsKey(RoomID))
                        try
                        {
                            foreach (UserInfo subscriber in OnlineUsers[RoomID].ToArray())
                            {
                                try
                                {
                                    subscriber.UserSocket.OnSyncUsersList(TempUsersList);
                                }
                                catch
                                {
                                    if (OnlineUsers.ContainsKey(RoomID))
                                        OnlineUsers[subscriber.RoomID].Remove(subscriber);
                                }
                            }
                        }
                        catch { }
                }
            }

            // Remove the Empty Rooms and clear the cash files 
            foreach (KeyValuePair<string, ArrayList> room in OnlineUsers.ToArray())
            {
                if (room.Value.Count == 0)
                {
                    ClearUploadedFiles(room.Key);
                    OnlineUsers.Remove(room.Key);
                    OnlineRooms.Remove(room.Key);
                    GlobalRoomPermissions.Remove(room.Key);
                    BlockedUsersList.Remove(room.Key);
                }
            }
        }
        catch { }
    }

    private void RemoveSubscriber(UserInfo subscriber)
    {
        if (OnlineUsers.ContainsKey(subscriber.RoomID))
            try
            {
                OnlineUsers[subscriber.RoomID].Remove(subscriber);
                SynchronizeOnlineUsers(subscriber.RoomID);
            }
            catch { }
    }

    private bool IsUserInRole(string UserID, string RoomID, UserInRole UserRole)
    {
        try
        {
            var query = from UserInfo subscriber in OnlineUsers[RoomID].ToArray()
                        where subscriber.UserName == UserID
                        where subscriber.RoomID == RoomID
                        where subscriber.Role == UserRole
                        select subscriber.Role;

            if (query.ToArray().Length > 0) return true; else return false;
        }
        catch { return false; }
    }

    private UserInRole GetUserRole(string UserID, string RoomID)
    {
        try
        {
            if (BlockedUsersList.ContainsKey(RoomID))
            {
                if (BlockedUsersList[RoomID].Contains(UserID)) return UserInRole.Blocked;
            }

            var query = from UserInfo subscriber in OnlineUsers[RoomID].ToArray()
                        where subscriber.UserName == UserID
                        select subscriber.Role;

            foreach (UserInRole user in query.ToList())
            {
                return user;
            }

            return UserInRole.NotValid;
        }
        catch { return UserInRole.NotValid; }
    }

    #endregion Online Rooms/Users Service

    #region Text Service

    public void PublishText(WcsTxtPacket packet)
    {
        try
        {
            if (Packetizer.CheckCheckSum(packet) & packet.PayloadType == TXTPayloadType.TxtMsg & packet.UserName != ServiceName)
            {
                UserInRole role = GetUserRole(packet.UserName, packet.RoomID);
                if (role != UserInRole.NotValid & role != UserInRole.Blocked)

                    if (packet.IsPublic)
                    {
                        try
                        {
                            if (OnlineUsers.ContainsKey(packet.RoomID))
                                foreach (UserInfo subscriber in OnlineUsers[packet.RoomID].ToArray())
                                {
                                    if (packet.UserName != subscriber.UserName)
                                        try
                                        {
                                            subscriber.UserSocket.OnTextSend(packet);
                                        }
                                        catch { RemoveSubscriber(subscriber); }
                                }
                        }
                        catch { }
                    }
                    else
                    {
                        try
                        {
                            if (OnlineUsers.ContainsKey(packet.RoomID))
                            {
                                var query = from UserInfo subscriber in OnlineUsers[packet.RoomID].ToArray()
                                            where subscriber.UserName == packet.To
                                            select subscriber;

                                foreach (UserInfo subscriber in query.ToList())
                                {
                                    if (packet.UserName != subscriber.UserName)
                                        try
                                        {
                                            subscriber.UserSocket.OnTextSend(packet);
                                        }
                                        catch
                                        {
                                            RemoveSubscriber(subscriber);
                                        }
                                }
                            }
                        }
                        catch { }
                    }
            }
        }
        catch (Exception ex) { LogWriter.WriteLog("PublishText ", ex.Message); }
    }

    public IssueStatus SendCMD(WcsTxtPacket packet)
    {
        try
        {
            UserInRole role = GetUserRole(packet.UserName, packet.RoomID);
            if (role != UserInRole.NotValid & role != UserInRole.Blocked)
                if (Packetizer.CheckCheckSum(packet))
                    if (packet.UserName != ServiceName)
                        if (packet.PayloadType == TXTPayloadType.Cmd || packet.PayloadType == TXTPayloadType.CCall ||
                            packet.PayloadType == TXTPayloadType.CAccepted || packet.PayloadType == TXTPayloadType.CEnded ||
                            packet.PayloadType == TXTPayloadType.CRejected || packet.PayloadType == TXTPayloadType.CBusy)
                        {

                            if (packet.IsPublic)
                            {
                                foreach (UserInfo subscriber in OnlineUsers[packet.RoomID].ToArray())
                                {
                                    if (packet.UserName != subscriber.UserName)
                                        try
                                        {
                                            subscriber.UserSocket.OnTextSend(packet);
                                        }
                                        catch { RemoveSubscriber(subscriber); }
                                }
                            }
                            else
                            {
                                var query = from UserInfo subscriber in OnlineUsers[packet.RoomID].ToArray()
                                            where subscriber.UserName == packet.To
                                            select subscriber;

                                foreach (UserInfo subscriber in query.ToList())
                                {
                                    if (packet.UserName != subscriber.UserName)
                                        try
                                        {
                                            subscriber.UserSocket.OnTextSend(packet);
                                        }
                                        catch
                                        {
                                            RemoveSubscriber(subscriber);

                                        }
                                }
                            }

                            return IssueStatus.Done;
                        }
                        else if (packet.PayloadType == TXTPayloadType.Sync)
                        {

                        }
        }
        catch (Exception ex) { LogWriter.WriteLog("PublishText ", ex.Message); }
        return IssueStatus.NotValid;
    }

    public IssueStatus SendPresenterCMD(WcsPresenterCMDPacket packet, GlobalUserPermissions global)
    {
        try
        {
            UserInRole role = GetUserRole(packet.UserName, packet.RoomID);
            if (role == UserInRole.Presenter || role == UserInRole.RoomAdmin)
                if (Packetizer.CheckCheckSum(packet) & IsUserInRole(packet.UserName, packet.RoomID, UserInRole.Presenter))
                    if (packet.UserName != ServiceName & packet.PayloadType == TXTPayloadType.Cmd)
                        if (packet.Command == PresenterCMD.Allow_Cam_Sharing || packet.Command == PresenterCMD.Allow_Drawing || packet.Command == PresenterCMD.Allow_DesktopSharing ||
                            packet.Command == PresenterCMD.Allow_Files_Uploading || packet.Command == PresenterCMD.Allow_Mic_Sharing || packet.Command == PresenterCMD.KickOut ||
                            packet.Command == PresenterCMD.Allow_Text_Typing || packet.Command == PresenterCMD.Block || packet.Command == PresenterCMD.Clear
                            || packet.Command == PresenterCMD.Disallow_Cam_Sharing || packet.Command == PresenterCMD.Disallow_Drawing || packet.Command == PresenterCMD.Disallow_DesktopSharing ||
                            packet.Command == PresenterCMD.Disallow_Files_Uploading || packet.Command == PresenterCMD.Disallow_Mic_Sharing || packet.Command == PresenterCMD.Disallow_Text_Typing)
                        {

                            if (packet.IsPublic)
                            {
                                foreach (UserInfo subscriber in OnlineUsers[packet.RoomID].ToArray())
                                {
                                    if (packet.UserName != subscriber.UserName)
                                        try
                                        {
                                            subscriber.UserSocket.OnCMDSend(packet);
                                        }
                                        catch { RemoveSubscriber(subscriber); }

                                    if (GlobalRoomPermissions.ContainsKey(packet.RoomID)) GlobalRoomPermissions[packet.RoomID] = global;
                                    else GlobalRoomPermissions.Add(packet.RoomID, global);
                                }
                            }
                            else
                            {
                                if (packet.Command == PresenterCMD.KickOut || packet.Command == PresenterCMD.Block)
                                {
                                    if (BlockedUsersList.ContainsKey(packet.RoomID))
                                    {
                                        BlockedUsersList[packet.RoomID].Add(packet.To);
                                    }
                                    else
                                    {
                                        ArrayList ar = new ArrayList();
                                        ar.Add(packet.To);
                                        BlockedUsersList.Add(packet.RoomID, ar);
                                    }
                                }

                                var query = from UserInfo subscriber in OnlineUsers[packet.RoomID].ToArray()
                                            where subscriber.UserName == packet.To
                                            select subscriber;

                                foreach (UserInfo subscriber in query.ToList())
                                {
                                    if (packet.UserName != subscriber.UserName)
                                        try
                                        {
                                            subscriber.UserSocket.OnCMDSend(packet);
                                        }
                                        catch
                                        {
                                            RemoveSubscriber(subscriber);

                                        }
                                }

                            }

                            return IssueStatus.Done;
                        }
        }
        catch (Exception ex) { LogWriter.WriteLog("PublishText ", ex.Message); }

        return IssueStatus.NotValid;
    }

    #endregion Text Service

    #region Video Service
    public void PublishVideo(WcsBinaryPacket packet)
    {
        try
        {
            if (Packetizer.CheckCheckSum(packet) & packet.PayloadType == BinaryPayloadType.Video & packet.UserName != ServiceName)
            {
                UserInRole role = GetUserRole(packet.UserName, packet.RoomID);
                if (role != UserInRole.NotValid & role != UserInRole.Blocked)

                    if (packet.IsPublic)
                    {
                        try
                        {
                            if (OnlineUsers.ContainsKey(packet.RoomID))
                                foreach (UserInfo subscriber in OnlineUsers[packet.RoomID].ToArray())
                                {
                                    if (packet.UserName != subscriber.UserName)
                                        try
                                        {
                                            subscriber.UserSocket.OnVideoSend(packet);
                                        }
                                        catch { RemoveSubscriber(subscriber); }
                                }
                        }
                        catch { }
                    }
                    else
                    {
                        try
                        {
                            if (OnlineUsers.ContainsKey(packet.RoomID))
                            {
                                var query = from UserInfo subscriber in OnlineUsers[packet.RoomID].ToArray()
                                            where subscriber.UserName == packet.To
                                            select subscriber;

                                foreach (UserInfo subscriber in query.ToList())
                                {
                                    if (packet.UserName != subscriber.UserName)
                                        try
                                        {
                                            subscriber.UserSocket.OnVideoSend(packet);
                                        }
                                        catch
                                        {
                                            RemoveSubscriber(subscriber);
                                        }
                                }
                            }
                        }
                        catch { }
                    }
            }
        }
        catch (Exception ex) { LogWriter.WriteLog("PublishVideo ", ex.Message); }
    }
    #endregion Video Service

    #region Voice Service
    public void PublishVoice(WcsAudioPacket packet)
    {
        try
        {
            if (Packetizer.CheckCheckSum(packet) & packet.PayloadType == BinaryPayloadType.Voice & packet.UserName != ServiceName)
            {
                UserInRole role = GetUserRole(packet.UserName, packet.RoomID);
                if (role != UserInRole.NotValid & role != UserInRole.Blocked)

                    if (packet.IsPublic)
                    {
                        try
                        {
                            if (OnlineUsers.ContainsKey(packet.RoomID))
                                foreach (UserInfo subscriber in OnlineUsers[packet.RoomID].ToArray())
                                {
                                    if (packet.UserName != subscriber.UserName)
                                        try
                                        {
                                            subscriber.UserSocket.OnVoiceSend(packet);
                                        }
                                        catch { RemoveSubscriber(subscriber); }
                                }
                        }
                        catch { }
                    }
                    else
                    {
                        try
                        {
                            if (OnlineUsers.ContainsKey(packet.RoomID))
                            {
                                var query = from UserInfo subscriber in OnlineUsers[packet.RoomID].ToArray()
                                            where subscriber.UserName == packet.To
                                            select subscriber;

                                foreach (UserInfo subscriber in query.ToList())
                                {
                                    if (packet.UserName != subscriber.UserName)
                                        try
                                        {
                                            subscriber.UserSocket.OnVoiceSend(packet);
                                        }
                                        catch
                                        {
                                            RemoveSubscriber(subscriber);
                                        }
                                }
                            }
                        }
                        catch { }
                    }
            }
        }
        catch (Exception ex) { LogWriter.WriteLog("PublishVoice ", ex.Message); }
    }
    #endregion Voice Service

    #region Drawing Service
    public void PublishDrawing(WcsBinaryPacket packet)
    {
        try
        {
            if (Packetizer.CheckCheckSum(packet) & packet.PayloadType == BinaryPayloadType.Drawing & packet.UserName != ServiceName)
            {
                UserInRole role = GetUserRole(packet.UserName, packet.RoomID);
                if (role != UserInRole.NotValid & role != UserInRole.Blocked)

                    if (packet.IsPublic)
                    {
                        try
                        {
                            if (OnlineUsers.ContainsKey(packet.RoomID))
                                foreach (UserInfo subscriber in OnlineUsers[packet.RoomID].ToArray())
                                {
                                    if (packet.UserName != subscriber.UserName)
                                        try
                                        {
                                            subscriber.UserSocket.OnDrawingSend(packet);
                                        }
                                        catch { RemoveSubscriber(subscriber); }
                                }
                        }
                        catch { }
                    }
                    else
                    {
                        try
                        {
                            if (OnlineUsers.ContainsKey(packet.RoomID))
                            {
                                var query = from UserInfo subscriber in OnlineUsers[packet.RoomID].ToArray()
                                            where subscriber.UserName == packet.To
                                            select subscriber;

                                foreach (UserInfo subscriber in query.ToList())
                                {
                                    if (packet.UserName != subscriber.UserName)
                                        try
                                        {
                                            subscriber.UserSocket.OnDrawingSend(packet);
                                        }
                                        catch
                                        {
                                            RemoveSubscriber(subscriber);
                                        }
                                }
                            }
                        }
                        catch { }
                    }
            }
        }
        catch (Exception ex) { LogWriter.WriteLog("PublishDrawing ", ex.Message); }
    }
    public void CollaborativeBoardSync(WcsBinaryPacket packet, string ControlType)
    {
        try
        {
            if (Packetizer.CheckCheckSum(packet) & packet.PayloadType == BinaryPayloadType.Drawing & packet.UserName != ServiceName)
            {
                UserInRole role = GetUserRole(packet.UserName, packet.RoomID);
                if (role != UserInRole.NotValid & role != UserInRole.Blocked)

                    try
                    {
                        if (OnlineUsers.ContainsKey(packet.RoomID))
                            foreach (UserInfo subscriber in OnlineUsers[packet.RoomID].ToArray())
                            {
                                if (packet.UserName != subscriber.UserName)
                                    try
                                    {
                                        subscriber.UserSocket.OnCollaborativeBoardSync(packet.DataBuffer, ControlType,packet.UserName);
                                    }
                                    catch { RemoveSubscriber(subscriber); }
                            }
                    }
                    catch { }
            }
        }
        catch (Exception ex) { LogWriter.WriteLog("PublishDrawing ", ex.Message); }
    }
    #endregion Drawing Service

    #region Desktop Sharing Service

    public void PublishDesktop(WcsBinaryPacket packet)
    {
        try
        {
            if (Packetizer.CheckCheckSum(packet) & packet.PayloadType == BinaryPayloadType.DesktopShare & packet.UserName != ServiceName)
            {
                if (packet.UserName.Contains("Desktop"))

                    if (packet.IsPublic)
                    {
                        try
                        {
                            if (OnlineUsers.ContainsKey(packet.RoomID))
                                foreach (UserInfo subscriber in OnlineUsers[packet.RoomID].ToArray())
                                {
                                    if (packet.UserName != subscriber.UserName)
                                        try
                                        {
                                            subscriber.UserSocket.OnDesktopSend(packet);
                                        }
                                        catch { RemoveSubscriber(subscriber); }
                                }
                        }
                        catch { }
                    }
                    else
                    {
                        try
                        {
                            if (OnlineUsers.ContainsKey(packet.RoomID))
                            {
                                var query = from UserInfo subscriber in OnlineUsers[packet.RoomID].ToArray()
                                            where subscriber.UserName == packet.To
                                            select subscriber;

                                foreach (UserInfo subscriber in query.ToList())
                                {
                                    if (packet.UserName != subscriber.UserName)
                                        try
                                        {
                                            subscriber.UserSocket.OnDesktopSend(packet);
                                        }
                                        catch
                                        {
                                            RemoveSubscriber(subscriber);
                                        }
                                }
                            }
                        }
                        catch { }
                    }
            }
        }
        catch (Exception ex) { LogWriter.WriteLog("PublishDesktop ", ex.Message); }
    }
    #endregion Desktop Sharing Service

    #region Files Sharing Service

    public int MaxFileSize
    {
        // The Default is 8 MB MAX File Size
        get { return 8388608; }
    }

    private string SaveFolderPath
    {
        // The Default Write/Read Files Folder

        get { return @"temp\"; }
    }

    public void UploadFile(WcsFilePacket packet)
    {
        try
        {

            if (Packetizer.CheckCheckSum(packet) & packet.PayloadType == BinaryPayloadType.File & packet.UserName != ServiceName)
            {

                UserInRole role = GetUserRole(packet.UserName, packet.RoomID);
                if (role != UserInRole.Blocked & role != UserInRole.NotValid & packet.DataBuffer.Length <= MaxFileSize)
                    try
                    {
                        // Save the File To Cash
                        string FileID = SaveUploadedFile(packet.DataBuffer);

                        // Add File Id to Dic
                        if (FileID != "" & !UploadedFilesDictionary.ContainsKey(FileID))
                        {
                            WcsFilePacket File_Info = Packetizer.GetObject(packet.UserName, packet.RoomID, new byte[0], packet.FileName, packet.FileExtension, packet.FileSize, BinaryPayloadType.File, true);
                            File_Info.UploadedFileID = FileID;

                            UploadedFilesDictionary.Add(FileID, File_Info);

                            // Sync the New Files List to All Users in the room
                            SynchronizeFilesList(File_Info);
                        }
                    }
                    catch (Exception ex) { LogWriter.WriteLog("UploadFile ", ex.Message); }

            }
        }
        catch { }
    }

    public WcsFilePacket DownloadFile(WcsFilePacket FileID)
    {
        try
        {
            if (Packetizer.CheckCheckSum(FileID) & FileID.PayloadType == BinaryPayloadType.File & FileID.UserName != ServiceName)
            {

                if (UploadedFilesDictionary.ContainsKey(FileID.UploadedFileID))
                {

                    // Get The File Bytes From HDD or DB
                    byte[] DataBuffer = LoadUploadedFile(FileID.UploadedFileID);

                    // Get File Info From Dic
                    if (UploadedFilesDictionary.ContainsKey(FileID.UploadedFileID) & DataBuffer.Length > 0)
                    {
                        WcsFilePacket fileInfo = UploadedFilesDictionary[FileID.UploadedFileID];

                        // Packetizer
                        WcsFilePacket packet = Packetizer.GetObject(fileInfo.UserName, fileInfo.RoomID, DataBuffer, fileInfo.FileName,
                            fileInfo.FileExtension, fileInfo.FileSize, BinaryPayloadType.File, true);

                        return packet;
                    }

                    return new WcsFilePacket();
                }
                else return new WcsFilePacket();
            }
            else return new WcsFilePacket();
        }
        catch (Exception ex) { LogWriter.WriteLog("DownloadFile ", ex.Message); }

        return new WcsFilePacket();
    }

    public void RemoveFile(WcsFilePacket WcsFileInfo)
    {
        try
        {
            if (Packetizer.CheckCheckSum(WcsFileInfo) & WcsFileInfo.PayloadType == BinaryPayloadType.File & WcsFileInfo.UserName != ServiceName)
            {
                UserInRole role = GetUserRole(WcsFileInfo.UserName, WcsFileInfo.RoomID);
                if (role != UserInRole.NotValid & role != UserInRole.Blocked)
                    if (UploadedFilesDictionary.ContainsKey(WcsFileInfo.UploadedFileID))
                    {

                        // Must be the file owner on the same room and have the file id
                        if (UploadedFilesDictionary[WcsFileInfo.UploadedFileID].UserName == WcsFileInfo.UserName &
                            UploadedFilesDictionary[WcsFileInfo.UploadedFileID].RoomID == WcsFileInfo.RoomID)
                        {
                            // Remove it from Dictionary
                            UploadedFilesDictionary.Remove(WcsFileInfo.UploadedFileID);

                            // Remove it from HDD
                            RemoveUploadedFile(WcsFileInfo.UploadedFileID);

                            SynchronizeFilesList(WcsFileInfo);
                        }
                    }

            }
        }
        catch (Exception ex) { LogWriter.WriteLog("RemoveFile ", ex.Message); }
    }

    public void SynchronizeFilesList(WcsFilePacket UserRoomInfo)
    {
        try
        {
            // Send Files Header Include Files ID
            if (Packetizer.CheckCheckSum(UserRoomInfo) & UserRoomInfo.PayloadType == BinaryPayloadType.File & UserRoomInfo.UserName != ServiceName)
            {
                List<WcsFilePacket> FilesList = new List<WcsFilePacket>();


                foreach (var FileInfo in UploadedFilesDictionary)
                {
                    if (FileInfo.Value.RoomID == UserRoomInfo.RoomID)
                        FilesList.Add(FileInfo.Value);
                }

                if (OnlineUsers.ContainsKey(UserRoomInfo.RoomID))
                {
                    foreach (UserInfo subscriber in OnlineUsers[UserRoomInfo.RoomID].ToArray())
                    {
                        try
                        {
                            subscriber.UserSocket.OnFileUploaded(FilesList);
                        }
                        catch { RemoveSubscriber(subscriber); }
                    }
                }
            }
        }
        catch (Exception ex) { LogWriter.WriteLog("SynchronizeFilesList ", ex.Message); }
    }

    private string SaveUploadedFile(byte[] DataBuffer)
    {
        try
        {
            // Save the file into the HDD and generate Unique ID , 
            // Please note that Reading/Writing into Server HDD need to grant a special permission to allow reading and writing
            Random rnd = new Random(1000);
            string FileID = DateTime.Now.ToFileTime().ToString() + rnd.Next(1000).ToString();

            MemoryStream saveFile = new MemoryStream(DataBuffer);

            if (!System.IO.Directory.Exists(SaveFolderPath))
                System.IO.Directory.CreateDirectory(SaveFolderPath);

            using (FileStream outfile = new FileStream(SaveFolderPath + FileID, FileMode.Create))
            {
                try
                {
                    byte[] buffer = new byte[DataBuffer.Length];
                    int bytesRead = saveFile.Read(buffer, 0, buffer.Length);

                    while (bytesRead > 0)
                    {
                        outfile.Write(buffer, 0, bytesRead);
                        bytesRead = saveFile.Read(buffer, 0, buffer.Length);
                    }
                }
                catch { }
                finally
                {
                    outfile.Close();
                }
            }

            return FileID;
        }
        catch { return ""; }
    }

    private byte[] LoadUploadedFile(string FileID)
    {
        try
        {
            // Read The File From HDD by file ID
            // Please note that Reading/Writing into Server HDD need to grant a special permission to allow reading and writing
            string FilePath = SaveFolderPath + FileID;
            byte[] FileBuffer = new byte[0];

            BinaryReader br = null;

            if (File.Exists(FilePath))
            {
                FileStream fs = new FileStream(FilePath, FileMode.Open, FileAccess.Read);

                try
                {
                    br = new BinaryReader(fs);
                    long numBytes = new FileInfo(FilePath).Length;
                    FileBuffer = br.ReadBytes((int)numBytes);
                }
                catch { }

                finally
                {
                    if (br != null) br.Close();
                    if (fs != null) fs.Close();
                }
            }
            return FileBuffer;
        }
        catch { return new byte[0]; }
    }

    private void RemoveUploadedFile(string FileID)
    {
        try
        {
            // Remove The File From HDD by file ID
            // Please note that Reading/Writing into Server HDD need to grant a special permission to allow reading and writing
            string FilePath = SaveFolderPath + FileID;

            if (File.Exists(FilePath))
                File.Delete(FilePath);
        }
        catch (Exception ex) { LogWriter.WriteLog("RemoveUploadedFile ", ex.Message); }
    }

    private void ClearUploadedFiles(string RoomID)
    {
        try
        {
            foreach (var FileInfo in UploadedFilesDictionary.ToArray())
            {
                // Clear The Files From HDD if the room is empty
                if (FileInfo.Value.RoomID == RoomID)
                {
                    try
                    {
                        // Clear The File From Dictionary
                        UploadedFilesDictionary.Remove(FileInfo.Key);
                    }
                    catch { }

                    // Remove the file from HDD
                    RemoveUploadedFile(FileInfo.Key);
                }
            }

        }
        catch (Exception ex) { LogWriter.WriteLog("ClearUploadedFiles ", ex.Message); }
    }

    #endregion Files_Sharing

    #region Policy Service
    public Stream GetSilverlightPolicy()
    {
        string result = @"<?xml version=""1.0"" encoding=""utf-8""?> 
                            <access-policy> 
                                <cross-domain-access> 
                                   <policy> 
                                        <allow-from http-request-headers=""*""> 
                                           <domain uri=""*""/> 
                                      </allow-from> 
                                       <grant-to> 
                                           <socket-resource port=""4527"" protocol=""tcp"" /> 
                                       </grant-to> 
                                    </policy> 
                               </cross-domain-access> 
                            </access-policy>";
        WebOperationContext.Current.OutgoingResponse.ContentType = "application/xml";
        return new MemoryStream(Encoding.UTF8.GetBytes(result));
    }

    #endregion Policy Service

}
