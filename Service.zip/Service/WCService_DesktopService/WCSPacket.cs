﻿// (C) SocketCoder.Com 
// WCS/WMS Web Conferencing Server
// Last Modify: 17/Aug/2014
namespace MediaStreaming
{
    using System;
    using System.Collections.Generic;
    using System.Security.Cryptography;

    public enum BinaryPayloadType { Voice, Video, Drawing, DesktopShare, File };
    public enum TXTPayloadType { Subscribe, UnSubscribe, Sync, Cmd, TxtMsg, CCall, CAccepted, CEnded, CRejected, CBusy };
    public enum PresenterCMD { Clear, KickOut, Block, Allow_Mic_Sharing, Allow_Cam_Sharing, Allow_Text_Typing, Allow_Files_Uploading, Allow_Drawing, Allow_DesktopSharing, Disallow_Mic_Sharing, Disallow_Cam_Sharing, Disallow_Text_Typing, Disallow_Files_Uploading, Disallow_Drawing, Disallow_DesktopSharing };
    public enum UserType { Guest, RegisteredUser, SysAdmin };
    public enum UserInRole { NotValid, Blocked, Participant, Presenter, RoomAdmin };
    public enum RoomInRole { All, TextChat, VoiceChat, VideoChat, DrawingBoard, DesktopSharing, FilesSharing };
    public enum IssueStatus { Done, Error, NotValid, Reject, UserIDAlreadyInUse, BlockedUser, MaxUsersExceeded, OldVersion }

    public struct WcsTxtPacket
    {
        // For Text , Notify Messages
        public bool IsPublic { get; set; }
        public TXTPayloadType PayloadType { get; set; }
        public string To { get; set; }
        public string UserName { get; set; }
        public string RoomID { get; set; }
        public string Message { get; set; }
        public string CheckSum { get; set; }
    }

    public struct WcsPresenterCMDPacket
    {
        // For Commands Messages
        public bool IsPublic { get; set; }
        public TXTPayloadType PayloadType { get; set; }
        public PresenterCMD Command { get; set; }
        public string To { get; set; }
        public string UserName { get; set; }
        public string RoomID { get; set; }
        public string CheckSum { get; set; }
    }

    public struct WcsBinaryPacket
    {
        // For Video , Drawing and Desktop Sharing
        public string To { get; set; }
        public string UserName { get; set; }
        public string RoomID { get; set; }
        public byte[] DataBuffer { get; set; }
        public string CheckSum { get; set; }
        public BinaryPayloadType PayloadType { get; set; }
        public bool IsCompressed { get; set; }
        public bool IsPublic { get; set; }
    }

    public struct WcsAudioPacket
    {
        // For Audio Data Exchange 
        public string To { get; set; }
        public string UserName { get; set; }
        public string RoomID { get; set; }
        public byte[] DataBuffer { get; set; }
        public int AudioFormatBits { get; set; }
        public int AudioFormatSamples { get; set; }
        public int AudioFormatChannels { get; set; }
        public string CheckSum { get; set; }
        public BinaryPayloadType PayloadType { get; set; }
        public bool IsPublic { get; set; }
    }

    public struct WcsFilePacket
    {
        // For Files Sharing
        public string UserName { get; set; }
        public string RoomID { get; set; }
        public byte[] DataBuffer { get; set; }
        public string FileName { get; set; }
        public string FileExtension { get; set; }
        public string UploadedFileID { get; set; }
        public int FileSize { get; set; }
        public string CheckSum { get; set; }
        public BinaryPayloadType PayloadType { get; set; }
        public bool IsPublic { get; set; }
    }

    public struct UserInfoPacket
    {
        public string RoomID { get; set; }
        public string UserName { get; set; }
        public UserInRole Role { get; set; }
        public UserType UType { get; set; }
        public string AgentVersion { get; set; }
        public string AvatarID { get; set; }
        public string CheckSum { get; set; }
    }

    public struct RoomInfoPacket
    {
        public string RoomID { get; set; }
        public RoomInRole[] RoomRoles { get; set; }
        public int MaxUsers { get; set; }
        public string CheckSum { get; set; }
    }

    public struct GlobalUserPermissions
    {
        public bool AllowMic { get; set; }
        public bool AllowCAM { get; set; }
        public bool AllowTXT { get; set; }
        public bool AllowFiles { get; set; }
        public bool ALLOWWB { get; set; }
    }

    public class WcsPacketizer
    {
        private const string SecurityKey = "C56A901aB3";

        public WcsTxtPacket GetObject(string To_User, string UserName,string RoomID, string TxtMessage, TXTPayloadType PType, bool Is_Public)
        {
            WcsTxtPacket TxTPacket = new WcsTxtPacket();
            TxTPacket.To = To_User;
            TxTPacket.UserName = UserName;
            TxTPacket.RoomID = RoomID;
            TxTPacket.Message = TxtMessage;
            TxTPacket.PayloadType = PType;
            TxTPacket.IsPublic = Is_Public;
            TxTPacket.CheckSum = GenerateCheckSum((TxTPacket.To.Length + TxTPacket.UserName.Length + TxTPacket.RoomID.Length + TxTPacket.Message.Length).ToString());
            return TxTPacket;
        }

        public UserInfoPacket GetObject(string Room_ID, string User_Name, string Avatar_ID, UserInRole User_Role, UserType User_Type, string AgentVersion)
        {
            UserInfoPacket info = new UserInfoPacket();
            info.UType = User_Type;
            info.Role = User_Role;
            info.RoomID = Room_ID;
            info.AgentVersion = AgentVersion;
            info.AvatarID = Avatar_ID;
            info.UserName = User_Name;
            info.CheckSum = GenerateCheckSum((Room_ID.Length + AgentVersion.Length + User_Name.Length + Avatar_ID.Length + User_Role.ToString().Length + User_Type.ToString().Length).ToString());
            return info;
        }

        public RoomInfoPacket GetObject(string Room_ID, RoomInRole[] User_Role,int MaxUsers)
        {
            RoomInfoPacket info = new RoomInfoPacket();
            info.RoomID = Room_ID;
            info.RoomRoles = User_Role;
            info.MaxUsers = MaxUsers;
            info.CheckSum = GenerateCheckSum((Room_ID.Length + User_Role.Length + MaxUsers).ToString());
            return info;
        }

        public WcsPresenterCMDPacket GetObject(string To_User, string UserName, string RoomID, PresenterCMD CMD, TXTPayloadType PType, bool Is_Public)
        {
            WcsPresenterCMDPacket CMDPacket = new WcsPresenterCMDPacket();
            CMDPacket.To = To_User;
            CMDPacket.UserName = UserName;
            CMDPacket.RoomID = RoomID;
            CMDPacket.Command = CMD;
            CMDPacket.PayloadType = PType;
            CMDPacket.IsPublic = Is_Public;
            CMDPacket.CheckSum = GenerateCheckSum((CMDPacket.To.Length + CMDPacket.UserName.Length + CMDPacket.RoomID.Length + CMDPacket.Command.ToString().Length).ToString());
            return CMDPacket;
        }

        public WcsBinaryPacket GetObject(string To_User, string UserName,string RoomID, byte[] DataBuffer, BinaryPayloadType PType, bool Is_Compressed, bool Is_Public)
        {
            WcsBinaryPacket BinaryPacket = new WcsBinaryPacket();
            BinaryPacket.To = To_User;
            BinaryPacket.UserName = UserName;
            BinaryPacket.RoomID = RoomID;
            BinaryPacket.DataBuffer = DataBuffer;
            BinaryPacket.PayloadType = PType;
            BinaryPacket.IsCompressed = Is_Compressed;
            BinaryPacket.IsPublic = Is_Public;
            BinaryPacket.CheckSum = GenerateCheckSum((BinaryPacket.To.Length + BinaryPacket.UserName.Length + BinaryPacket.RoomID.Length + BinaryPacket.DataBuffer.Length).ToString());
            return BinaryPacket;
        }

        public WcsAudioPacket GetObject(string To_User, string UserName,string RoomID, byte[] DataBuffer, int AudioFormatBits, int AudioFormatSamples, int AudioFormatChannels, BinaryPayloadType PType, bool Is_Public)
        {
            WcsAudioPacket AudioPacket = new WcsAudioPacket();
            AudioPacket.To = To_User;
            AudioPacket.UserName = UserName;
            AudioPacket.RoomID = RoomID;
            AudioPacket.DataBuffer = DataBuffer;
            AudioPacket.AudioFormatBits = AudioFormatBits;
            AudioPacket.AudioFormatSamples = AudioFormatSamples;
            AudioPacket.AudioFormatChannels = AudioFormatChannels;
            AudioPacket.PayloadType = PType;
            AudioPacket.IsPublic = Is_Public;
            AudioPacket.CheckSum = GenerateCheckSum((AudioPacket.To.Length + AudioPacket.UserName.Length + AudioPacket.RoomID.Length + AudioPacket.DataBuffer.Length).ToString());
            return AudioPacket;
        }

        public WcsFilePacket GetObject(string UserName, string RoomID, byte[] DataBuffer, string FileName, string FileExtension, int FileSize, BinaryPayloadType PType, bool Is_Public)
        {
            WcsFilePacket FilePacket = new WcsFilePacket();
            FilePacket.UserName = UserName;
            FilePacket.RoomID = RoomID;
            FilePacket.DataBuffer = DataBuffer;
            FilePacket.FileName = FileName;
            FilePacket.FileExtension = FileExtension;
            FilePacket.FileSize = FileSize;
            FilePacket.PayloadType = PType;
            FilePacket.IsPublic = Is_Public;
            FilePacket.CheckSum = GenerateCheckSum((FilePacket.UserName.Length + FilePacket.RoomID.Length + FilePacket.FileName.Length + FilePacket.DataBuffer.Length).ToString());
            return FilePacket;
        }

        public bool CheckCheckSum(WcsTxtPacket WcsTxt)
        {
            return CheckCheckSum((WcsTxt.To.Length + WcsTxt.UserName.Length + WcsTxt.RoomID.Length + WcsTxt.Message.Length).ToString(), WcsTxt.CheckSum);
        }
        public bool CheckCheckSum(UserInfoPacket WcsUser)
        {
            return CheckCheckSum((WcsUser.RoomID.Length + WcsUser.AgentVersion.Length + WcsUser.UserName.Length + WcsUser.AvatarID.Length + WcsUser.Role.ToString().Length + WcsUser.UType.ToString().Length).ToString(), WcsUser.CheckSum);
        }

        public bool CheckCheckSum(RoomInfoPacket WcsRoom)
        {
            return CheckCheckSum((WcsRoom.RoomID.Length + WcsRoom.RoomRoles.Length + WcsRoom.MaxUsers).ToString(), WcsRoom.CheckSum);
        }

        public bool CheckCheckSum(WcsPresenterCMDPacket WcsCMD)
        {
            return CheckCheckSum((WcsCMD.To.Length + WcsCMD.UserName.Length + WcsCMD.RoomID.Length + WcsCMD.Command.ToString().Length).ToString(), WcsCMD.CheckSum);
        }
        public bool CheckCheckSum(WcsBinaryPacket WcsBinary)
        {
            return CheckCheckSum((WcsBinary.To.Length + WcsBinary.UserName.Length + WcsBinary.RoomID.Length + WcsBinary.DataBuffer.Length).ToString(), WcsBinary.CheckSum);
        }

        public bool CheckCheckSum(WcsAudioPacket WcsAudio)
        {
            return CheckCheckSum((WcsAudio.To.Length + WcsAudio.UserName.Length + WcsAudio.RoomID.Length + WcsAudio.DataBuffer.Length).ToString(), WcsAudio.CheckSum);
        }

        public bool CheckCheckSum(WcsFilePacket WcsFile)
        {
            return CheckCheckSum((WcsFile.UserName.Length + WcsFile.RoomID.Length + WcsFile.FileName.Length + WcsFile.DataBuffer.Length).ToString(), WcsFile.CheckSum);
        }

        public string GenerateCheckSum(string PacketSummary)
        {
            try
            {
                using (SHA1Managed sha1 = new SHA1Managed())
                {
                    byte[] DataBytes = System.Text.UTF8Encoding.Unicode.GetBytes(PacketSummary + SecurityKey);
                    var hash = sha1.ComputeHash(DataBytes);
                    return Convert.ToBase64String(hash);
                }
            }
            catch { return "False"; }
        }

        private bool CheckCheckSum(string PacketSummary, string CheckSum)
        {
            try
            {
                using (SHA1Managed sha1 = new SHA1Managed())
                {
                    byte[] DataBytes = System.Text.UTF8Encoding.Unicode.GetBytes(PacketSummary + SecurityKey);
                    var hash = sha1.ComputeHash(DataBytes);
                    string GeneratedCheckSum = Convert.ToBase64String(hash);
                    if (GeneratedCheckSum == CheckSum) return true; else return false;
                }
            }
            catch { return false; }
        }

    }
}