﻿// (C) SocketCoder.Com 
// WCS/WMS Web Conferencing Server
// Last Modify: 17/Aug/2014

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.ServiceProcess;
using System.Configuration;
using System.Collections;

using SocketCoder_WCService;
using System.Threading;
using System.Net;
using System.ServiceModel;
using System.ServiceModel.Description;

namespace SocketCoder_WCService.MainService
{
    public partial class SocketCoder_WCService : ServiceBase
    {
        //To self host the ClientAccessPolicy file you should host it on HTTP Port 80 
        //if you already use this port on IIS on the same server and on the same IP the value should be false here and 
        //you have to copy the ClientAccessPolicy.xml file from the Compiled folder to host it on the root folder of IIS. 
        private bool SelfHostClientAccessPolicyFile = true;

        string ServerIP = "YOUR_SERVER_IP_HERE"; // Host Server IP or Domain Name Example: domain.com

        ServiceHost SocketCoderHostService;

        private string SaveFolderPath
        {
            // The Default Write/Read Files Folder

            get { return @"temp\"; }
        }


        public void ClearAllFiles()
        {
            try
            {
                if (System.IO.Directory.Exists(SaveFolderPath))
                {
                    System.IO.Directory.Delete(SaveFolderPath, true);
                }
            }
            catch { }
        }


        public SocketCoder_WCService()
        {
            InitializeComponent();

            try
            {
                ClearAllFiles();
            }
            catch (Exception ex)
            {
                LogWriter.WriteLog("OnStart", ex.Message);
            }
        }

        public void Add_Event(string ServiceName, string MSG)
        {
            LogWriter.WriteLog(ServiceName, MSG);
        }

        string GetTime()
        {
            return " at " + DateTime.Now.ToString();
        }

        #region Service start & stop
        protected override void OnStart(string[] args)
        {
            try
            {
                string baseAddressTcp = "net.tcp://" + ServerIP + ":4527/VideoConferenceService";
                string baseAddressHttp = "http://" + ServerIP + ":80";

                if (SelfHostClientAccessPolicyFile)
                {
                    SocketCoderHostService = new ServiceHost(typeof(VideoConferenceService), new Uri(baseAddressHttp), new Uri(baseAddressTcp));
                    SocketCoderHostService.AddServiceEndpoint(typeof(ITcpPolicyRetriever), new WebHttpBinding(), "").Behaviors.Add(new WebHttpBehavior());
                }
                else SocketCoderHostService = new ServiceHost(typeof(VideoConferenceService), new Uri(baseAddressTcp));

                ServiceMetadataBehavior smb = new ServiceMetadataBehavior();

                // Add Service Throttling quotas and set it on max level
                ServiceThrottlingBehavior throttle = new ServiceThrottlingBehavior();
                throttle.MaxConcurrentCalls = int.MaxValue;
                throttle.MaxConcurrentInstances = int.MaxValue;
                throttle.MaxConcurrentSessions = int.MaxValue;

                SocketCoderHostService.Description.Behaviors.Add(throttle);

                // Set Net TCP Quotas on max level
                NetTcpBinding netTcpBinding = new NetTcpBinding(SecurityMode.None);
                netTcpBinding.ReceiveTimeout = new TimeSpan(1, 0, 0, 0);
                netTcpBinding.MaxReceivedMessageSize = int.MaxValue;
                netTcpBinding.MaxBufferPoolSize = int.MaxValue;
                netTcpBinding.MaxBufferSize = int.MaxValue;
                netTcpBinding.ReaderQuotas.MaxArrayLength = int.MaxValue;
                netTcpBinding.ReaderQuotas.MaxBytesPerRead = int.MaxValue;
                netTcpBinding.ReaderQuotas.MaxDepth = int.MaxValue;
                netTcpBinding.ReaderQuotas.MaxNameTableCharCount = int.MaxValue;
                netTcpBinding.ReaderQuotas.MaxStringContentLength = int.MaxValue;

                SocketCoderHostService.AddServiceEndpoint(typeof(IVideoConferenceService), netTcpBinding, "");

                SocketCoderHostService.Description.Behaviors.Add(smb);
                SocketCoderHostService.AddServiceEndpoint(typeof(IMetadataExchange), MetadataExchangeBindings.CreateMexTcpBinding(), "mex");
                SocketCoderHostService.Open();

                LogWriter.WriteLog("OnStart Event: ", "Service " + baseAddressTcp + " Started");
              if (SelfHostClientAccessPolicyFile)  LogWriter.WriteLog("OnStart Event: ", "Service " + baseAddressHttp + " Started"); 
            }
            catch (Exception ex)
            {
                LogWriter.WriteLog("OnStart Error: ", ex.Message);
            }
        }

        protected override void OnStop()
        {
            try
            {
                if (SocketCoderHostService != null)
                    SocketCoderHostService.Close();

                ClearAllFiles();

                LogWriter.WriteLog("OnStop Event: ", "Service Stopped"); 
               
            }
            catch (Exception ex)
            {
                LogWriter.WriteLog("OnStop", ex.Message);
            }
        }
        #endregion
    }
}
