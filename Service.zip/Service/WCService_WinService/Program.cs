﻿using System;
using System.Collections.Generic;
using System.ServiceProcess;
using System.Text;

namespace SocketCoder_WCService.MainService
{
    static class Program
    {

        static void Main()
        {
            ServiceBase[] ServicesToRun;
            ServicesToRun = new ServiceBase[] { new SocketCoder_WCService() };
            ServiceBase.Run(ServicesToRun);
        }
    }
}
