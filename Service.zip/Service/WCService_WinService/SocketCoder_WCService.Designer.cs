﻿namespace SocketCoder_WCService.MainService
{
    partial class SocketCoder_WCService
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            // 
            // SocketCoder_WCService
            // 
            this.ServiceName = "SocketCoderWebConferenceServer";

        }
    }
}
