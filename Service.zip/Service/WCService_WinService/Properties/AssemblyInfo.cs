﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;


[assembly: AssemblyTitle("SocketCoder_WCService")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("SocketCoder.Com")]
[assembly: AssemblyProduct("SocketCoder_WCService")]
[assembly: AssemblyCopyright("Copyright © SocketCoder.Com 2014")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]


[assembly: Guid("504b430d-972a-499c-8d00-bd52e23aee86")]

[assembly: AssemblyVersion("4.0.0.1")]
[assembly: AssemblyFileVersion("4.0.0.1")]
