﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MediaStreaming;
using System.Net.Sockets;
using MeidaStreaming;
using System.IO;
using System.Windows.Media.Effects;
using System.Windows.Threading;
using System.ComponentModel;
using ImageTools;
using DesktopSharingTool.WCS_Proxy;

namespace DesktopSharingTool
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();

            if (App.Current.IsRunningOutOfBrowser)
            {
                PleaseNote.Visibility = System.Windows.Visibility.Collapsed;
                Application.Current.MainWindow.TopMost = true;
                ConnectBTN.IsEnabled = true;
            }
            else
            {
                ConnectBTN.IsEnabled = false;
            }
        }

        private WcsPacketizer Packetizer = new WcsPacketizer();
        private VideoConferenceServiceClient WCSProxy;

        // Default Image Quality
        private int Quality = 50;

        // Socket and Publisher Encoder
        private RoomCodeData RoomCode = new RoomCodeData();
        private Thread th;
        private bool stop = true;

        #region Desktop Sharing Socket Methods

        private void ConnectBTN_Click(object sender, RoutedEventArgs e)
        {
            if (App.Current.IsRunningOutOfBrowser)
            {
                if (RoomCode.Parse(RoomIdTXT.Text))
                {
                    Initiate_Proxy();
                }
                else ShowMessageBox("Wrong Room Code, Please Copy/Paste the Correct Room Code from the WCS System!");
            }
            else ShowMessageBox("This Tool Can be only running on windows desktop mode, Please right click then click on (Install SocketCoder Desktop Sharing Tool) to install it on your desktop");
        }

        void Initiate_Proxy()
        {
            try
            {
                if (WCSProxy != null)
                {
                    WCSProxy.Abort();
                }

                WCSProxy = new VideoConferenceServiceClient();
                WCSProxy.OpenCompleted += new EventHandler<AsyncCompletedEventArgs>(OnOpened);
                WCSProxy.CloseCompleted += new EventHandler<AsyncCompletedEventArgs>(OnClosed);
                WCSProxy.OpenAsync();
            }
            catch { }
        }

        void InnerChannel_Faulted(object sender, EventArgs e)
        {
            try
            {
                Deployment.Current.Dispatcher.BeginInvoke(() =>
                {
                    EnableDrawingControl(false);
                });
            }
            catch { }
        }

        void OnOpened(object sender, AsyncCompletedEventArgs e)
        {
            try
            {
                if (e.Error != null)
                {
                    ShowMessageBox(e.Error.Message);
                }
                else
                {
                    WCSProxy.InnerChannel.Faulted += new EventHandler(InnerChannel_Faulted);
                    
                    Deployment.Current.Dispatcher.BeginInvoke(() =>
                    {
                        EnableDrawingControl(true);
                    });
                }
            }
            catch { }
        }

        void OnClosed(object sender, AsyncCompletedEventArgs e)
        {
            try
            {
                if (e.Error != null)
                {
                    ShowMessageBox(e.Error.Message);
                }
            }
            catch { }
        }

        private void EnableDrawingControl(bool value)
        {
            ShareBTN.IsEnabled = StartBTN.IsEnabled = value;
            ConnectBTN.IsEnabled = RoomIdTXT.IsEnabled = !value;
            
            if (value)
            {
                ConnectBTN.Content = "Joined";
                sendingSt.Foreground = new SolidColorBrush(Colors.Green);
                sendingSt.Content = "Connected";
            }
            else
            {
                ConnectBTN.Content = "Join";
                sendingSt.Foreground = new SolidColorBrush(Colors.Red);
                sendingSt.Content = "Disconnected";
                StartAutoComparing(false);
            }
        }

        void PublishIt(byte[] buffer)
        {
            try
            {
                if (buffer.Length > 0)
                    WCSProxy.PublishDesktopAsync(Packetizer.GetObject(RoomCode.RoomID, RoomCode.UserName, RoomCode.RoomID, buffer, BinaryPayloadType.DesktopShare, true, true));
            }
            catch { }
        }

        #endregion Desktop Sharing Socket Methods

        private void ShareIt_Click(object sender, RoutedEventArgs e)
        {
            if (App.Current.IsRunningOutOfBrowser)
            {
                Application.Current.MainWindow.Hide();
                Delay(500,
                      () =>
                      {
                          try
                          {
                              byte[] buffer = ScreenCapture.GetDesktopImage(Quality);

                              if (buffer.Length > 0)
                              {
                                  PublishIt(buffer);
                                  sendingSt.Foreground = new SolidColorBrush(Colors.Green);
                                  sendingSt.Content = "Published";
                              }
                              else
                                  ShowMessageBox("You dont have the right on your computer to take a snapshot!");
                          }
                          catch (Exception ex)
                          {
                              MessageBox.Show(ex.Message);
                          }
                          finally
                          {
                              Application.Current.MainWindow.Show();
                              Application.Current.MainWindow.Activate();
                          }
                      });
            }
        }

        void StartAutoComparing(bool value)
        {
            try
            {
                if (value)
                {
                    stop = false;
                    th = new Thread(new ThreadStart(FindAndSend));
                    th.IsBackground = true;
                    th.Start();
                    StartBTN.IsEnabled = false;
                    StopBtn.IsEnabled = true;
                }
                else if (th != null)
                {
                    stop = true;
                    th.Abort();
                    StartBTN.IsEnabled = true;
                    StopBtn.IsEnabled = false;
                    sendingSt.Foreground = new SolidColorBrush(Colors.Red);
                    sendingSt.Content = "Stopped";
                }
            }
            catch { }
        }
        public void AutoComparing_Tick(object sender, EventArgs e)
        {
            FindAndSend();
        }
        private void StopBtn_Click(object sender, RoutedEventArgs e)
        {
            StartAutoComparing(false);
        }

        private void StartBTN_Click(object sender, RoutedEventArgs e)
        {
            StartAutoComparing(true);
        }

        void FindAndSend()
        {

            ExtendedImage FirstImage = null;
            ExtendedImage LastSentImage = null;
            int Counter  = 1;

            while (!stop)
                try
                {
                    if (LastSentImage != null)
                    {
                        Counter += CompareIt(ScreenCapture.GetDesktopImageToCompare(), LastSentImage);
                    }

                    FirstImage = ScreenCapture.GetDesktopImageToCompare();
                    Thread.Sleep(200);
                    Counter += CompareIt(FirstImage, ScreenCapture.GetDesktopImageToCompare());

                    if (Counter>=1)
                    {
                        Deployment.Current.Dispatcher.BeginInvoke(delegate()
                        {
                            sendingSt.Foreground = new SolidColorBrush(Colors.Green);
                            sendingSt.Content = "Sending...";
                            PublishIt(ScreenCapture.GetDesktopImage(Quality));
                        });

                        Counter = 0;
                        LastSentImage = FirstImage;
                        Thread.Sleep(1500);
                    }
                }
                catch { }
        }

        public int CompareIt(ExtendedImage OrginalImage, ExtendedImage SecoundImage)
        {                
            int Counter = 0;

            try
            {
                int size_H = OrginalImage.PixelHeight;
                int size_W = SecoundImage.PixelWidth;

                float total = size_H * size_W;

                for (int x = 0; x != size_W; x++)
                {

                    for (int y = 0; y != size_H; y++)
                    {
                        // Read Bitmap Pixel Color Then Compare it with the Second image pixel
                        int OrginalImageColor = OrginalImage.Pixels[(int)(y * OrginalImage.PixelWidth + x)];
                        int SecoundImageColor = SecoundImage.Pixels[(int)(y * SecoundImage.PixelWidth + x)];

                        // To Get The Pixel Color:
                        // Color pixel_image1 = Color.FromArgb((byte)(OrginalImageColor >> 24), (byte)(OrginalImageColor >> 16), (byte)(OrginalImageColor >> 8), (byte)(OrginalImageColor));
                        // Color pixel_image2 = Color.FromArgb((byte)(SecoundImageColor >> 24), (byte)(SecoundImageColor >> 16), (byte)(SecoundImageColor >> 8), (byte)(SecoundImageColor));

                        if (OrginalImageColor != SecoundImageColor)
                        {
                            Counter++;
                        }
                    }
                    
                }

            }
            catch { return 1; }

            Deployment.Current.Dispatcher.BeginInvoke(delegate()
            {
                sendingSt.Foreground = new SolidColorBrush(Colors.Blue);
                sendingSt.Content = "Comparing ..";
            });

            return Counter;
        }

        private void QualitySlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (QualitySlider != null)
            {
                Quality = (int)QualitySlider.Value;
                SelectedQuality.Content = Quality.ToString();
            }
        }

        private void Delay(int timeout, Action action)
        {
            Task task = new Task(
                () =>
                {
                    Thread.Sleep(timeout);

                    Deployment.Current.Dispatcher.BeginInvoke(action);
                });

            task.Start();
        }

        private void ShowMessageBox(string MSG)
        {
            MessageBox.Show(MSG, "WCS Desktop Sharing Tool", MessageBoxButton.OK);
        }

    }
}
