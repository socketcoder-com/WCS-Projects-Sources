﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Whiteboard.Client
{
    public class CanvasExt : Canvas
    {
        private bool _isImageLoaded;
        private bool _isCanvasMouseCaptured;
        private bool _isRectSelectorMouseCaptured;
        private Image _imgCroppable;
        private Point _pntMoveStart;
        private Point _pntRectSelector;
        private Point _pntSelection;
        private Shape _rectSelector;

        public CanvasExt()
        {
            MouseLeftButtonDown += canvasExt_MouseLeftButtonDown;
            MouseLeftButtonUp += canvasExt_MouseLeftButtonUp;
            MouseMove += canvasExt_MouseMove;
            _isImageLoaded = false;
            _isCanvasMouseCaptured = false;
        }

        public void LoadFromBitmapImage(BitmapImage bmpCroppable)
        {
            if (_isImageLoaded)
                _imgCroppable = null;
            
            _imgCroppable = new Image { Source = bmpCroppable, VerticalAlignment = VerticalAlignment.Top };
            _imgCroppable.MouseLeftButtonDown += canvasExt_MouseLeftButtonDown;
            _isImageLoaded = true;
            Children.Clear();
            Children.Add(_imgCroppable);
        }
        
        public WriteableBitmap CropImage()
        {
            try
            {
                WriteableBitmap wbSource = new WriteableBitmap(_imgCroppable, null);

                int sourceWidth = wbSource.PixelWidth;
                int w = (int)_rectSelector.Width;
                int h = (int)_rectSelector.Height;
                WriteableBitmap wbResult = new WriteableBitmap(w, h);

                for (int y = 0; y <= h - 1; y++)
                {
                    int sourceIndex = (int)GetLeft(_rectSelector) + ((int)GetTop(_rectSelector) + y) * sourceWidth;
                    int destinationIndex = y * w;
                    Array.Copy(wbSource.Pixels, sourceIndex, wbResult.Pixels, destinationIndex, w);
                }

                Children.Remove(_rectSelector);
                _rectSelector = null;
                return wbResult;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return null;
            }
        }

        private void canvasExt_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (_isRectSelectorMouseCaptured) return;
            if (!_isCanvasMouseCaptured && _isImageLoaded)
            {
                Children.Remove(_rectSelector);
                _rectSelector = null;
                _pntSelection = e.GetPosition(this);
                _isCanvasMouseCaptured = true;
            }
        }

        private void canvasExt_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            _isCanvasMouseCaptured = false;
        }

        private void canvasExt_MouseMove(object sender, MouseEventArgs e)
        {
            if (!_isCanvasMouseCaptured) return;
            if (_rectSelector == null)
            {
                //if (_rectSelectorStyle != null)
                //    rectSelector.Style = _rectSelectorStyle;
                _rectSelector = new Rectangle
                {
                    //Stroke = new SolidColorBrush(Colors.LightGray),
                    //Fill = new SolidColorBrush(Colors.Yellow),
                    //Opacity = 0.20,
                    Cursor = Cursors.Hand
                };
                _rectSelector.MouseLeftButtonDown += rectSelector_MouseLeftButtonDown;
                _rectSelector.MouseLeftButtonUp += rectSelector_MouseLeftButtonUp;
                _rectSelector.MouseMove += rectSelector_MouseMove;
                Children.Add(_rectSelector);
                SetZIndex(_rectSelector, 100);
            }

            if (e.GetPosition(this).X <= Width && e.GetPosition(this).X > 0)
            {
                double width = Math.Abs(_pntSelection.X - e.GetPosition(this).X);
                double left = Math.Min(_pntSelection.X, e.GetPosition(this).X);

                _rectSelector.Width = width;
                SetLeft(_rectSelector, left);
            }

            if (e.GetPosition(this).Y <= Height && e.GetPosition(this).Y > 0)
            {
                double height = Math.Abs(_pntSelection.Y - e.GetPosition(this).Y);
                double top = Math.Min(_pntSelection.Y, e.GetPosition(this).Y);

                _rectSelector.Height = height;
                SetTop(_rectSelector, top);
            }
        }

        private void rectSelector_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (_isRectSelectorMouseCaptured) return;
            _pntMoveStart = e.GetPosition(this);
            _pntRectSelector.X = GetLeft(_rectSelector);
            _pntRectSelector.Y = GetTop(_rectSelector);
            _isRectSelectorMouseCaptured = true;
        }

        private void rectSelector_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            _isRectSelectorMouseCaptured = false;
        }

        private void rectSelector_MouseMove(object sender, MouseEventArgs e)
        {
            if (!_isRectSelectorMouseCaptured) return;
            double left = _pntMoveStart.X - e.GetPosition(this).X;

            if (_pntRectSelector.X + _rectSelector.Width - left <= Width &&
                _pntRectSelector.X - left > 0)
            {
                SetLeft(_rectSelector, _pntRectSelector.X - left);
            }

            double top = _pntMoveStart.Y - e.GetPosition(this).Y;

            if (_pntRectSelector.Y + _rectSelector.Height - top <= Height &&
                _pntRectSelector.Y - top > 0)
            {
                SetTop(_rectSelector, _pntRectSelector.Y - top);
            }
        }
    }
}