﻿using System;
using System.Windows;

namespace SilverFlow.Controls
{
    /// <summary>
    /// Useful Silverlight controls extensions
    /// </summary>
    public static class ControlExtensions
    {
        /// <summary>
        /// Sets the visible of the UIElement.
        /// </summary>
        /// <param name="uiElement">The UI element.</param>
        /// <param name="visible">Set Visible if <c>true</c>; otherwise - Collapsed.</param>
        public static void SetVisible(this UIElement uiElement, bool visible = true)
        {
            if (uiElement != null)
            {
                uiElement.Visibility = (visible) ? Visibility.Visible : Visibility.Collapsed;
            }
        }

        /// <summary>
        /// Determines whether the specified element contains the point.
        /// </summary>
        /// <param name="element">This FrameworkElement.</param>
        /// <param name="point">The point to check.</param>
        /// <returns>
        /// <c>true</c> if the specified element contains the point; otherwise, <c>false</c>.
        /// </returns>
        public static bool ContainsPoint(this FrameworkElement element, Point point)
        {
            if (element != null)
            {
                Rect rect = new Rect(0, 0, element.ActualWidth, element.ActualHeight);
                return rect.Contains(point);
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Gets position of the element relative to another specified (root) element.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <param name="rootElement">The root element.</param>
        /// <returns>Relative position.</returns>
        /// <exception cref="ArgumentNullException">Input parameter is null.</exception>
        public static Point GetRelativePosition(this UIElement element, UIElement rootElement)
        {
            if (element == null)
                throw new ArgumentNullException("element");

            if (rootElement == null)
                throw new ArgumentNullException("rootElement");

            var transformFromClientToRoot = element.TransformToVisual(rootElement);
            return transformFromClientToRoot.Transform(new Point(0, 0));
        }

        /// <summary>
        /// Gets total horizontal value of the specified thickness.
        /// </summary>
        /// <param name="thickness">The thickness.</param>
        /// <returns>Horizontal thickness.</returns>
        /// <exception cref="ArgumentNullException">Input parameter is null.</exception>
        public static double Horizontal(this Thickness thickness)
        {
            if (thickness == null)
                throw new ArgumentNullException("thickness");

            return thickness.Left + thickness.Right;
        }

        /// <summary>
        /// Gets total vertical value of the specified thickness.
        /// </summary>
        /// <param name="thickness">The thickness.</param>
        /// <returns>Vertical thickness.</returns>
        /// <exception cref="ArgumentNullException">Input parameter is null.</exception>
        public static double Vertical(this Thickness thickness)
        {
            if (thickness == null)
                throw new ArgumentNullException("thickness");

            return thickness.Top + thickness.Bottom;
        }
    }
}
