﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Shapes;
using MediaStreaming;
using System.Windows.Media.Imaging;
using System.Windows.Media;

namespace WebConferencingSystem.Views
{
    public partial class OnlineUser : UserControl
    {
        public enum CButtonType { TXT, MIC, VIDEO, Files, UserCamWindow, WhiteBoard, PresentationsViewer, SPEAKERS };

        public MediaElement MediaElement = new MediaElement();
        public ChatArea TxtChatWindow; 
        public StreamingMediaSource StreamingMediaSources;
        public RemoteCam RemoteWebCam;

        public event EventHandler ShareVideoClicked;
        public event EventHandler ShareVoiceClicked;
        public event EventHandler StartTextChatClicked;
        public event EventHandler ViewLargeCamClicked;

        public bool IsPublicChat { get; set; }
        public string UserName { get; set; }
        public string AvatarID { get; set; }

        public bool VoiceShared = false;
        public bool VideoShared = false;
        public bool TextShared = false;
        public bool IsMute = false;
        public bool FocusedView = false;



        public OnlineUser(string User_Name,bool IsAllUsers,string User_Role,string Avatar_ID)
        {
            InitializeComponent();

            this.UserNameTXT.Text = UserName = User_Name;
            
            RemoteWebCam = new RemoteCam(User_Name);
            RemoteWebCam.Position = new Point(10, 250);
            RemoteWebCam.SetTitle(UserName);

            IsPublicChat = IsAllUsers;
            UserRoleTXT.Content = User_Role;
            AvatarID = Avatar_ID;
            SetAvatarIMG();

            if (IsAllUsers)
            {
                TextShared = true;
                EnableChattingControl(CButtonType.TXT, true);

                ToolTipService.SetToolTip(TextChat_BTN, "Public Text Chat");
                ToolTipService.SetToolTip(PrivVoice_Chat_BTN, "Share Your Mic With the All Users in this room");
                ToolTipService.SetToolTip(PrivVideo_Chat_BTN, "Share Your WebCam With the All Users in this room");
                ToolTipService.SetToolTip(PubSoundMute_BTN, "Turn off/on Public Speakers");
            }
            else
            {
                ToolTipService.SetToolTip(TextChat_BTN, "Private Text Chat With " + User_Name);
                ToolTipService.SetToolTip(PrivVoice_Chat_BTN, "Share Your Mic with " + User_Name);
                ToolTipService.SetToolTip(PrivVideo_Chat_BTN, "Share Your WebCam with " + User_Name);
                ToolTipService.SetToolTip(PubSoundMute_BTN, "Turn off/on Speakers from " + User_Name);
                ToolTipService.SetToolTip(AvatarIMG, "Double click to view " + User_Name + " webcam on a larger window");
            }

            if (IsAllUsers)
            {
                ellipse1.Fill = new SolidColorBrush(Colors.Red);
            }
            else ellipse1.Fill = new SolidColorBrush(Colors.Green);
        }

        public void ViewReceivedVideoFrame(BitmapImage RImag)
        {
            AvatarIMG.Source = RImag;

            if (FocusedView) RemoteWebCam.ViewReceivedVideoFrame(RImag);
        }

        private void SetAvatarIMG()
        {
            try
            {
                if (AvatarID.Length > 0)
                 AvatarIMG.Source = new BitmapImage(new Uri("/WebConferencingSystem;component/Views/Avatars/" + AvatarID + ".png", UriKind.Relative));
                else
                 AvatarIMG.Source = new BitmapImage(new Uri("/WebConferencingSystem;component/Views/Avatars/00000.png", UriKind.Relative));
            }
            catch {}
        }

        private void Voice_Chat_BTN_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            SenderValue value = new SenderValue();
            value.IsPublic = IsPublicChat;
            value.IsEnabled = !VoiceShared;
            value.TalkingWith = UserName;
            value.UserName = UserName;

            if (VoiceShared)
            {
                EnableChattingControl(CButtonType.MIC, false);
            }
            else
            {
                EnableChattingControl(CButtonType.MIC, true);
            }

            ShareVoiceClicked(value, null);
        }

        private void Video_Chat_BTN_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            SenderValue value = new SenderValue();
            value.IsPublic = IsPublicChat;
            value.IsEnabled = !VideoShared;
            value.TalkingWith = UserName;
            value.UserName = UserName;

            if (VideoShared)
            {
                EnableChattingControl(CButtonType.VIDEO, false);
            }
            else
            {
                EnableChattingControl(CButtonType.VIDEO, true);
            }

            ShareVideoClicked(value, null);

        }

        private void TextChat_BTN_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            SenderValue value = new SenderValue();
            value.IsPublic = IsPublicChat;
            value.IsEnabled = !TextShared;
            value.TalkingWith = UserName;
            value.UserName = UserName;

            if (TextShared)
            {
                EnableChattingControl(CButtonType.TXT, false);
            }
            else
            {
                EnableChattingControl(CButtonType.TXT, true);
            }

            StartTextChatClicked(value, null);
            
        }
        private void SoundMute_BTN_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (IsMute)
            {
                EnableChattingControl(CButtonType.SPEAKERS, true);
            }
            else
            {
                EnableChattingControl(CButtonType.SPEAKERS, false);
            }

            IsMute = !IsMute;
        }

        private void RemoteCam_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (!IsPublicChat)
            if (e.ClickCount == 2)
            {
                if (ViewLargeCamClicked !=null)
                ViewLargeCamClicked(UserName, null);
            }
        }

        public void EnableChattingControl(CButtonType BType, bool Enable)
        {
            try
            {
                if (BType == CButtonType.MIC)
                {
                    BitmapImage Mic_En = new BitmapImage(new Uri("/WebConferencingSystem;component/Views/Images/VoiceChat_EN.png", UriKind.Relative));
                    BitmapImage Mic_Dis = new BitmapImage(new Uri("/WebConferencingSystem;component/Views/Images/VoiceChat_DIS.png", UriKind.Relative));

                    if (Enable)
                    {
                        PrivVoice_Chat_BTN.Source = Mic_En;
                    }
                    else
                    {
                        PrivVoice_Chat_BTN.Source = Mic_Dis;
                    }
                    VoiceShared = Enable;
                }
                else if (BType == CButtonType.VIDEO)
                {
                    BitmapImage Vid_En = new BitmapImage(new Uri("/WebConferencingSystem;component/Views/Images/video_chat.png", UriKind.Relative));
                    BitmapImage Vid_Dis = new BitmapImage(new Uri("/WebConferencingSystem;component/Views/Images/video_chat-d.png", UriKind.Relative));

                    VideoShared = Enable;

                    if (Enable)
                    {
                        PrivVideo_Chat_BTN.Source = Vid_En;
                    }
                    else
                    {
                        PrivVideo_Chat_BTN.Source = Vid_Dis;
                    }
                }
                else if (BType == CButtonType.TXT)
                {
                    BitmapImage Txt_En = new BitmapImage(new Uri("/WebConferencingSystem;component/Views/Images/text_chat.png", UriKind.Relative));
                    BitmapImage Txt_Dis = new BitmapImage(new Uri("/WebConferencingSystem;component/Views/Images/text_chat-d.png", UriKind.Relative));

                    TextShared = Enable;

                    if (Enable)
                    {
                        TextChat_BTN.Source = Txt_En;
                    }
                    else
                    {
                        TextChat_BTN.Source = Txt_Dis;
                    }
                }
                else if (BType == CButtonType.SPEAKERS)
                {
                    BitmapImage SPK_En = new BitmapImage(new Uri("/WebConferencingSystem;component/Views/Images/SPK_EN.png", UriKind.Relative));
                    BitmapImage SPK_Dis = new BitmapImage(new Uri("/WebConferencingSystem;component/Views/Images/SPK_Dis.png", UriKind.Relative));

                    if (Enable)
                    {
                        PubSoundMute_BTN.Source = SPK_En;
                    }
                    else
                    {
                        PubSoundMute_BTN.Source = SPK_Dis;
                    }
                }
            }
            catch { }
        }



    }
}
