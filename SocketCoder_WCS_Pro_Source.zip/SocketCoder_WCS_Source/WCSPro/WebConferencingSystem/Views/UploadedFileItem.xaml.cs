﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using WebConferencingSystem.WCS_Proxy;
using System.IO;
using ICSharpCode.SharpZipLib.Zip.Compression;

namespace WebConferencingSystem.Views
{
    public partial class UploadedFileItem : UserControl
    {

        public event EventHandler DownloadClicked;
        public event EventHandler RemoveClicked;

        public WcsFilePacket PacketInfo { get; set; }

        public UploadedFileItem(WcsFilePacket Received_PacketInfo,string UserName)
        {
            InitializeComponent();

            this.PacketInfo = Received_PacketInfo;
            FileNameLB.Content = PacketInfo.FileName;
            int FileSizeInKB = PacketInfo.FileSize / 1024;
            if (FileSizeInKB > 0) FileSizeLB.Content = FileSizeInKB + " KB";
            else FileSizeLB.Content = PacketInfo.FileSize + " Bytes";

            FileOwnerLB.Content = PacketInfo.UserName;

            if (UserName == PacketInfo.UserName)
                RemoveBTN.Visibility = System.Windows.Visibility.Visible;
            else RemoveBTN.Visibility = System.Windows.Visibility.Collapsed;
        }


        private void DownloadBTN_Click(object sender, RoutedEventArgs e)
        {
            DownloadClicked(PacketInfo,null);
        }

        private void RemoveBTN_Click(object sender, RoutedEventArgs e)
        {
            RemoveClicked(PacketInfo, null);
        }
    }
}
