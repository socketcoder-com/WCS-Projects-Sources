﻿ //(C) SocketCoder.Com 
 //Last Modify: 1/Aug/2014

using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Navigation;
using System.IO;
using System.Net.Sockets;
using System.Windows.Media.Imaging;
using System.Text;
using System.Threading;
using System.ComponentModel;
using System.Windows.Threading;
using WebConferencingSystem.Views.Login;
using WebConferencingSystem.WCS_Proxy;
using MediaStreaming;
using ImageTools;
using System.Diagnostics;
using ICSharpCode.SharpZipLib.Zip.Compression;
using System.Collections.ObjectModel;

namespace WebConferencingSystem.Views
{
    public partial class Home
    {

        #region Global Declarations

        private string WCSServiceName = "WCS Service";
        private string version = "4.0.0.0";
        private string PublicKey = "*All Users*";

        private VideoConferenceServiceClient WCSProxy;
        private WcsPacketizer Packetizer = new WcsPacketizer();
        private LocalWebCam localcam = new LocalWebCam();
        private CaptureDevicesSettings CapturingDevice = new CaptureDevicesSettings();
        private Collaborative board;

        private Dictionary<string, OnlineUser> OnlineUsers = new Dictionary<string, OnlineUser>();
        private Dictionary<string, DesktopViewer> DesktopViewerSessions = new Dictionary<string, DesktopViewer>();

        private DispatcherTimer KeepAliveTimer = new DispatcherTimer();
        private enum CButtonType { TXT, MIC, VIDEO, Files, UserCamWindow, WhiteBoard, PresentationsViewer, SPEAKERS };
        private TextBlock MyName = new TextBlock();
        private bool Joined = false;
        private Login.Login log = new Login.Login();
        private Login.ConnectionLost ConnLost = new Login.ConnectionLost();
        private bool IsConLost = false;

        private RunDesktopSharingTool DSTool;

        // For To Who Voice/Video Sending flags
        private string VideoTalkingWith = "";
        private string VoiceTalkingWith = "";
        private bool   VideoTalkingIsPublic = true;
        private bool   VoiceTalkingIsPublic = true;

        private struct ReceivedStream
        {
            public Stream DataStream;
            public string SentFrom;
            public string SentTo;
        }

     // Encoder/Decoder Threads
        private BackgroundWorker VideoEncoderThread = new BackgroundWorker();
        private BackgroundWorker VideoDecoderThread = new BackgroundWorker();
        private BackgroundWorker DesktopDecoderThread = new BackgroundWorker();

      //For Video Client
        private VideoBrush videoBrush = new VideoBrush();
        private DispatcherTimer VideoSendingTimer = new DispatcherTimer();
       

      //For File Sharing
        private FilesManager FM;

        #endregion Global Declarations

        #region Constructor
        public Home()
        {
            InitializeComponent();

            DateNow.Content = DateTime.Now.ToShortDateString();
            ConnLost.TryAgainClicked += new EventHandler(ConnTryAgain);
            
            CapturingDevice.AllowUsingClicked += new EventHandler(WebCamStart);
            CapturingDevice.DontAllowClicked += new EventHandler(WebCamStop);

            // Voice/Video Capturing/Encoding Async
            CapturingDevice.audiSink.OnBufferFulfill += new EventHandler(SendVoiceBuffer);
            VideoSendingTimer.Interval = new TimeSpan(0, 0, 0, 0, CapturingDevice.FPMS);
            VideoSendingTimer.Tick += new EventHandler(Video_Each_Tick);
            CapturingDevice.Capture_Source.CaptureImageCompleted += new EventHandler<CaptureImageCompletedEventArgs>(VideoFrameEncoding);

            // Keep Alive Timer
            KeepAliveTimer.Interval = new TimeSpan(0, 0, 59);
            KeepAliveTimer.Tick += new EventHandler(KeepAlive_Timer_Tick);


            // Other Services Encoder/Decoder Async
            DesktopDecoderThread.DoWork += new DoWorkEventHandler(DesktopDecoder);


            log.Show();
            log.Closed += (s, args) =>
            {
               JoinBTN_Click(null, null);
            };

        }

        #endregion Constructor

        #region Connection Methods

        void Initiate_Proxy()
        {
            try
            {
                if (WCSProxy != null)
                {
                    WCSProxy.Abort();
                }

                WCSProxy = new VideoConferenceServiceClient();
                WCSProxy.SubscribeCompleted += new EventHandler<SubscribeCompletedEventArgs>(OnSubscribed);
                WCSProxy.UnSubscribeCompleted += new EventHandler<AsyncCompletedEventArgs>(UnSubscribeCompleted);
                WCSProxy.OpenCompleted += new EventHandler<AsyncCompletedEventArgs>(OnOpened);
                WCSProxy.CloseCompleted += new EventHandler<AsyncCompletedEventArgs>(OnClosed);
                WCSProxy.OnSyncUsersListReceived += new EventHandler<OnSyncUsersListReceivedEventArgs>(OnSynchronizeUsersList);
                WCSProxy.OnTextSendReceived += new EventHandler<OnTextSendReceivedEventArgs>(OnTextReceived);
                WCSProxy.OnVideoSendReceived += new EventHandler<OnVideoSendReceivedEventArgs>(OnVideoReceived);
                WCSProxy.OnVoiceSendReceived += new EventHandler<OnVoiceSendReceivedEventArgs>(OnVoiceReceived);
                WCSProxy.OnFileUploadedReceived += new EventHandler<OnFileUploadedReceivedEventArgs>(OnSyncFilesListReceived);
                WCSProxy.OnDrawingSendReceived += new EventHandler<OnDrawingSendReceivedEventArgs>(OnDrawingReceived);
                WCSProxy.OnCollaborativeBoardSyncReceived += new EventHandler<OnCollaborativeBoardSyncReceivedEventArgs>(OnCollaborativeSyncReceived);
                WCSProxy.OnDesktopSendReceived += new EventHandler<OnDesktopSendReceivedEventArgs>(OnDesktopReceived);
                WCSProxy.get_MaxFileSizeCompleted += new EventHandler<get_MaxFileSizeCompletedEventArgs>(GetMaxFileSizeCompleted);
                WCSProxy.UploadFileCompleted += new EventHandler<AsyncCompletedEventArgs>(UploadFileCompleted);
                WCSProxy.DownloadFileCompleted += new EventHandler<DownloadFileCompletedEventArgs>(DownloadFileCompleted);
                WCSProxy.RemoveFileCompleted += new EventHandler<AsyncCompletedEventArgs>(RemoveFileCompleted);
                WCSProxy.OpenAsync();

            }
            catch { }
        }

        private void JoinBTN_Click(object sender, MouseButtonEventArgs e)
        {
            try
            {
                if (log.Isvalid())
                {
                    if (!Joined)
                    {
                        ConnectingWaitLB.Visibility = System.Windows.Visibility.Visible;

                        Initiate_Proxy();
                    }
                    else
                    {
                        DisConnect();
                        log.Show();
                    }
                }
                else
                {
                    DisConnect();
                    log.Show();
                }
            }
            catch { }
        }

        void DisConnect()
        {
            try
            {
                if (WCSProxy != null)
                     WCSProxy.Abort();

                IsConLost = false;

                WebCamStop(null, null);

                if ( CapturingDevice.audiSink != null)
                 CapturingDevice.audiSink.IsVoiceSendingStarted = false;

                    Joined = false;
                    log.NickNameTextBox.Text = "";
                    StopTalking();
                    StopSendingWebCam();
                    EnableUsing(false);

                    if (FM != null)
                    {
                        FM.ClearFilesList();
                        NumberOfFilesLB.Content = "0";
                    }

                ChattersListbox.Items.Clear();
                RoomTitle.Content = UserNameLB.Content = "";
                KeepAliveTimer.Stop();
                OnlineUsers.Clear();
                DesktopViewerSessions.Clear();
                Dashboard.CloseAllWindows();
            }
            catch { }
        }

        void InnerChannel_Faulted(object sender, EventArgs e)
        {
            try
            {
                Deployment.Current.Dispatcher.BeginInvoke(() =>
                {
                    AutoTryToCon(true);
                });
            }
            catch { }
        }

        private void KeepAlive_Timer_Tick(object sender, EventArgs e)
        {
            try
            {
                if (WCSProxy.State == System.ServiceModel.CommunicationState.Opened)
                {
                    DateNow.Content = DateTime.Now.ToShortDateString() + " " + DateTime.Now.ToShortTimeString();
                    WCSProxy.SendCMDAsync(Packetizer.GetObject(WCSServiceName, log.UserName, log.RoomID, "Sync", TXTPayloadType.Sync, false));
                }
            }
            catch { }
        }

        private void ConnTryAgain(object sender, EventArgs e)
        {
            if (ConnLost.DialogResult == true)
                try
                {
                    Initiate_Proxy();
                }
                catch { }
            else AutoTryToCon(false);
        }

        void OnOpened(object sender, AsyncCompletedEventArgs e)
        {
            try
            {
                if (e.Error != null)
                {
                    Deployment.Current.Dispatcher.BeginInvoke(() =>
                    {
                        if (Joined)
                            AutoTryToCon(true);

                        else
                        {
                            DisConnect();
                            log.ErrorMSG.Content = "Cannot Connect With The WCS Service!";
                            log.Show();
                        }

                    });
                }
                else
                {

                    WCSProxy.InnerChannel.Faulted += new EventHandler(InnerChannel_Faulted);

                    if (IsConLost)
                        WCSProxy.UnSubscribeAsync(Packetizer.GetObject(WCSServiceName, log.UserName, log.RoomID, "UnSubscribe", TXTPayloadType.UnSubscribe, false));

                    else
                        WCSProxy.SubscribeAsync(Packetizer.GetObject(log.RoomID, log.UserName, "00000", UserInRole.Participant, UserType.Guest, version), Packetizer.GetObject(log.RoomID, 500));

                    if (Joined)
                    {
                        Deployment.Current.Dispatcher.BeginInvoke(() =>
                        {
                            AutoTryToCon(false);
                        });
                    }
                    else if (!Joined & WCSProxy.State == System.ServiceModel.CommunicationState.Opened)
                    {
                        Deployment.Current.Dispatcher.BeginInvoke(() =>
                        {
                            RoomTitle.Content = log.RoomID;
                            DSTool = new RunDesktopSharingTool(log.RoomID, log.UserName);

                            OnlineUsers.Add(PublicKey, new OnlineUser(PublicKey, true, "Public Chat", "AllUsers"));
                            OnlineUsers[PublicKey].TxtChatWindow = new ChatArea(log.RoomID, log.UserName, log.RoomID, WCSServiceName, true);
                            OnlineUsers[PublicKey].TxtChatWindow.SendDrawingClicked += new EventHandler(SendDrawingBTN_Click);
                            OnlineUsers[PublicKey].TxtChatWindow.SendTextClicked += new EventHandler(SendRichBTN_Click);
                            OnlineUsers[PublicKey].ShareVideoClicked += new EventHandler(Video_Chat_BTN_MouseLeftButtonUp);
                            OnlineUsers[PublicKey].ShareVoiceClicked += new EventHandler(Voice_Chat_BTN_MouseLeftButtonUp);
                            OnlineUsers[PublicKey].StartTextChatClicked += new EventHandler(StartTextChat);
                            OnlineUsers[PublicKey].Foreground = new SolidColorBrush(Colors.Red);
                            Dashboard.Add(OnlineUsers[PublicKey].TxtChatWindow);
                            OnlineUsers[PublicKey].TxtChatWindow.Show();
                            OnlineUsers[PublicKey].TxtChatWindow.RestoreSizeAndPosition();
                            OnlineUsers[PublicKey].TxtChatWindow.RestoreWindow();
                            ChattersListbox.Items.Clear();
                            ChattersListbox.Items.Add(OnlineUsers[PublicKey]);

                            Joined = true;
                        });
                    }
                }
            }
            catch { }
            finally {try{ConnectingWaitLB.Visibility = System.Windows.Visibility.Collapsed;}catch { }}
        }

        void UnSubscribeCompleted(object sender, AsyncCompletedEventArgs e)
        {
            if (IsConLost)
               WCSProxy.SubscribeAsync(Packetizer.GetObject(log.RoomID, log.UserName, "00000", UserInRole.Participant, UserType.Guest, version), Packetizer.GetObject(log.RoomID, 500));
            IsConLost = false;
        }

        void OnClosed(object sender, AsyncCompletedEventArgs e)
        {
            try
            {
                if (e.Error != null)
                {
                    OnlineUsers[PublicKey].TxtChatWindow.ShowErrorMessageBox(e.Error.Message);
                }
            }
            catch { }
        }

        void OnSubscribed(object sender, SubscribeCompletedEventArgs e)
        {
            try
            {
                if (e.Error != null)
                {
                    Deployment.Current.Dispatcher.BeginInvoke(() =>
                    {
                        OnlineUsers[PublicKey].TxtChatWindow.ShowErrorMessageBox(e.Error.Message);
                        EnableUsing(false);
                    });
                }
                else if (e.Result == IssueStatus.Done)
                    Deployment.Current.Dispatcher.BeginInvoke(() =>
                    {
                        EnableUsing(true);
                    });
                else if (e.Result == IssueStatus.BlockedUser)
                {
                    Deployment.Current.Dispatcher.BeginInvoke(() =>
                    {
                        OnlineUsers[PublicKey].TxtChatWindow.ShowErrorMessageBox("Sorry your User Name has been blocked by the system admin!");
                        EnableUsing(false);
                    });

                }
                else if (e.Result == IssueStatus.MaxUsersExceeded)
                {
                    Deployment.Current.Dispatcher.BeginInvoke(() =>
                    {
                        OnlineUsers[PublicKey].TxtChatWindow.ShowErrorMessageBox("Maximum Users Exceeded! Please try to join to another room or try again later");
                        EnableUsing(false);
                    });

                }
                else if (e.Result == IssueStatus.NotValid)
                {
                    Deployment.Current.Dispatcher.BeginInvoke(() =>
                    {
                        OnlineUsers[PublicKey].TxtChatWindow.ShowErrorMessageBox("Sorry You are not valid to join to this room!");
                        EnableUsing(false);
                    });

                }
                else if (e.Result == IssueStatus.UserIDAlreadyInUse)
                {
                    Deployment.Current.Dispatcher.BeginInvoke(() =>
                    {
                        OnlineUsers[PublicKey].TxtChatWindow.ShowErrorMessageBox("The Username is already being used, please leave the room and join again using different username");
                        EnableUsing(false);
                    });

                }
                else if (e.Result == IssueStatus.OldVersion)
                {
                    Deployment.Current.Dispatcher.BeginInvoke(() =>
                    {
                        OnlineUsers[PublicKey].TxtChatWindow.ShowErrorMessageBox("You are using an older version of WCS Pro, please remove this version and install it again from the website!");
                        EnableUsing(false);
                    });

                }
            }
            catch { }
            finally { }
        }

        private void EnableUsing(bool value)
        {
            try
            {
                if (value)
                {

                    if (!CapturingDevice.AllowUsing)
                    {
                        CapturingDevice.Show();
                    }

                    if (FM == null)
                    {
                        FM = new FilesManager();
                        FM.UploadClicked += new EventHandler(FileUploadClick);
                    }

                    board = new Collaborative(true);
                    board.page1.OnDrawingToSend += new EventHandler(SenderSyncDrawingEvent);


                    FM.Initiate(log.UserName, log.RoomID);

                    // Get The new uploaded files if any
                    if (WCSProxy.State == System.ServiceModel.CommunicationState.Opened)
                    {
                        WCSProxy.get_MaxFileSizeAsync();
                        WCSProxy.SynchronizeFilesListAsync(Packetizer.GetObject(log.UserName, log.RoomID, new byte[0], "", "", "", 0, BinaryPayloadType.File, true));
                    }

                    if (ChattersListbox.Items.Contains(OnlineUsers[PublicKey]))
                        ChattersListbox.SelectedItem = OnlineUsers[PublicKey];

                    if (FM != null)
                        FM.EnableFileControl(value);

                    DateNow.Content = DateTime.Now.ToShortDateString() + " " + DateTime.Now.ToShortTimeString();
                    KeepAliveTimer.Start();
                }

                ChattersListbox.IsEnabled = value;

                foreach (var userKey in OnlineUsers)
                {
                    OnlineUsers[userKey.Key].TxtChatWindow.EnableControl(value);
                }

            }
            catch { }
        }

        private void Page_Unloaded(object sender, RoutedEventArgs e)
        {
            DisConnect();
        }

        void AutoTryToCon(bool value)
        {
            if (Joined & value)
            {
                IsConLost = true;
                ConnLost.Show();
                ConnLost.StartTimer();
            }
            else if (Joined & !value)
            {
                ConnLost.DialogResult = false;
                ConnLost.StopTimer();

                if (WCSProxy.State != System.ServiceModel.CommunicationState.Opened)
                {
                    OnlineUsers[PublicKey].TxtChatWindow.ShowErrorMessageBox("You have canceled the auto connect mode and you still offline! to use the system you must be connected, to try to connect again now, you have to leave and join the room again");
                    
                    EnableUsing(false);
                }

            }
        }
        #endregion Connection Methods

        #region TextClient

        private void SendTextMessage(string TXTMSG, string SendTO, bool IsPublic)
        {
            if (WCSProxy.InnerChannel.State == System.ServiceModel.CommunicationState.Opened)
                try
                {
                    if (TXTMSG.Length > 3)
                    {
                        WcsTxtPacket packet = Packetizer.GetObject(SendTO, log.UserName, log.RoomID, TXTMSG, TXTPayloadType.TxtMsg, IsPublic);
                        WCSProxy.PublishTextAsync(packet);
                        ReceivedTXTData_Analyzer(packet);
                    }
                }
                catch { }
        }

        void StartTextChat(object sender, EventArgs e)
        {
            SenderValue sentvalue = (SenderValue)sender;

            if (sentvalue.IsPublic)
            {
                if (sentvalue.IsEnabled)
                {
                    Dashboard.Add(OnlineUsers[PublicKey].TxtChatWindow);
                    OnlineUsers[PublicKey].TxtChatWindow.Show();
                    OnlineUsers[PublicKey].TxtChatWindow.RestoreSizeAndPosition();
                    OnlineUsers[PublicKey].TxtChatWindow.RestoreWindow();
                }
                else
                {
                    Dashboard.Remove(OnlineUsers[sentvalue.UserName].TxtChatWindow);
                }
            }
            if (OnlineUsers.ContainsKey(sentvalue.UserName))
            {
                if (sentvalue.IsEnabled)
                {
                    Dashboard.Add(OnlineUsers[sentvalue.UserName].TxtChatWindow);
                    OnlineUsers[sentvalue.UserName].TxtChatWindow.Show();
                    OnlineUsers[sentvalue.UserName].TxtChatWindow.RestoreSizeAndPosition();
                    OnlineUsers[sentvalue.UserName].TxtChatWindow.RestoreWindow();
                }
                else
                {
                    Dashboard.Remove(OnlineUsers[sentvalue.UserName].TxtChatWindow);
                }
            }
        }

        void OnTextReceived(object sender, OnTextSendReceivedEventArgs e)
        {
            try
            {
                if (e.Error != null)
                {
                    OnlineUsers[PublicKey].TxtChatWindow.ShowErrorMessageBox(e.Error.Message);
                }
                else
                {
                    ReceivedTXTData_Analyzer(e.TxtPacket);
                }
            }
            catch { }
        }

        void ReceivedTXTData_Analyzer(WCS_Proxy.WcsTxtPacket RM)
        {
            try
            {
                switch (RM.PayloadType)
                {
                    case TXTPayloadType.UnSubscribe:
                        {
                            DropFromUsersList(RM.Message);
                        }
                        break;
                    case TXTPayloadType.TxtMsg:
                        {
                            if (RM.IsPublic)
                            {
                                if (!Dashboard.Children.Contains(OnlineUsers[PublicKey].TxtChatWindow))
                                {
                                    OnlineUsers[PublicKey].EnableChattingControl(OnlineUser.CButtonType.TXT, true);
                                    Dashboard.Add(OnlineUsers[PublicKey].TxtChatWindow);
                                    OnlineUsers[PublicKey].TxtChatWindow.Show();
                                    OnlineUsers[PublicKey].TxtChatWindow.RestoreSizeAndPosition();
                                    OnlineUsers[PublicKey].TxtChatWindow.RestoreWindow();
                                }

                                OnlineUsers[PublicKey].TxtChatWindow.AddMSGToChatList(RM.UserName, RM.To, RM.Message);

                            }
                            else if (OnlineUsers.ContainsKey(RM.UserName))
                            {

                                if (!Dashboard.Children.Contains(OnlineUsers[RM.UserName].TxtChatWindow))
                                {
                                    OnlineUsers[RM.UserName].EnableChattingControl(OnlineUser.CButtonType.TXT, true);
                                    Dashboard.Add(OnlineUsers[RM.UserName].TxtChatWindow);
                                    OnlineUsers[RM.UserName].TxtChatWindow.Show();
                                    OnlineUsers[RM.UserName].TxtChatWindow.RestoreSizeAndPosition();
                                    OnlineUsers[RM.UserName].TxtChatWindow.RestoreWindow();
                                }

                                 OnlineUsers[RM.UserName].TxtChatWindow.AddMSGToChatList(RM.UserName, RM.To, RM.Message);
                                
                            }

                            break;
                        }
                    case TXTPayloadType.CCall:
                        {

                        }
                        break;
                    case TXTPayloadType.CAccepted:
                        {

                        }
                        break;
                    case TXTPayloadType.CRejected:
                        {

                        }
                        break;
                    case TXTPayloadType.CEnded:
                        {

                        }
                        break;
                    case TXTPayloadType.CBusy:
                        {

                        }
                        break;
                }
            }
            catch { }
        }

        void OnSynchronizeUsersList(object sender, OnSyncUsersListReceivedEventArgs e)
        {
            if (e.Error == null)
                try
                {

                    var UsersList = e.UsersList;

                    // Add the online users
                    foreach (KeyValuePair<string, UserInfoPacket> User in UsersList)
                    {
                        AddToUsersList(User.Value);
                    }

                    // Drop the offile users
                    foreach (OnlineUser UserInList in ChattersListbox.Items.ToArray())
                    {
                        if (UserInList.UserName != PublicKey)
                        {
                            if (!UsersList.ContainsKey(UserInList.UserName.ToString()))
                            {
                                DropFromUsersList((UserInList.UserName));
                            }
                        }
                    }
                }
                catch (Exception ex) { OnlineUsers[PublicKey].TxtChatWindow.ShowErrorMessageBox(ex.Message); }
            else OnlineUsers[PublicKey].TxtChatWindow.ShowErrorMessageBox(e.Error.Message);
        }

        private void ChattersListbox_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {

        }

        private void AddToUsersList(UserInfoPacket UserInfo)
        {
            try
            {
                if (UserInfo.UserName != WCSServiceName)
                {
                    if (UserInfo.UserName == log.UserName)
                    {
                        UserNameLB.Content = "Welcome, " + UserInfo.UserName;
                    }
                    else if (!OnlineUsers.ContainsKey(UserInfo.UserName))
                    {
                        OnlineUsers[UserInfo.UserName] = new OnlineUser(UserInfo.UserName, false, UserInfo.Role.ToString(), UserInfo.AvatarID);
                        OnlineUsers[UserInfo.UserName].TxtChatWindow = new ChatArea(UserInfo.UserName, log.UserName, log.RoomID, WCSServiceName, false);
                        OnlineUsers[UserInfo.UserName].TxtChatWindow.Position = new Point(10, 10);
                        OnlineUsers[UserInfo.UserName].TxtChatWindow.SendDrawingClicked += new EventHandler(SendDrawingBTN_Click);
                        OnlineUsers[UserInfo.UserName].TxtChatWindow.SendTextClicked += new EventHandler(SendRichBTN_Click);
                        OnlineUsers[UserInfo.UserName].ShareVideoClicked += new EventHandler(Video_Chat_BTN_MouseLeftButtonUp);
                        OnlineUsers[UserInfo.UserName].ShareVoiceClicked += new EventHandler(Voice_Chat_BTN_MouseLeftButtonUp);
                        OnlineUsers[UserInfo.UserName].StartTextChatClicked += new EventHandler(StartTextChat);
                        OnlineUsers[UserInfo.UserName].ViewLargeCamClicked += new EventHandler(WebCamLargeViewClicked);
                        ChattersListbox.Items.Add(OnlineUsers[UserInfo.UserName]);
                    }
                    else if (!ChattersListbox.Items.Contains(OnlineUsers[UserInfo.UserName])) 
                        ChattersListbox.Items.Add(OnlineUsers[UserInfo.UserName]);

                }
            }
            catch { }
        }

        private void DropFromUsersList(string UserName)
        {
            try
            {
                if (OnlineUsers.ContainsKey(UserName))
                {
                    ChattersListbox.Items.Remove(OnlineUsers[UserName]);

                    if (OnlineUsers[UserName].TxtChatWindow!=null) Dashboard.Remove(OnlineUsers[UserName].TxtChatWindow);
                    if (OnlineUsers[UserName].RemoteWebCam != null) Dashboard.Remove(OnlineUsers[UserName].RemoteWebCam);
                    if (DesktopViewerSessions.ContainsKey(UserName + " Desktop")) Dashboard.Remove(DesktopViewerSessions[UserName + " Desktop"]);

                    OnlineUsers.Remove(UserName);
                }

                if (CapturingDevice.audiSink != null)
                    if ((CapturingDevice.audiSink.IsVoiceSendingStarted) && (UserName == VoiceTalkingWith))
                    {
                        StopTalking();
                    }

                if (UserName == VideoTalkingWith) StopSendingWebCam();
            }
            catch { }
        }

        private void SendRichBTN_Click(object sender, EventArgs e)
        {
            WcsTxtPacket packet = (WcsTxtPacket)sender;
            if (WCSProxy.State == System.ServiceModel.CommunicationState.Opened)
                WCSProxy.PublishTextAsync(packet);
        }
        #endregion TextClient

        #region DrawingClient
        private void CollaborationBoard_BTN_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (board != null)
            {
                if (!Dashboard.Children.Contains(board))
                {
                    Dashboard.Add(board);
                    board.Show();
                }
            }
        }

        public void SenderSyncDrawingEvent(object sender, EventArgs e)
        {
            if (WCSProxy.State == System.ServiceModel.CommunicationState.Opened & board != null)
            try
            {
                Whiteboard.Client.SenderSyncDrawing data = (Whiteboard.Client.SenderSyncDrawing)sender;
                WCSProxy.CollaborativeBoardSyncAsync(Packetizer.GetObject(log.RoomID, log.UserName, log.RoomID, data.Data_Buffer, BinaryPayloadType.Drawing, true, true), data.DataType);
            }
            catch{}
        }

        void OnCollaborativeSyncReceived(object sender, OnCollaborativeBoardSyncReceivedEventArgs e)
        {
            try
            {
                if ((board != null) & (e.Error == null))
                {
                    if (!Dashboard.Children.Contains(board))
                    {
                        Dashboard.Add(board);
                        board.Show();
                    }
                    
                    Deployment.Current.Dispatcher.BeginInvoke(() =>
                    {
                        board.page1.SetReceivedDrawing(e.DataInBytes, e.ControlType);
                        board.DrawingWith(e.DrawingFrom);
                    });

                }
                else if (e.Error != null)
                {
                    OnlineUsers[PublicKey].TxtChatWindow.ShowErrorMessageBox(e.Error.Message);
                }
            }
            catch { }
        }

        void OnDrawingReceived(object sender, OnDrawingSendReceivedEventArgs e)
        {
            try
            {
                if (e.Error != null)
                {
                    OnlineUsers[PublicKey].TxtChatWindow.ShowErrorMessageBox(e.Error.Message);
                }
                else
                {
                    try
                    {
                        if (e.BinaryPacket.IsPublic)
                        {
                            if (OnlineUsers.ContainsKey(PublicKey))
                            {
                                if (!Dashboard.Children.Contains(OnlineUsers[PublicKey].TxtChatWindow))
                                {
                                    OnlineUsers[PublicKey].EnableChattingControl(OnlineUser.CButtonType.TXT, true);
                                    Dashboard.Add(OnlineUsers[PublicKey].TxtChatWindow);
                                    OnlineUsers[PublicKey].TxtChatWindow.Show();
                                    OnlineUsers[PublicKey].TxtChatWindow.RestoreSizeAndPosition();
                                    OnlineUsers[PublicKey].TxtChatWindow.RestoreWindow();
                                }

                                OnlineUsers[PublicKey].TxtChatWindow.DrawingDecoderThread.RunWorkerAsync(e.BinaryPacket);
                            }
                        }

                        else if (OnlineUsers.ContainsKey(e.BinaryPacket.UserName))
                        {

                            if (!Dashboard.Children.Contains(OnlineUsers[e.BinaryPacket.UserName].TxtChatWindow))
                            {
                                OnlineUsers[e.BinaryPacket.UserName].EnableChattingControl(OnlineUser.CButtonType.TXT, true);
                                Dashboard.Add(OnlineUsers[e.BinaryPacket.UserName].TxtChatWindow);
                                OnlineUsers[e.BinaryPacket.UserName].TxtChatWindow.Show();
                                OnlineUsers[e.BinaryPacket.UserName].TxtChatWindow.RestoreSizeAndPosition();
                                OnlineUsers[e.BinaryPacket.UserName].TxtChatWindow.RestoreWindow();
                            }

                            OnlineUsers[e.BinaryPacket.UserName].TxtChatWindow.DrawingDecoderThread.RunWorkerAsync(e.BinaryPacket);
                        }
                    }
                    catch { }
                }
            }
            catch { }
        }

        private void SendDrawingBTN_Click(object sender, EventArgs e)
        {
            if (WCSProxy.State == System.ServiceModel.CommunicationState.Opened)
                WCSProxy.PublishDrawingAsync((WcsBinaryPacket)sender);
        }

        #endregion DrawingClient

        #region VideoClient

        void WebCamStart(object sender, EventArgs e)
        {
            // Start The Camera
            if (CapturingDevice.AllowUsing & CapturingDevice.HaveCam)
            {
                try
                {
                    localcam.Position = new Point(10, 370);

                    Dashboard.Add(localcam);
                    localcam.Show();
                    localcam.RestoreSizeAndPosition();
                    localcam.RestoreWindow();

                    videoBrush.SetSource(CapturingDevice.Capture_Source);
                    localcam.MyCameraIMG.Fill = videoBrush;
                }
                catch { }
            }
        }

        void WebCamStop(object sender, EventArgs e)
        {
            try
            {
                Dashboard.Remove(localcam);

                CapturingDevice.StopCapturing();
                StopSendingWebCam();
                StopTalking();
            }
            catch { }
        }

        ////////////////////////////// Video Sending and Encoding /////////////////////////////////////////////////////////////////

        void StartSendingWebCam()
        {
            try
            {
                VideoSendingTimer.Start();
            }
            catch { }
        }

        void StopSendingWebCam()
        {
            try
            {
                VideoSendingTimer.Stop();
            }
            catch { }
        }

        public void Video_Each_Tick(object sender, EventArgs e)
        {
            try
            {
                CapturingDevice.Capture_Source.CaptureImageAsync();

                if (CapturingDevice.FPMS != VideoSendingTimer.Interval.Milliseconds)
                {
                    VideoSendingTimer.Interval = new TimeSpan(0, 0, 0, 0, CapturingDevice.FPMS);
                }
            }
            catch { }
        }

        private void VideoFrameEncoding(object sender, CaptureImageCompletedEventArgs e)
        {
            byte[] buffer = ImageEcoderDecoder.JpegEncode(e.Result.ToImage(), CapturingDevice.ImageQuality, true);

            if (WCSProxy.InnerChannel.State == System.ServiceModel.CommunicationState.Opened)
            if (VideoTalkingWith != "")
            {
                if (VideoTalkingIsPublic)
                WCSProxy.PublishVideoAsync(Packetizer.GetObject(log.RoomID, log.UserName, log.RoomID, buffer, BinaryPayloadType.Video,true, VideoTalkingIsPublic));
                else
                    WCSProxy.PublishVideoAsync(Packetizer.GetObject(VideoTalkingWith, log.UserName, log.RoomID, buffer, BinaryPayloadType.Video, true, VideoTalkingIsPublic));
            }
        }

        ////////////////////////////// Video Receiving and Decoding /////////////////////////////////////////////////////////////////

        void OnVideoReceived(object sender, OnVideoSendReceivedEventArgs e)
        {
            try
            {
                if (e.Error != null)
                {
                    OnlineUsers[PublicKey].TxtChatWindow.ShowErrorMessageBox(e.Error.Message);
                }
                else
                {
                    try
                    {
                        WcsBinaryPacket RD = e.BinaryPacket;
                        if (RD.DataBuffer != null)
                        {
                            ReceivedStream rbm = new ReceivedStream();
                            rbm.DataStream = ImageEcoderDecoder.Decoder(RD.DataBuffer, RD.IsCompressed);
                            rbm.SentFrom = RD.UserName;

                            Deployment.Current.Dispatcher.BeginInvoke(() =>
                            {
                                ViewReceivedVideoFrame(rbm);
                            });
                        }
                    }
                    catch { }
                }
            }
            catch { }
        }

        private void ViewReceivedVideoFrame(ReceivedStream RBM)
        {
            try
            {
                if (RBM.DataStream != null)
                {
                    var bi = new BitmapImage();
                    bi.SetSource(RBM.DataStream);

                    if (OnlineUsers.ContainsKey(RBM.SentFrom))
                    {
                        OnlineUsers[RBM.SentFrom].ViewReceivedVideoFrame(bi);
                    }
                }
            }
            catch { }
        }

        private void Video_Chat_BTN_MouseLeftButtonUp(object sender, EventArgs e)
        {
            
            try
            {
                SenderValue SentValue = (SenderValue)sender;
                VideoTalkingIsPublic = SentValue.IsPublic;
                VideoTalkingWith = SentValue.TalkingWith;

                string TalkingWith = VoiceTalkingWith;

                if (OnlineUsers.ContainsKey(VideoTalkingWith))

                if (CapturingDevice.HaveCam & !CapturingDevice.AllowUsing)
                {
                    CapturingDevice.Show();
                    OnlineUsers[VideoTalkingWith].EnableChattingControl(OnlineUser.CButtonType.VIDEO, false);
                }
                else if (!CapturingDevice.HaveCam)
                {
                   OnlineUsers[VideoTalkingWith].EnableChattingControl(OnlineUser.CButtonType.VIDEO, false);
                }
                else if (CapturingDevice.HaveCam & CapturingDevice.AllowUsing)
                {
                    if (SentValue.IsEnabled)
                    {
                        foreach (var value in OnlineUsers)
                        {
                            if (value.Key != SentValue.TalkingWith)
                                OnlineUsers[value.Key].EnableChattingControl(OnlineUser.CButtonType.VIDEO, false);
                        }

                        StartSendingWebCam();
                    }
                    else
                    {
                        StopSendingWebCam();
                    }
                }
                else StopSendingWebCam();

            }
            catch { }
        }

        void WebCamLargeViewClicked(object sender, EventArgs e)
        {
            string CamUserName = sender.ToString();
            if (OnlineUsers.ContainsKey(CamUserName))
            {
                Dashboard.Add(OnlineUsers[CamUserName].RemoteWebCam);

                OnlineUsers[CamUserName].RemoteWebCam.Show();
                OnlineUsers[CamUserName].RemoteWebCam.RestoreSizeAndPosition();
                OnlineUsers[CamUserName].RemoteWebCam.RestoreWindow();

                OnlineUsers[CamUserName].FocusedView = true;

                OnlineUsers[CamUserName].RemoteWebCam.Closed += (s, args) =>
                {
                    OnlineUsers[CamUserName].FocusedView = false;
                };
            }
        }

        #endregion Encoder/Decoder VideoClient

        #region VoiceClient

        private void StartTalking()
        {
            try
            {
                if (CapturingDevice.HaveMic & VoiceTalkingWith != "")
                {
                    CapturingDevice.audiSink.IsVoiceSendingStarted = true;
                }
            }
            catch { }
        }

        private void StopTalking()
        {
            if (CapturingDevice.audiSink != null)
            CapturingDevice.audiSink.IsVoiceSendingStarted = false;
        }

        void SendVoiceBuffer(object VoiceBuffer, EventArgs e)
        {
            try
            {
                byte[] EncodedBuffer = (byte[])VoiceBuffer;

                if (CapturingDevice.audiSink != null)

                    if (CapturingDevice.audiSink.IsVoiceSendingStarted & WCSProxy.InnerChannel.State == System.ServiceModel.CommunicationState.Opened & !CapturingDevice.isPlayback)
                {
                    if (VoiceTalkingIsPublic)
                    {

                        WCSProxy.PublishVoiceAsync(Packetizer.GetObject(log.RoomID, log.UserName, log.RoomID, EncodedBuffer, CapturingDevice.BitsPerSample,
                        CapturingDevice.SamplesPerSecond, CapturingDevice.Channels, BinaryPayloadType.Voice, VoiceTalkingIsPublic));
                    }
                    else
                    {
                        WCSProxy.PublishVoiceAsync(Packetizer.GetObject(VoiceTalkingWith, log.UserName, log.RoomID, EncodedBuffer, CapturingDevice.BitsPerSample, 
                         CapturingDevice.SamplesPerSecond, CapturingDevice.Channels, BinaryPayloadType.Voice, VoiceTalkingIsPublic));

                    }

                }
                else if (CapturingDevice.isPlayback)
                {
                    Deployment.Current.Dispatcher.BeginInvoke(() =>
                    {
                        PlayPlaybackBuffer(EncodedBuffer);
                    });
                }
            }
            catch { }
        }

        void InitiateUserVoicePlayback(string FromUserName, int UserBitsPerSample, int UserSamplesPerSecond, int UserChannels)
        {
           if (OnlineUsers.ContainsKey(FromUserName))
           if (OnlineUsers[FromUserName].StreamingMediaSources == null) // If a new user
            {
                try
                {
                    // Initiate a New User Media Source
                    OnlineUsers[FromUserName].StreamingMediaSources = new StreamingMediaSource(UserBitsPerSample, UserSamplesPerSecond, UserChannels);
    
                    // Setup The User MediaElement 
                    OnlineUsers[FromUserName].MediaElement.SetSource(OnlineUsers[FromUserName].StreamingMediaSources);
                    OnlineUsers[FromUserName].MediaElement.Volume = 1.0;
                    OnlineUsers[FromUserName].MediaElement.AutoPlay = true;
                }
                catch { }
            }
            else
            {
                try
                {
                    // Update Voice Format if Changed.
                    OnlineUsers[FromUserName].StreamingMediaSources.UpdateVoiceFormat(UserBitsPerSample, UserSamplesPerSecond, UserChannels);
                }
                catch { }
            }
        }

        void OnVoiceReceived(object sender, OnVoiceSendReceivedEventArgs e)
        {
            try
            {
                if (e.Error != null)
                {
                    OnlineUsers[PublicKey].TxtChatWindow.ShowErrorMessageBox(e.Error.Message);
                }
                else
                {
                    QueueVoiceReceivedBuffer(e.AudioPacket);
                }
            }
            catch { }
        }

        private void PlayPlaybackBuffer(byte[] ByteFullBuffer)
        {
            try
            {
                if (CapturingDevice.PlaybackTestSMSource == null)
                {
                    CapturingDevice.PlaybackTestSMSource = new StreamingMediaSource(CapturingDevice.BitsPerSample, CapturingDevice.SamplesPerSecond, CapturingDevice.Channels);
                    CapturingDevice.PlaybackTestME.SetSource(CapturingDevice.PlaybackTestSMSource);
                    CapturingDevice.PlaybackTestME.Volume = 1.0;
                    CapturingDevice.PlaybackTestME.AutoPlay = true;
                }
                else CapturingDevice.PlaybackTestSMSource.PushBufferToQueue(ByteFullBuffer);
            }
            catch { }
        }

        private void QueueVoiceReceivedBuffer(WcsAudioPacket RD)
        {
            try
            {
                if (RD.DataBuffer != null & OnlineUsers.ContainsKey(RD.UserName))
                    if (RD.DataBuffer.Length > 0 & !OnlineUsers[RD.UserName].IsMute)
                    {
                        InitiateUserVoicePlayback(RD.UserName, RD.AudioFormatBits, RD.AudioFormatSamples, RD.AudioFormatChannels);
                        OnlineUsers[RD.UserName].StreamingMediaSources.PushBufferToQueue(RD.DataBuffer);
                    }
            }
            catch { }
        }


        private void Voice_Chat_BTN_MouseLeftButtonUp(object sender, EventArgs e)
        {
            try
            {
                SenderValue SentValue = (SenderValue)sender;
                VoiceTalkingIsPublic = SentValue.IsPublic;

                VoiceTalkingWith = SentValue.TalkingWith;

                if (OnlineUsers.ContainsKey(VoiceTalkingWith))
                    if (CapturingDevice.HaveMic & !CapturingDevice.AllowUsing)
                    {
                        OnlineUsers[VoiceTalkingWith].EnableChattingControl(OnlineUser.CButtonType.MIC, false);
                        CapturingDevice.Show();
                    }
                    else if (!CapturingDevice.HaveMic)
                    {
                        OnlineUsers[VoiceTalkingWith].EnableChattingControl(OnlineUser.CButtonType.MIC, false);
                    }
                    else if (CapturingDevice.HaveMic & CapturingDevice.AllowUsing)
                    {
                        if (SentValue.IsEnabled)
                        {
                            foreach (var value in OnlineUsers)
                            {
                                if (value.Key != SentValue.TalkingWith)
                                    OnlineUsers[value.Key].EnableChattingControl(OnlineUser.CButtonType.MIC, false);
                            }

                            StartTalking();
                        }
                        else
                        {
                            StopTalking();
                        }
                    }
                    else
                    {
                        OnlineUsers[VoiceTalkingWith].EnableChattingControl(OnlineUser.CButtonType.MIC, false);
                        StopTalking();
                    }
            }

            catch { }
        }

        private void DevicesSettings_BTN_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            CapturingDevice.Show();
        }

        #endregion VoiceClient

        #region DesktopClient

        void OnDesktopReceived(object sender, OnDesktopSendReceivedEventArgs e)
        {
            try
            {
                if (e.Error != null)
                {
                    OnlineUsers[PublicKey].TxtChatWindow.ShowErrorMessageBox(e.Error.Message);
                }
                else
                {
                    try
                    {
                        DesktopDecoderThread.RunWorkerAsync(e.BinaryPacket);
                        
                    }
                    catch { }
                }
            }
            catch { }
        }

        void DesktopDecoder(object sender, DoWorkEventArgs e)
        {
            try
            {
                WcsBinaryPacket RD = (WcsBinaryPacket)e.Argument;
                if (RD.DataBuffer != null)
                {
                    ReceivedStream rbm = new ReceivedStream();
                    rbm.DataStream = ImageEcoderDecoder.Decoder(RD.DataBuffer, RD.IsCompressed);
                    rbm.SentFrom = RD.UserName;
                    rbm.SentTo = RD.To;
                    Deployment.Current.Dispatcher.BeginInvoke(() =>
                    {
                        ViewReceivedDesktopImage(rbm);
                    });
                }
            }
            catch { }
        }

        private void ViewReceivedDesktopImage(ReceivedStream rds)
        {
            try
            {
                if (rds.DataStream != null)
                {
                    var bi = new BitmapImage();
                    bi.SetSource(rds.DataStream);

                    if (!DesktopViewerSessions.ContainsKey(rds.SentFrom))
                    {
                        DesktopViewerSessions.Add(rds.SentFrom, new DesktopViewer(rds.SentFrom));
                        DesktopViewerSessions[rds.SentFrom].Position = new Point(10, 300);
                        Dashboard.Add(DesktopViewerSessions[rds.SentFrom]);
                        DesktopViewerSessions[rds.SentFrom].Show();
                        DesktopViewerSessions[rds.SentFrom].ViewReceivedImage(bi);
                        
                    }
                    else
                    {
                        DesktopViewerSessions[rds.SentFrom].ViewReceivedImage(bi);
                    }
                }
            }
            catch { }
        }

        private void RunDesktopSharing_BTN_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (DSTool != null)
                DSTool.Show();
        }

        #endregion DesktopClient

        #region FileClient

        void OnSyncFilesListReceived(object sender, OnFileUploadedReceivedEventArgs e)
        {
            try
            {
                if (e.Error == null & e.FilesListSync != null)
                {
                    NumberOfFilesLB.Content = e.FilesListSync.Count;
                    SyncFilesList(e.FilesListSync);
                }
            }
            catch {};
        }

        public void SyncFilesList(System.Collections.ObjectModel.ObservableCollection<WcsFilePacket> FilesList)
        {
            try
            {
                FM.ClearFilesList();

                foreach (var file in FilesList)
                {
                    if (file.UploadedFileID != null)
                    {
                        UploadedFileItem fileItem = new UploadedFileItem(file, log.UserName);
                        fileItem.DownloadClicked += new EventHandler(FileDownloadClick);
                        fileItem.RemoveClicked += new EventHandler(FileRemoveClick);
                        FM.ReceivedFileslistBox.Items.Add(fileItem);
                    }
                }
            }
            catch { }
        }

        private void FileUploadClick(object sender, EventArgs ev)
        {
            try
            {
                if (sender != null)
                {
                    WcsFilePacket packet = (WcsFilePacket)sender;
                    WCSProxy.UploadFileAsync(packet);
                }
            }
            catch  { };
        }

        private void FileDownloadClick(object sender, EventArgs ev)
        {
            try
            {
                if (sender != null)
                {
                    FM.IsProgress(true, "Downloading ..");

                    WcsFilePacket packet = (WcsFilePacket)sender;
                    WCSProxy.DownloadFileAsync(packet);
                }
            }
            catch {  };
        }

        private void FileRemoveClick(object sender, EventArgs ev)
        {
            try
            {
                if (sender != null)
                {
                    FM.IsProgress(true, "Removing ..");

                    WcsFilePacket packet = (WcsFilePacket)sender;
                    WCSProxy.RemoveFileAsync(packet);
                }
            }
            catch { };
        }

        void GetMaxFileSizeCompleted(object sender, get_MaxFileSizeCompletedEventArgs e)
        {
            if (e.Error == null)
                FM.MaxFileBufferSize = e.Result;
            else FM.AllowUploadFile = false;
        }

        private void UploadFileCompleted(object sender, AsyncCompletedEventArgs e)
        {
            try
            {
                if (e.Error != null)
                    FM.FileUploadCompleted(e.Error.Message);
                else FM.FileUploadCompleted("Done");
            }
            catch (Exception ex) { FM.FileUploadCompleted(ex.Message); };
        }

        private void DownloadFileCompleted(object sender, DownloadFileCompletedEventArgs e)
        {
            try
            {
                if (e.Error != null)
                    FM.FileDownloadCompleted("Downloading File: " + e.Error.Message);
                else
                {
                    FM.FileDownloadCompleted("Done");
                    if (e.Result.DataBuffer != null)
                    {
                        DownSaveDialog download = new DownSaveDialog((e.Result));
                        download.Show();
                    }
                }
            }
            catch (Exception ex) { FM.FileDownloadCompleted(ex.Message); };
        }

        private void RemoveFileCompleted(object sender, AsyncCompletedEventArgs e)
        {
            try
            {
                if (e.Error != null)
                    FM.FileRemoveCompleted(e.Error.Message);
                else FM.FileUploadCompleted("Done");
            }
            catch (Exception ex) { FM.FileRemoveCompleted(ex.Message); };
        }

        private void Uploaded_Files_Counter(object sender, EventArgs e)
        {
            try
            {
                if (sender != null)
                {
                    NumberOfFilesLB.Content = sender.ToString();
                }
            }
            catch { };
        }
        private void PubFilesSharing_BTN_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (FM != null)
                FM.Show();
        }
        #endregion FileClient

    }
}
