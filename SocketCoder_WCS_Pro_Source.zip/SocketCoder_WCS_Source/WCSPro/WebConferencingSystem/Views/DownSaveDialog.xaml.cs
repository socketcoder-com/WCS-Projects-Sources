﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using WebConferencingSystem.WCS_Proxy;
using System.IO;
using ICSharpCode.SharpZipLib.Zip.Compression;

namespace WebConferencingSystem.Views
{
    public partial class DownSaveDialog : ChildWindow
    {
        public DownSaveDialog(WcsFilePacket FilePacket)
        {
            InitializeComponent();

            Packet = FilePacket;

            AreYouSureTxT.Text = "Do you want to save " + Packet.FileName + " File On your Computer?";
        }

        public WcsFilePacket Packet { get; set; }

        public byte[] Uncompress(byte[] input)
        {
            Inflater decompressor = new Inflater();
            decompressor.SetInput(input);

            // Create an expandable byte array to hold the decompressed data  
            MemoryStream bos = new MemoryStream(input.Length);

            // Decompress the data  
            byte[] buf = new byte[1024];
            while (!decompressor.IsFinished)
            {
                int count = decompressor.Inflate(buf);
                bos.Write(buf, 0, count);
            }

            // Get the decompressed data  
            return bos.ToArray();
        }

        private void OKButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = true;

            try
            {
                if (Packet.DataBuffer != null)

                    if (Packet.DataBuffer.Length > 0)
                    {
                        SaveFileDialog SaveDialog = new SaveFileDialog();
                        SaveDialog.DefaultExt = Packet.FileExtension;
                        SaveDialog.DefaultFileName = Packet.FileName.Replace(':', ' ');
                        SaveDialog.Filter = "Received File (*" + Packet.FileExtension + ")|*" + Packet.FileExtension;
                        if (SaveDialog.ShowDialog().Value)
                        {
                            try
                            {
                                byte[] UncompressBytes = Uncompress(Packet.DataBuffer);

                                using (Stream filestream = SaveDialog.OpenFile())
                                {
                                    filestream.Write(UncompressBytes, 0, UncompressBytes.Length);
                                    filestream.Close();
                                }
                            }
                            catch { }
                        }
                    }
            }
            catch { }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }
    }
}

