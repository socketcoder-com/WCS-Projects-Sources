﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Media.Imaging;
using System.IO;
using ImageTools;

namespace WebConferencingSystem.Views
{
    public partial class RemoteCam : SilverFlow.Controls.FloatingWindow
    {
        public bool FocusedView = false;

        public RemoteCam(string PublisherName)
        {
            InitializeComponent();

            this.Title = PublisherName;
        }

        public void SetTitle(string _Title)
        {
            this.Title = _Title;
        }

        public void ViewReceivedVideoFrame(BitmapImage RImag)
        {
              RemoteCamIMG.Source = RImag;
        }

        public void ClearCamImage()
        {
            RemoteCamIMG.Source = null;
        }

        private void RemoteCam_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ClickCount == 2)
            {
                try
                {
                    SaveFileDialog saveFileDlg = new SaveFileDialog();
                    ImageTools.IO.Jpeg.JpegEncoder EncodeJpeg = new ImageTools.IO.Jpeg.JpegEncoder();
                    EncodeJpeg.Quality = 100;
                    saveFileDlg.DefaultFileName = "Image " + DateTime.Now.ToFileTime().ToString();
                    saveFileDlg.Filter = "JPEG Files (*.jpg)|*.jpg";
                    saveFileDlg.DefaultExt = ".jpg";

                    if (saveFileDlg.ShowDialog().Value)
                    {
                        using (Stream dstStream = saveFileDlg.OpenFile())
                        {
                            WriteableBitmap bmp = new WriteableBitmap(RemoteCamIMG, null);
                            EncodeJpeg.Encode(bmp.ToImage(), dstStream);
                        }
                    }
                }
                catch { }
            }
        }

    }
}
