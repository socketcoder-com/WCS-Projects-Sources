﻿using SilverFlow.Controls;
using System.Windows.Media;

namespace WebConferencingSystem.Views
{
    public partial class LocalWebCam : FloatingWindow
    {
        public LocalWebCam()
        {
            InitializeComponent();
        }

    }
}
