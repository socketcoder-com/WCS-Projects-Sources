﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using SilverFlow.Controls;

namespace WebConferencingSystem.Views
{
    public partial class Collaborative : FloatingWindow
    {
        public void DrawingWith(string DrawingNow)
        {
            this.Title = "Public Collaborative Drawing - " + DrawingNow + " Now Drawing";
        }

        public Collaborative(bool IsPresenter)
        {
            try
            {
                InitializeComponent();
                page1.SetIsCollaborative(IsPresenter);
                page1.AllowUsingWB = IsPresenter;
            }
            catch { }
        }

        private void page1_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            DrawingWith("You");
        }
    }
}
