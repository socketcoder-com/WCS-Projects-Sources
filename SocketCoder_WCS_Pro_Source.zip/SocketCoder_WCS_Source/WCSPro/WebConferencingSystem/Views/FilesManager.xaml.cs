﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.IO;
using MediaStreaming;
using ICSharpCode.SharpZipLib.Zip.Compression;
using WebConferencingSystem.WCS_Proxy;

namespace WebConferencingSystem.Views
{
    public partial class FilesManager : ChildWindow
    {

        public int MaxFileBufferSize { get; set; }
        public bool AllowUploadFile  {get;set;}

        public FilesManager()
        {
            InitializeComponent();
        }

        // For File Transfer
        private string UserName {get;set;}
        private string RoomID { get; set; }
        public event EventHandler UploadClicked;
        private delegate void Enabledelegate(bool value);
        private WcsPacketizer Packetizer = new WcsPacketizer();

        public void Initiate(string User_ID, string Room_ID)
        {
            UserName = User_ID;
            RoomID = Room_ID;
        }

        public void FileUploadCompleted(string Result)
        {
            try
            {
                if (Result != "Done")
                {
                    ShowMessageBox("ERROR: " + Result);
                }

                IsProgress(false, "Uploading Completed");
            }
            catch {}
        }

        public void FileDownloadCompleted(string Result)
        {
            try
            {
                if (Result != "Done")
                {
                    ShowMessageBox("ERROR: " + Result);
                }

                IsProgress(false,"Downloading Completed");
                
            }
            catch { }
        }

        public void FileRemoveCompleted(string Result)
        {
            try
            {
                if (Result != "Done")
                {
                    ShowMessageBox("ERROR: " + Result);
                }

                IsProgress(false, "Removing Completed");

            }
            catch { }
        }

        public void IsProgress(bool value,string MSG)
        {
            EnableFileControl(!value);

            if (value)
            {
                UploadingLB.Content = MSG;
                UploadingLB.Visibility = System.Windows.Visibility.Visible;
            }
            else
            {
                UploadingLB.Visibility = System.Windows.Visibility.Collapsed;
            }
        }


        private void ShowMessageBox(string MSG)
        {
            MessageBox.Show(MSG, "SocketCoder.Com - Web Conference System", MessageBoxButton.OK);
        }

        public byte[] Compress_BEST_COMPRESSION(byte[] input)
        {
            // Create the compressor with highest level of compression  
            Deflater compressor = new Deflater();
            compressor.SetLevel(Deflater.BEST_COMPRESSION);

            // Give the compressor the data to compress  
            compressor.SetInput(input);
            compressor.Finish();

            /* 
             * Create an expandable byte array to hold the compressed data. 
             * You cannot use an array that's the same size as the orginal because 
             * there is no guarantee that the compressed data will be smaller than 
             * the uncompressed data. 
             */
            MemoryStream bos = new MemoryStream(input.Length);

            // Compress the data  
            byte[] buf = new byte[1024];
            while (!compressor.IsFinished)
            {
                int count = compressor.Deflate(buf);
                bos.Write(buf, 0, count);
            }

            // Get the compressed data  
            return bos.ToArray();
        }

        WcsFilePacket UploadFile()
        {
            try
            {
                OpenFileDialog FileDialog = new OpenFileDialog();
                FileDialog.Filter = "AnyFile (*.*)|*.*";

                if (FileDialog.ShowDialog().Value)
                {
                    Stream filestrm = FileDialog.File.OpenRead();
                    byte[] FileBuffer = new byte[filestrm.Length];
                    filestrm.Read(FileBuffer, 0, FileBuffer.Length);
                    filestrm.Close();

                    if (FileBuffer.Length <= MaxFileBufferSize)
                    {
                        string FileName = FileDialog.File.Name;
                        string FileExten = FileDialog.File.Extension;
                        byte[] CompressedBytes = Compress_BEST_COMPRESSION(FileBuffer);

                        return Packetizer.GetObject(UserName, RoomID, CompressedBytes, "", FileName, FileExten, FileBuffer.Length, BinaryPayloadType.File, true);

                    }
                    else
                        ShowMessageBox("You cannot Upload a file greater than " + (MaxFileBufferSize/1024/1024) + " MB, if you would like to increase it please call the system Administrator");
                }
            }
            catch { }
            return new WcsFilePacket();
        }

        public void ClearFilesList()
        {
            ReceivedFileslistBox.Items.Clear();
        }

        public void EnableFileControl(bool value)
        {
            AllowUploadFile = value;
            ReceivedFileslistBox.IsEnabled = value;
        }

        private void UploadFileBT_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            try
            {
                if (AllowUploadFile)
                {
                    WcsFilePacket packet = UploadFile();
                    if (packet.DataBuffer != null)
                    {
                        IsProgress(true, "Uploading ..");

                        UploadClicked(packet, null);
                    }
                }
            }
            catch (Exception ex) { ShowMessageBox(ex.Message); }
        }
    }
}

