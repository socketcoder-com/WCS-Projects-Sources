﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace SilverFlow.Controls
{
    /// <summary>
    /// Thumbnail of the minimized windows.
    /// </summary>
    [TemplatePart(Name = PART_Title, Type = typeof(TextBlock))]
    [TemplatePart(Name = PART_Thumbnail, Type = typeof(Image))]
    public class WindowIcon : Button
    {
        // Template parts
        private const string PART_Title = "Title";
        private const string PART_Thumbnail = "Thumbnail";

        // VSM states
        private const string VSMSTATE_StateNormal = "Normal";
        private const string VSMSTATE_StateMouseOver = "MouseOver";

        /// <summary>
        /// Gets or sets the window title that is displayed on the icon />.
        /// </summary>
        /// <value>The title displayed on the icon.</value>
        public string Title { get; set; }

        /// <summary>
        /// Gets or sets the thumbnail.
        /// </summary>
        /// <value>The thumbnail.</value>
        public ImageSource Thumbnail { get; set; }

        /// <summary>
        /// Gets or sets the FloatingWindow associated with the icon.
        /// </summary>
        /// <value>Floating window.</value>
        public FloatingWindow Window { get; set; }

        /// <summary>
        /// Window's title.
        /// </summary>
        private TextBlock title;

        /// <summary>
        /// Thumbnail icon of the window.
        /// </summary>
        private Image thumbnail;

        private bool selected;

        /// <summary>
        /// Gets or sets a value indicating whether this <see cref="WindowIcon"/> is selected.
        /// </summary>
        /// <value><c>true</c> if selected; otherwise, <c>false</c>.</value>
        public bool Selected
        {
            get
            {
                return selected;
            }

            set
            {
                selected = value;
                VisualStateManager.GoToState(
                    this,
                    value ? VSMSTATE_StateMouseOver : VSMSTATE_StateNormal, 
                    true);
            }
        }

        #region public double IconWidth

        /// <summary>
        /// Gets or sets the width of the window's icon.
        /// </summary>
        /// <value>The width of the window's icon.</value>
        public double IconWidth
        {
            get { return (double)GetValue(IconWidthProperty); }
            set { SetValue(IconWidthProperty, value); }
        }

        /// <summary>
        /// Identifies the <see cref="WindowIcon.IconWidth" /> dependency property.
        /// </summary>
        /// <value>
        /// The identifier for the <see cref="WindowIcon.IconWidth" /> dependency property.
        /// </value>
        public static readonly DependencyProperty IconWidthProperty =
            DependencyProperty.Register(
            "IconWidth",
            typeof(double),
            typeof(WindowIcon),
            null);

        #endregion

        #region public double IconHeight

        /// <summary>
        /// Gets or sets the height of the window's icon.
        /// </summary>
        /// <value>The height of the window's icon.</value>
        public double IconHeight
        {
            get { return (double)GetValue(IconHeightProperty); }
            set { SetValue(IconHeightProperty, value); }
        }

        /// <summary>
        /// Identifies the <see cref="WindowIcon.IconHeight" /> dependency property.
        /// </summary>
        /// <value>
        /// The identifier for the <see cref="WindowIcon.IconHeight" /> dependency property.
        /// </value>
        public static readonly DependencyProperty IconHeightProperty =
            DependencyProperty.Register(
            "IconHeight",
            typeof(double),
            typeof(WindowIcon),
            null);

        #endregion

        /// <summary>
        /// Builds the visual tree for the <see cref="WindowIcon" /> control 
        /// when a new template is applied.
        /// </summary>
        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();

            title = GetTemplateChild(PART_Title) as TextBlock;
            thumbnail = GetTemplateChild(PART_Thumbnail) as Image;

            if (title == null)
                throw new NotImplementedException("Template Part PART_Title is required to display WindowIcon.");

            if (thumbnail == null)
                throw new NotImplementedException("Template Part PART_Thumbnail is required to display WindowIcon.");

            title.Text = Title;
            title.FlowDirection = this.FlowDirection;
            thumbnail.Source = Thumbnail;
        }
    }
}
