﻿using System.Windows;
using System.Windows.Controls;

namespace SilverFlow.Controls
{
    /// <summary>
    /// Two-state button with up/down arrow.
    /// </summary>
    public class BootstrapButton : Button
    {
        // VSM states
        private const string VSMSTATE_StateOpen = "Open";
        private const string VSMSTATE_StateClose = "Close";

        #region public bool StateOpen

        /// <summary>
        /// Gets or sets a value indicating whether the bootstrap button is in state "Open".
        /// </summary>
        /// <value><c>true</c> if the bootstrap button is in state "Open"; otherwise, <c>false</c>.</value>
        public bool StateOpen
        {
            get { return (bool)GetValue(StateOpenProperty); }
            set { SetValue(StateOpenProperty, value); }
        }

        /// <summary>
        /// Identifies the <see cref="BootstrapButton.StateOpen" /> dependency property.
        /// </summary>
        /// <value>
        /// The identifier for the <see cref="BootstrapButton.StateOpen" /> dependency property.
        /// </value>
        public static readonly DependencyProperty StateOpenProperty =
            DependencyProperty.Register(
            "StateOpen",
            typeof(bool),
            typeof(BootstrapButton),
            new PropertyMetadata(true, StateOpenPropertyChanged));

        /// <summary>
        /// StateOpenProperty PropertyChangedCallback call back static function.
        /// </summary>
        /// <param name="d">BootstrapButton object whose StateOpenProperty property is changed.</param>
        /// <param name="e">DependencyPropertyChangedEventArgs which contains the old and new values.</param>
        private static void StateOpenPropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            BootstrapButton button = (BootstrapButton)d;

            VisualStateManager.GoToState(
                button,
                (bool)e.NewValue ? VSMSTATE_StateOpen : VSMSTATE_StateClose, 
                true);

            ToolTipService.SetToolTip(
                button,
                (bool)e.NewValue ? "Open Iconbar" : "Close Iconbar");
        }

        #endregion

        /// <summary>
        /// Raises the <see cref="E:System.Windows.Controls.Primitives.ButtonBase.Click"/> event.
        /// </summary>
        protected override void OnClick()
        {
            base.OnClick();

            // Toggle open/closed state
            StateOpen = !StateOpen;
        }
    }
}
