﻿using System;
using System.Windows;
using System.Windows.Media.Animation;

namespace SilverFlow.Controls
{
    /// <summary>
    /// Useful Silverlight animation extensions
    /// </summary>
    public static class AnimationExtensions
    {
        /// <summary>
        /// Animates specified property of the object.
        /// </summary>
        /// <param name="target">The target object to animate.</param>
        /// <param name="propertyPath">Property path, e.g. Canvas.Top.</param>
        /// <param name="from">Animation's starting value.</param>
        /// <param name="to">Animation's ending value.</param>
        /// <param name="milliseconds">Duration of the animation in milliseconds.</param>
        /// <param name="easingFunction">Easing function applied to the animation.</param>
        /// <param name="completed">Event handler called when animation completed.</param>
        /// <returns>Returns started storyboard.</returns>
        public static Storyboard AnimateDoubleProperty(this DependencyObject target, string propertyPath, double? from, double? to, double milliseconds,
            IEasingFunction easingFunction = null, EventHandler completed = null)
        {
            Duration duration = new Duration(TimeSpan.FromMilliseconds(milliseconds));
            DoubleAnimation doubleAnimation = new DoubleAnimation()
            {
                From = from,
                To = to,
                Duration = duration,
                EasingFunction = easingFunction
            };

            Storyboard storyboard = new Storyboard();
            storyboard.Duration = duration;
            storyboard.Children.Add(doubleAnimation);

            Storyboard.SetTarget(doubleAnimation, target);
            Storyboard.SetTargetProperty(doubleAnimation, new PropertyPath(propertyPath));

            if (completed != null)
                storyboard.Completed += completed;

            storyboard.Begin();

            return storyboard;
        }

        /// <summary>
        /// Fade in the specified object.
        /// </summary>
        /// <param name="target">The target object.</param>
        /// <param name="milliseconds">Duration of the animation in milliseconds.</param>
        /// <param name="completed">Event handler called when animation completed.</param>
        /// <returns>Returns started storyboard.</returns>
        public static Storyboard FadeIn(this DependencyObject target, double milliseconds, EventHandler completed = null)
        {
            return AnimateDoubleProperty(target, "Opacity", 0, 1, milliseconds, null, completed);
        }

        /// <summary>
        /// Fade out the specified object.
        /// </summary>
        /// <param name="target">The target object.</param>
        /// <param name="milliseconds">Duration of the animation in milliseconds.</param>
        /// <param name="completed">Event handler called when animation completed.</param>
        /// <returns>Returns started storyboard.</returns>
        public static Storyboard FadeOut(this DependencyObject target, double milliseconds, EventHandler completed = null)
        {
            return AnimateDoubleProperty(target, "Opacity", 1, 0, milliseconds, null, completed);
        }

        /// <summary>
        /// Moves and resizes the object.
        /// </summary>
        /// <param name="target">The target object.</param>
        /// <param name="position">Ending position.</param>
        /// <param name="width">New width.</param>
        /// <param name="height">New height.</param>
        /// <param name="milliseconds">Duration of the animation in milliseconds.</param>
        /// <param name="completed">Event handler called when animation completed.</param>
        public static void MoveAndResize(this DependencyObject target, Point position, double width, double height,
            double milliseconds, EventHandler completed = null)
        {
            Duration duration = new Duration(TimeSpan.FromMilliseconds(milliseconds));
            DoubleAnimation doubleAnimation1 = new DoubleAnimation();
            DoubleAnimation doubleAnimation2 = new DoubleAnimation();
            PointAnimation pointAnimation = new PointAnimation();

            doubleAnimation1.Duration = duration;
            doubleAnimation2.Duration = duration;
            pointAnimation.Duration = duration;

            Storyboard storyboard = new Storyboard();
            storyboard.Duration = duration;

            storyboard.Children.Add(doubleAnimation1);
            storyboard.Children.Add(doubleAnimation2);
            storyboard.Children.Add(pointAnimation);

            Storyboard.SetTarget(doubleAnimation1, target);
            Storyboard.SetTarget(doubleAnimation2, target);
            Storyboard.SetTarget(pointAnimation, target);

            Storyboard.SetTargetProperty(doubleAnimation1, new PropertyPath("(Width)"));
            Storyboard.SetTargetProperty(doubleAnimation2, new PropertyPath("(Height)"));
            Storyboard.SetTargetProperty(pointAnimation, new PropertyPath("(Position)"));

            doubleAnimation1.To = width;
            if (!height.IsNotSet())
                doubleAnimation2.To = height;

            pointAnimation.To = position;

            if (completed != null)
                storyboard.Completed += completed;

            storyboard.Begin();
        }
    }
}
