﻿// (C) SocketCoder.Com 
// WCS Packet
// Last Modify:  5/July/2014
namespace MediaStreaming
{
    using System;
    using System.Net;
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Documents;
    using System.Windows.Ink;
    using System.Windows.Input;
    using System.Windows.Media;
    using System.Windows.Media.Animation;
    using System.Windows.Shapes;
    using NSpeex;

    public class SpeexEncoderDecoder
    {
        SpeexEncoder CodecSpeexEncoder = new SpeexEncoder(BandMode.Wide);
        SpeexDecoder CodecSpeexDecoder = new SpeexDecoder(BandMode.Wide);


        private int _VoiceQuality = 5;

        public int VoiceQuality
        {
            set
            {
                _VoiceQuality = this.CodecSpeexEncoder.Quality = value;
            }
            get
            {
                return _VoiceQuality;
            }
        }

        public SpeexEncoderDecoder()
        {
            this.CodecSpeexEncoder.Quality = _VoiceQuality;
        }

        public byte[] Decode(byte[] encodedData, int SamplesPerSecond, int Channels)
        {
            try
            {
                short[] decodedFrame = new short[SamplesPerSecond * Channels];
                int decodedBytes = CodecSpeexDecoder.Decode(encodedData, 0, encodedData.Length, decodedFrame, 0, false);

                byte[] decodedAudioData = null;

                decodedAudioData = new byte[decodedBytes * 2];

                try
                {
                    for (int shortIndex = 0, byteIndex = 0; shortIndex < decodedBytes; shortIndex++, byteIndex += 2)
                    {
                        byte[] temp = BitConverter.GetBytes(decodedFrame[shortIndex]);
                        decodedAudioData[byteIndex] = temp[0];
                        decodedAudioData[byteIndex + 1] = temp[1];
                    }
                }
                catch
                {
                    return decodedAudioData;
                }
                return decodedAudioData;
            }
            catch
            {
                return new byte[0];
            }
        }

        public byte[] Encode(byte[] rawData)
        {
            try
            {
                var inDataSize = rawData.Length / 2;

                var inData = new short[inDataSize];

                for (int index = 0; index < rawData.Length; index += 2)
                {
                    inData[index / 2] = BitConverter.ToInt16(rawData, index);
                }
                inDataSize = inDataSize - inDataSize % CodecSpeexEncoder.FrameSize;
                var encodedData = new byte[rawData.Length];
                var encodedBytes = CodecSpeexEncoder.Encode(inData, 0, inDataSize, encodedData, 0, encodedData.Length);
                byte[] encodedAudioData = null;
                if (encodedBytes != 0)
                {
                    encodedAudioData = new byte[encodedBytes];
                    Array.Copy(encodedData, 0, encodedAudioData, 0, encodedBytes);
                }

                return encodedAudioData;
            }
            catch { return new byte[0]; }
        }

    }
    internal static class Converters
    {
        public static byte[] ToByteArray(this short[] array)
        {
            byte[] dst = new byte[array.Length * 2];
            Buffer.BlockCopy(array, 0, dst, 0, dst.Length);
            return dst;
        }

        public static short[] ToShortArray(this byte[] array)
        {
            short[] dst = new short[array.Length / 2];
            Buffer.BlockCopy(array, 0, dst, 0, array.Length);
            return dst;
        }
    }

}