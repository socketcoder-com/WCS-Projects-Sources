﻿// (C) SocketCoder.Com 
// WCS Packet
// Last Modify:  1/Aug/2014
namespace MediaStreaming
{
    using System;
    using System.Net;
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Documents;
    using System.Windows.Ink;
    using System.Windows.Input;
    using System.Windows.Media;
    using System.Windows.Media.Animation;
    using System.Windows.Shapes;
    using System.Windows.Media.Imaging;
    using System.IO;
    using ImageTools;
    using System.Windows.Media.Effects;

    internal class ImageEcoderDecoder
    {
        private static ImageTools.IO.Jpeg.JpegDecoder Jdecoder = new ImageTools.IO.Jpeg.JpegDecoder();
        private static ImageTools.IO.Jpeg.JpegEncoder Jpgencod = new ImageTools.IO.Jpeg.JpegEncoder();
        private static ImageTools.IO.Png.PngEncoder pngEncoder = new ImageTools.IO.Png.PngEncoder();

        internal static byte[] JpegEncode(ExtendedImage bitmap, int ImageQuality, bool WithCompression)
        {
            try
            {
                MemoryStream stream = new MemoryStream();
                Jpgencod.Quality = ImageQuality;
                Jpgencod.Encode(bitmap, stream);

                if (WithCompression)
                    return QuickLZSharp.QuickLZ.compress(stream.GetBuffer());
                else
                    return stream.GetBuffer();
            }
            catch { return new byte[0]; }
        }

        internal static byte[] PngEncoder(ExtendedImage bitmap, bool WithCompression)
        {
            try
            {
                MemoryStream stream = new MemoryStream();
                pngEncoder.Encode(bitmap, stream);

                if (WithCompression)
                    return QuickLZSharp.QuickLZ.compress(stream.GetBuffer());
                else
                    return stream.GetBuffer();
            }
            catch { return new byte[0]; }
        }

        internal static Stream Decoder(byte[] buffer, bool IsCompressed)
        {
            try
            {
                if (IsCompressed)
                    return new MemoryStream(QuickLZSharp.QuickLZ.decompress(buffer));
                else return new MemoryStream(buffer);
            }
            catch { return new MemoryStream(); }
        }

        public static ExtendedImage Resize(ExtendedImage bmp, int ImgWidth, int ImgHeight)
        {
            try
            {
                return ExtendedImage.Resize(bmp, ImgWidth, ImgHeight, new ImageTools.Filtering.NearestNeighborResizer());
            }
            catch { return null; }
        }
    }
}