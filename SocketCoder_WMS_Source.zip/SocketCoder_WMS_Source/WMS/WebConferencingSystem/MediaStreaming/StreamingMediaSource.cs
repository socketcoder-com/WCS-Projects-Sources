﻿// (C) SocketCoder.Com 
// WCS Packet
// Last Modify:  5/July/2014
namespace MediaStreaming
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Runtime.CompilerServices;
    using System.Text;
    using System.Threading;
    using System.Windows.Media;

    public class StreamingMediaSource : MediaStreamSource
    {

        private Stream stream;

        private object locker = new object();

        private SpeexEncoderDecoder decoder = new SpeexEncoderDecoder();


        private int BitPerSample;
        private int SamplePeerSecond;
        private int Channels;

        private Queue<byte[]> BufferQueue = new Queue<byte[]>();

        private MediaStreamDescription audioDesc;
        private string HexWaveHeader;

        public StreamingMediaSource(int _BitPerSample, int _SamplePeerSecond, int _Channels)
        {
            InitiateVoiceFormat( _BitPerSample,  _SamplePeerSecond,  _Channels);
        }

        private void InitiateVoiceFormat(int _BitPerSample, int _SamplePeerSecond, int _Channels)
        {
            try
            {
                BitPerSample = _BitPerSample;
                SamplePeerSecond = _SamplePeerSecond;
                Channels = _Channels;

                HexWaveHeader = WaveHeaderToHexString(BitPerSample, SamplePeerSecond, Channels);
            }
            catch { }
        }
        public void UpdateVoiceFormat(int _BitPerSample, int _SamplePeerSecond, int _Channels)
        {
            try
            {
                if (_BitPerSample != BitPerSample || _SamplePeerSecond != SamplePeerSecond || _Channels != Channels)
                {
                    InitiateVoiceFormat(_BitPerSample, _SamplePeerSecond, _Channels);
                }
            }
            catch { }
        }
        protected override void OpenMediaAsync()
        {
            try
            {
                // Init
                Dictionary<MediaStreamAttributeKeys, string> streamAttributes = new Dictionary<MediaStreamAttributeKeys, string>();
                Dictionary<MediaSourceAttributesKeys, string> sourceAttributes = new Dictionary<MediaSourceAttributesKeys, string>();
                List<MediaStreamDescription> availableStreams = new List<MediaStreamDescription>();

                // Stream Description
                streamAttributes[MediaStreamAttributeKeys.CodecPrivateData] = HexWaveHeader;
                this.audioDesc = new MediaStreamDescription(MediaStreamType.Audio, streamAttributes);
                availableStreams.Add(this.audioDesc);
                sourceAttributes[MediaSourceAttributesKeys.Duration] = "0";
                ReportOpenMediaCompleted(sourceAttributes, availableStreams);
            }
            catch (Exception) { }
        }

        protected override void GetSampleAsync(MediaStreamType mediaStreamType)
        {
            try
            {
                stream = PullBufferQueue();
                MediaStreamSample sample = new MediaStreamSample(this.audioDesc, stream, 0, stream.Length, 0, 10, new Dictionary<MediaSampleAttributeKeys, string>());
                base.ReportGetSampleCompleted(sample);
            }
            catch { }
        }

        protected override void SeekAsync(long seekToTime)
        {
            try
            {
                ReportSeekCompleted(seekToTime);
            }
            catch { }
        }

        public MemoryStream PullBufferQueue()
        {
            try
            {
                lock (this.locker)
                {
                    byte[] DecodedBuffer = decoder.Decode(this.BufferQueue.Dequeue(), SamplePeerSecond, Channels);

                    return new MemoryStream(DecodedBuffer);
                }
            }
            catch { return new MemoryStream(); }
        }

        public void PushBufferToQueue(byte[] data)
        {
            try
            {
                lock (this.locker)
                {
                    while (this.BufferQueue.Count > 40)
                    {
                        this.BufferQueue.Dequeue();
                    }
                    this.BufferQueue.Enqueue(data);
                }
            }
            catch { }
        }

        // Define The Wave Header
        public string WaveHeaderToHexString(int BitPerSample, int SamplePeerSecond, int Channels)
        {
            try
            {
                string WaveHeader = string.Empty;
                WaveHeader += ToLittleEndianString(string.Format("{0:X4}", 1));
                WaveHeader += ToLittleEndianString(string.Format("{0:X4}", Channels));
                WaveHeader += ToLittleEndianString(string.Format("{0:X8}", SamplePeerSecond));
                WaveHeader += ToLittleEndianString(string.Format("{0:X8}", (BitPerSample * SamplePeerSecond * Channels / 8)));
                WaveHeader += ToLittleEndianString(string.Format("{0:X4}", (ushort)(BitPerSample * Channels / 8)));
                WaveHeader += ToLittleEndianString(string.Format("{0:X4}", BitPerSample));
                WaveHeader += ToLittleEndianString(string.Format("{0:X4}", 0));
                return WaveHeader;
            }
            catch { return ""; }
        }

        public static string ToLittleEndianString(string bigEndianString)
        {
            try
            {
                if (bigEndianString == null)
                {
                    return string.Empty;
                }

                char[] bigEndianChars = bigEndianString.ToCharArray();

                // Guard
                if (bigEndianChars.Length % 2 != 0)
                {
                    return string.Empty;
                }

                int i, ai, bi, ci, di;
                char a, b, c, d;
                for (i = 0; i < bigEndianChars.Length / 2; i += 2)
                {
                    // front byte
                    ai = i;
                    bi = i + 1;

                    // back byte
                    ci = bigEndianChars.Length - 2 - i;
                    di = bigEndianChars.Length - 1 - i;

                    a = bigEndianChars[ai];
                    b = bigEndianChars[bi];
                    c = bigEndianChars[ci];
                    d = bigEndianChars[di];

                    bigEndianChars[ci] = a;
                    bigEndianChars[di] = b;
                    bigEndianChars[ai] = c;
                    bigEndianChars[bi] = d;
                }
                return new string(bigEndianChars);
            }
            catch { return ""; }
        }

        protected override void CloseMedia() { }
        protected override void GetDiagnosticAsync(MediaStreamSourceDiagnosticKind diagnosticKind) { }
        protected override void SwitchMediaStreamAsync(MediaStreamDescription mediaStreamDescription) { }
    }
}
