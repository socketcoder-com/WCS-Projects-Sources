﻿ //(C) SocketCoder.Com 
 //Last Modify: 1/Aug/2014

using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Navigation;
using System.IO;
using System.Net.Sockets;
using System.Windows.Media.Imaging;
using System.Text;
using System.Threading;
using System.ComponentModel;
using System.Windows.Threading;
using WebConferencingSystem.Views.Login;
using WebConferencingSystem.WCS_Proxy;
using MediaStreaming;
using ImageTools;
using System.Diagnostics;
using ICSharpCode.SharpZipLib.Zip.Compression;

namespace WebConferencingSystem.Views
{
    public partial class Home
    {

        #region Global Declarations

        private string WCSServiceName = "WCS Service";
        private string version = "4.0.0.0";
        private string PublicKey = "*All Users*";

        private VideoConferenceServiceClient WCSProxy;
        private WcsPacketizer Packetizer = new WcsPacketizer();
        private LocalWebCam localcam = new LocalWebCam();

        private Login.Login log = new Login.Login();
        private Login.ConnectionLost ConnLost = new Login.ConnectionLost();
        private FocusedView LargeWebCamWindow = new FocusedView();
        private CaptureDevicesSettings CapturingDevice = new CaptureDevicesSettings();
        private NewCall PickCall_Window;

        private Dictionary<string, OnlineUser> OnlineUsers = new Dictionary<string, OnlineUser>();

        private DispatcherTimer KeepAliveTimer = new DispatcherTimer();
        private enum CButtonType { TXT, MIC, VIDEO, CallStarted, SPEAKERS };
        private TextBlock MyName = new TextBlock();
        private bool Joined = false;

        private Microsoft.Xna.Framework.Audio.SoundEffectInstance Ringinginstance;

        private bool CallIsEstablished = false;
        private bool IsLargeView = false;
        public bool TryingToCall = false;
        public bool VideoShared = false;
        public bool VoiceShared = false;
        private bool IsConLost = false;
        private bool IsRinging = false;
        private string SelectedUserName;

        private struct ReceivedStream
        {
            public Stream DataStream;
            public string SentFrom;
            public string SentTo;
        }

     // Encoder/Decoder Threads
        private BackgroundWorker VideoEncoderThread = new BackgroundWorker();
        private BackgroundWorker VideoDecoderThread = new BackgroundWorker();

      //For Video Client
        private VideoBrush videoBrush = new VideoBrush();
        private DispatcherTimer VideoSendingTimer = new DispatcherTimer();
       

        #endregion Global Declarations

        #region Constructor
        public Home()
        {
            InitializeComponent();

            DateNow.Content = DateTime.Now.ToShortDateString();
            ConnLost.TryAgainClicked += new EventHandler(ConnTryAgain);
            
            CapturingDevice.AllowUsingClicked += new EventHandler(WebCamStart);
            CapturingDevice.DontAllowClicked += new EventHandler(WebCamStop);

            // Voice/Video Capturing/Encoding Async
            CapturingDevice.audiSink.OnBufferFulfill += new EventHandler(SendVoiceBuffer);
            VideoSendingTimer.Interval = new TimeSpan(0, 0, 0, 0, CapturingDevice.FPMS);
            VideoSendingTimer.Tick += new EventHandler(Video_Each_Tick);
            CapturingDevice.Capture_Source.CaptureImageCompleted += new EventHandler<CaptureImageCompletedEventArgs>(VideoFrameEncoding);

            // Keep Alive Timer
            KeepAliveTimer.Interval = new TimeSpan(0, 1, 0);
            KeepAliveTimer.Tick += new EventHandler(KeepAlive_Timer_Tick);


            // Other Services Encoder/Decoder Async
            SelectedUserPanel.Visibility = System.Windows.Visibility.Collapsed;

            log.Show();
            log.Closed += (s, args) =>
            {
               JoinBTN_Click(null, null);
            };

        }

        #endregion Constructor

        #region Connection Methods

        void Initiate_Proxy()
        {
            try
            {
                if (WCSProxy != null)
                {
                    WCSProxy.Abort();
                }

                WCSProxy = new VideoConferenceServiceClient();
                WCSProxy.SubscribeCompleted += new EventHandler<SubscribeCompletedEventArgs>(OnSubscribed);
                WCSProxy.UnSubscribeCompleted += new EventHandler<AsyncCompletedEventArgs>(UnSubscribeCompleted);
                WCSProxy.OpenCompleted += new EventHandler<AsyncCompletedEventArgs>(OnOpened);
                WCSProxy.CloseCompleted += new EventHandler<AsyncCompletedEventArgs>(OnClosed);
                WCSProxy.OnSyncUsersListReceived += new EventHandler<OnSyncUsersListReceivedEventArgs>(OnSynchronizeUsersList);
                WCSProxy.OnTextSendReceived += new EventHandler<OnTextSendReceivedEventArgs>(OnTextReceived);
                WCSProxy.OnVideoSendReceived += new EventHandler<OnVideoSendReceivedEventArgs>(OnVideoReceived);
                WCSProxy.OnVoiceSendReceived += new EventHandler<OnVoiceSendReceivedEventArgs>(OnVoiceReceived);
                WCSProxy.OnDrawingSendReceived += new EventHandler<OnDrawingSendReceivedEventArgs>(OnDrawingReceived);
                WCSProxy.OpenAsync();
            }
            catch { }
        }

        private void JoinBTN_Click(object sender, MouseButtonEventArgs e)
        {
            try
            {
                if (log.Isvalid())
                {
                    if (!Joined)
                    {
                        ConnectingWaitLB.Visibility = System.Windows.Visibility.Visible;

                        Initiate_Proxy();
                    }
                    else
                    {
                        DisConnect();
                        log.Show();
                    }
                }
                else
                {
                    DisConnect();
                    log.Show();
                }
            }
            catch { }
        }

        void DisConnect()
        {
            try
            {
                if (WCSProxy != null)
                     WCSProxy.Abort();

                IsConLost = false;

                WebCamStop(null, null);

                if ( CapturingDevice.audiSink != null)
                 CapturingDevice.audiSink.IsVoiceSendingStarted = false;

                    Joined = false;
                    log.NickNameTextBox.Text = "";
                    StopTalking();
                    StopSendingWebCam();
                    EnableUsing(false);

                ChattersListbox.Items.Clear();
                RoomTitle.Content = UserNameLB.Content = "";
                KeepAliveTimer.Stop();
                OnlineUsers.Clear();
                Dashboard.CloseAllWindows();

                SelectedUserPanel.Visibility = System.Windows.Visibility.Collapsed;
            }
            catch { }
        }

        void InnerChannel_Faulted(object sender, EventArgs e)
        {
            try
            {
                Deployment.Current.Dispatcher.BeginInvoke(() =>
                {
                    AutoTryToCon(true);
                });
            }
            catch { }
        }

        private void KeepAlive_Timer_Tick(object sender, EventArgs e)
        {
            try
            {
                if (WCSProxy.State == System.ServiceModel.CommunicationState.Opened)
                {
                    DateNow.Content = DateTime.Now.ToShortDateString() + " " + DateTime.Now.ToShortTimeString();
                    WCSProxy.SendCMDAsync(Packetizer.GetObject(WCSServiceName, log.UserName, log.RoomID, "Sync", TXTPayloadType.Sync, false));
                }
            }
            catch { }
        }

        private void ConnTryAgain(object sender, EventArgs e)
        {
            if (ConnLost.DialogResult == true)
                try
                {
                    Initiate_Proxy();
                }
                catch { }
            else AutoTryToCon(false);
        }

        void OnOpened(object sender, AsyncCompletedEventArgs e)
        {
            try
            {
                if (e.Error != null)
                {
                    Deployment.Current.Dispatcher.BeginInvoke(() =>
                    {
                        if (Joined)
                            AutoTryToCon(true);

                        else
                        {
                            DisConnect();
                            log.ErrorMSG.Content = "Cannot Connect With The WCS Service!";
                            log.Show();
                        }

                    });
                }
                else
                {

                    WCSProxy.InnerChannel.Faulted += new EventHandler(InnerChannel_Faulted);

                    if (IsConLost)
                        WCSProxy.UnSubscribeAsync(Packetizer.GetObject(WCSServiceName, log.UserName, log.RoomID, "UnSubscribe", TXTPayloadType.UnSubscribe, false));
                        
                    else
                        WCSProxy.SubscribeAsync(Packetizer.GetObject(log.RoomID, log.UserName, "00000", UserInRole.Participant, UserType.Guest, version), Packetizer.GetObject(log.RoomID, 500));

                    if (Joined)
                    {
                        Deployment.Current.Dispatcher.BeginInvoke(() =>
                        {
                            AutoTryToCon(false);
                        });
                    }
                    else if (!Joined & WCSProxy.State == System.ServiceModel.CommunicationState.Opened)
                    {
                        Deployment.Current.Dispatcher.BeginInvoke(() =>
                        {
                            RoomTitle.Content = log.RoomID;

                            OnlineUsers.Add(PublicKey, new OnlineUser(PublicKey, true, "Public Chat", "AllUsers"));
                            OnlineUsers[PublicKey].TxtChatWindow = new ChatArea(log.RoomID, log.UserName, log.RoomID, WCSServiceName, true);
                            OnlineUsers[PublicKey].TxtChatWindow.SendDrawingClicked += new EventHandler(SendDrawingBTN_Click);
                            OnlineUsers[PublicKey].TxtChatWindow.SendTextClicked += new EventHandler(SendRichBTN_Click);
                            OnlineUsers[PublicKey].Foreground = new SolidColorBrush(Colors.Red);
                            Dashboard.Add(OnlineUsers[PublicKey].TxtChatWindow);
                            OnlineUsers[PublicKey].TxtChatWindow.Show();
                            OnlineUsers[PublicKey].TxtChatWindow.RestoreSizeAndPosition();
                            OnlineUsers[PublicKey].TxtChatWindow.RestoreWindow();
                            ChattersListbox.Items.Clear();
                            ChattersListbox.Items.Add(OnlineUsers[PublicKey]);

                            Joined = true;
                        });
                    }
                }
            }
            catch { }
            finally {try{ConnectingWaitLB.Visibility = System.Windows.Visibility.Collapsed;}catch { }}
        }

        void UnSubscribeCompleted(object sender, AsyncCompletedEventArgs e)
        {
            if (IsConLost)
                WCSProxy.SubscribeAsync(Packetizer.GetObject(log.RoomID, log.UserName, "00000", UserInRole.Participant, UserType.Guest, version), Packetizer.GetObject(log.RoomID, 500));

            IsConLost = false;
        }

        void OnClosed(object sender, AsyncCompletedEventArgs e)
        {
            try
            {
                if (e.Error != null)
                {
                    OnlineUsers[PublicKey].TxtChatWindow.ShowErrorMessageBox(e.Error.Message);
                }
            }
            catch { }
        }

        void OnSubscribed(object sender, SubscribeCompletedEventArgs e)
        {
            try
            {
                if (e.Error != null)
                {
                    Deployment.Current.Dispatcher.BeginInvoke(() =>
                    {
                        OnlineUsers[PublicKey].TxtChatWindow.ShowErrorMessageBox(e.Error.Message);
                        EnableUsing(false);
                    });
                }
                else if (e.Result == IssueStatus.Done)
                    Deployment.Current.Dispatcher.BeginInvoke(() =>
                    {
                        EnableUsing(true);
                    });
                else if (e.Result == IssueStatus.BlockedUser)
                {
                    Deployment.Current.Dispatcher.BeginInvoke(() =>
                    {
                        OnlineUsers[PublicKey].TxtChatWindow.ShowErrorMessageBox("Sorry your User Name has been blocked by the system admin!");
                        EnableUsing(false);
                    });

                }
                else if (e.Result == IssueStatus.MaxUsersExceeded)
                {
                    Deployment.Current.Dispatcher.BeginInvoke(() =>
                    {
                        OnlineUsers[PublicKey].TxtChatWindow.ShowErrorMessageBox("Maximum Users Exceeded! Please try to join to another room or try again later");
                        EnableUsing(false);
                    });

                }
                else if (e.Result == IssueStatus.NotValid)
                {
                    Deployment.Current.Dispatcher.BeginInvoke(() =>
                    {
                        OnlineUsers[PublicKey].TxtChatWindow.ShowErrorMessageBox("Sorry You are not valid to join to this room!");
                        EnableUsing(false);
                    });

                }
                else if (e.Result == IssueStatus.UserIDAlreadyInUse)
                {
                    Deployment.Current.Dispatcher.BeginInvoke(() =>
                    {
                        OnlineUsers[PublicKey].TxtChatWindow.ShowErrorMessageBox("The Username is already being used, please leave the room and join again using different username");
                        EnableUsing(false);
                    });

                }
                else if (e.Result == IssueStatus.OldVersion)
                {
                    Deployment.Current.Dispatcher.BeginInvoke(() =>
                    {
                        OnlineUsers[PublicKey].TxtChatWindow.ShowErrorMessageBox("You are using an older version of WMS, please remove this version and install it again from the website!");
                        EnableUsing(false);
                    });

                }
            }
            catch { }
            finally { }
        }

        private void EnableUsing(bool value)
        {
            try
            {
                if (value)
                {

                    if (!CapturingDevice.AllowUsing)
                    {
                        CapturingDevice.Show();
                    }


                    // Get The new uploaded files if any
                    if (WCSProxy.State == System.ServiceModel.CommunicationState.Opened)
                    {
                        WCSProxy.get_MaxFileSizeAsync();
                        WCSProxy.SynchronizeFilesListAsync(Packetizer.GetObject(log.UserName, log.RoomID, new byte[0], "", "", "", 0, BinaryPayloadType.File, true));
                    }

                    if (ChattersListbox.Items.Contains(OnlineUsers[PublicKey]))
                        ChattersListbox.SelectedItem = OnlineUsers[PublicKey];

                    DateNow.Content = DateTime.Now.ToShortDateString() + " " + DateTime.Now.ToShortTimeString();
                    KeepAliveTimer.Start();
                }

                ChattersListbox.IsEnabled = value;

                foreach (var userKey in OnlineUsers)
                {
                    OnlineUsers[userKey.Key].TxtChatWindow.EnableControl(value);
                }

            }
            catch { }
        }

        private void Page_Unloaded(object sender, RoutedEventArgs e)
        {
            DisConnect();
        }

        void AutoTryToCon(bool value)
        {
            if (Joined & value)
            {
                IsConLost = true;
                ConnLost.Show();
                ConnLost.StartTimer();

                if (CallIsEstablished)
                {
                    CallEnded();
                    SelectUser(OnlineUsers[PublicKey]);
                }
            }
            else if (Joined & !value)
            {
                ConnLost.DialogResult = false;
                ConnLost.StopTimer();

                if (WCSProxy.State != System.ServiceModel.CommunicationState.Opened)
                {
                    OnlineUsers[PublicKey].TxtChatWindow.ShowErrorMessageBox("You have canceled the auto connect mode and you still offline! to use the system you must be connected, to try to connect again now, you have to leave and join the room again");
                    
                    EnableUsing(false);
                }

            }
        }

        private void EnableChattingControl(CButtonType BType, bool Enable)
        {
            try
            {
                if (BType == CButtonType.MIC)
                {
                    BitmapImage Mic_En = new BitmapImage(new Uri("/WebConferencingSystem;component/Views/Images/VoiceChat_EN.png", UriKind.Relative));
                    BitmapImage Mic_Dis = new BitmapImage(new Uri("/WebConferencingSystem;component/Views/Images/VoiceChat_DIS.png", UriKind.Relative));

                    if (Enable)
                    {
                        Voice_Chat_BTN.Source = Mic_En;
                    }
                    else
                    {
                        Voice_Chat_BTN.Source = Mic_Dis;
                    }


                }
                else if (BType == CButtonType.VIDEO)
                {
                    BitmapImage Vid_En = new BitmapImage(new Uri("/WebConferencingSystem;component/Views/Images/video_chat.png", UriKind.Relative));
                    BitmapImage Vid_Dis = new BitmapImage(new Uri("/WebConferencingSystem;component/Views/Images/video_chat-d.png", UriKind.Relative));

                    if (Enable)
                    {
                        Video_Chat_BTN.Source = Vid_En;
                    }
                    else
                    {
                        Video_Chat_BTN.Source = Vid_Dis;
                    }
                }
                else if (BType == CButtonType.TXT)
                {
                    BitmapImage Txt_En = new BitmapImage(new Uri("/WebConferencingSystem;component/Views/Images/text_chat.png", UriKind.Relative));
                    BitmapImage Txt_Dis = new BitmapImage(new Uri("/WebConferencingSystem;component/Views/Images/text_chat-d.png", UriKind.Relative));

                    if (Enable)
                    {
                        Text_Chat_BTN.Source = Txt_En;
                    }
                    else
                    {
                        Text_Chat_BTN.Source = Txt_Dis;
                    }
                }
                else if (BType == CButtonType.CallStarted)
                {
                    BitmapImage Call_Started = new BitmapImage(new Uri("/WebConferencingSystem;component/Views/Images/BTNEndCall.png", UriKind.Relative));
                    BitmapImage Call_Ended = new BitmapImage(new Uri("/WebConferencingSystem;component/Views/Images/BTNCall.png", UriKind.Relative));

                    if (Enable)
                    {
                        VoiceCallBTN.Source = Call_Started;
                        Video_Chat_BTN.Visibility = System.Windows.Visibility.Visible;
                        Mute_Chat_BTN.Visibility = System.Windows.Visibility.Visible;
                    }
                    else
                    {
                        VoiceCallBTN.Source = Call_Ended;
                        Video_Chat_BTN.Visibility = System.Windows.Visibility.Collapsed;
                        Mute_Chat_BTN.Visibility = System.Windows.Visibility.Collapsed;
                    }
                }
                else if (BType == CButtonType.SPEAKERS)
                {
                    BitmapImage SPK_En = new BitmapImage(new Uri("/WebConferencingSystem;component/Views/Images/SPK_EN.png", UriKind.Relative));
                    BitmapImage SPK_Dis = new BitmapImage(new Uri("/WebConferencingSystem;component/Views/Images/SPK_Dis.png", UriKind.Relative));

                    if (Enable)
                    {
                        Mute_Chat_BTN.Source = SPK_En;
                    }
                    else
                    {
                        Mute_Chat_BTN.Source = SPK_Dis;
                    }

                }

            }
            catch { }
        }
        private void CloseBTN_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (!CallIsEstablished & !TryingToCall)
                SelectedUserPanel.Visibility = System.Windows.Visibility.Collapsed;
        }
        #endregion Connection Methods

        #region TextClient

        private void SendCMDMessage(string Msg, TXTPayloadType cmd, string SendTO, bool IsPublic)
        {
            if (IsPublic) SendTO = log.RoomID;

            WcsTxtPacket packet = Packetizer.GetObject(SendTO, log.UserName, log.RoomID, Msg, cmd, IsPublic);
            WCSProxy.SendCMDAsync(packet);
        }

        private void SendTextMessage(string TXTMSG, string SendTO, bool IsPublic)
        {
            if (WCSProxy.InnerChannel.State == System.ServiceModel.CommunicationState.Opened)
                try
                {
                    if (TXTMSG.Length > 3)
                    {
                        WcsTxtPacket packet = Packetizer.GetObject(SendTO, log.UserName, log.RoomID, TXTMSG, TXTPayloadType.TxtMsg, IsPublic);
                        WCSProxy.PublishTextAsync(packet);
                        ReceivedTXTData_Analyzer(packet);
                    }
                }
                catch { }
        }

        void OnTextReceived(object sender, OnTextSendReceivedEventArgs e)
        {
            try
            {
                if (e.Error != null)
                {
                    OnlineUsers[PublicKey].TxtChatWindow.ShowErrorMessageBox(e.Error.Message);
                }
                else
                {
                    ReceivedTXTData_Analyzer(e.TxtPacket);
                }
            }
            catch { }
        }

        void ReceivedTXTData_Analyzer(WCS_Proxy.WcsTxtPacket RM)
        {
            try
            {
                switch (RM.PayloadType)
                {
                    case TXTPayloadType.UnSubscribe:
                        {
                            DropFromUsersList(RM.Message);
                        }
                        break;
                    case TXTPayloadType.TxtMsg:
                        {
                            if (RM.IsPublic)
                            {
                                OnlineUsers[PublicKey].TextShared = true;
                                if (!Dashboard.Children.Contains(OnlineUsers[PublicKey].TxtChatWindow))
                                {
                                    Dashboard.Add(OnlineUsers[PublicKey].TxtChatWindow);
                                    OnlineUsers[PublicKey].TxtChatWindow.Show();
                                }
                                OnlineUsers[PublicKey].TxtChatWindow.AddMSGToChatList(RM.UserName, RM.To, RM.Message);
                            }
                            else if (OnlineUsers.ContainsKey(RM.UserName))
                            {
                                OnlineUsers[RM.UserName].TextShared = true;
                                if (!Dashboard.Children.Contains(OnlineUsers[RM.UserName].TxtChatWindow))
                                {
                                    Dashboard.Add(OnlineUsers[RM.UserName].TxtChatWindow);
                                    OnlineUsers[RM.UserName].TxtChatWindow.Show();
                                }
                                OnlineUsers[RM.UserName].TxtChatWindow.RestoreWindow();
                                OnlineUsers[RM.UserName].TxtChatWindow.AddMSGToChatList(RM.UserName, RM.To, RM.Message);
                            }

                            break;
                        }
                    case TXTPayloadType.CCall:
                        {
                            if (!CallIsEstablished & !TryingToCall & !IsRinging)
                                Deployment.Current.Dispatcher.BeginInvoke(() =>
                                {
                                    PickTheCall(RM.UserName);
                                });
                           else SendCMDMessage("CBusy", TXTPayloadType.CBusy, RM.UserName, false);
                        }
                        break;
                    case TXTPayloadType.CAccepted:
                        {
                            // Accepted Call
                            PlayCallingRingin(false);
                            CallEstablished(RM.UserName);
                        }
                        break;
                    case TXTPayloadType.CRejected:
                        {
                            if (SelectedUserName == RM.UserName)
                            {
                                // Rejected Call
                                PlayCallingRingin(false);
                                CallDurationStatusLB.Text = "Call Rejected";
                                CallEnded();
                            }
                        }
                        break;
                    case TXTPayloadType.CEnded:
                        {
                            if (SelectedUserName == RM.UserName)
                            {
                                // Call Ended
                                PlayCallingRingin(false);
                                CallDurationStatusLB.Text = "Call Ended";
                                CallEnded();
                            }
                        }
                        break;
                    case TXTPayloadType.CBusy:
                        {
                            if (SelectedUserName == RM.UserName)
                            {
                                CallDurationStatusLB.Text = "Busy..";
                                PlayCallingRingin(false);
                                CallEnded();
                            }
                        }
                        break;
                }
            }
            catch { }
        }

        void OnSynchronizeUsersList(object sender, OnSyncUsersListReceivedEventArgs e)
        {
            if (e.Error == null)
                try
                {

                    var UsersList = e.UsersList;

                    // Add the online users
                    foreach (KeyValuePair<string, UserInfoPacket> User in UsersList)
                    {
                        AddToUsersList(User.Value);
                    }

                    // Drop the offile users
                    foreach (OnlineUser UserInList in ChattersListbox.Items.ToArray())
                    {
                        if (UserInList.UserName != PublicKey)
                        {
                            if (!UsersList.ContainsKey(UserInList.UserName.ToString()))
                            {
                                DropFromUsersList((UserInList.UserName));
                            }
                        }
                    }
                }
                catch (Exception ex) { OnlineUsers[PublicKey].TxtChatWindow.ShowErrorMessageBox(ex.Message); }
            else OnlineUsers[PublicKey].TxtChatWindow.ShowErrorMessageBox(e.Error.Message);
        }

        private void ChattersListbox_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            try
            {
                if (ChattersListbox.SelectedValue != null)
                {
                    if (!TryingToCall & !CallIsEstablished)
                    {
                        StopTalking();
                        OnlineUser user = (OnlineUser)ChattersListbox.SelectedValue;
                        SelectUser(user);
                    }
                }
            }
            catch{}
        }

        private void SelectUser(OnlineUser user)
        {
            try
            {
                SelectedUserName = SelectedUserNameTxT.Text = user.UserName;
                ChattersListbox.SelectedValue = user;
                SelectedUserImage.Source = user.AvatarIMG.Source;
                CallDurationStatusLB.Text = "";

                if (SelectedUserName == PublicKey)
                {
                    Voice_Chat_BTN.Visibility = System.Windows.Visibility.Visible;
                    VoiceCallBTN.Visibility = System.Windows.Visibility.Collapsed;
                    Video_Chat_BTN.Visibility = System.Windows.Visibility.Collapsed;
                    Mute_Chat_BTN.Visibility = System.Windows.Visibility.Visible;
                }
                else
                {
                    VoiceCallBTN.Visibility = System.Windows.Visibility.Visible;
                    Voice_Chat_BTN.Visibility = System.Windows.Visibility.Collapsed;
                    Mute_Chat_BTN.Visibility = System.Windows.Visibility.Collapsed;
                }

                if (OnlineUsers.ContainsKey(SelectedUserName))
                {
                    EnableChattingControl(CButtonType.TXT, OnlineUsers[SelectedUserName].TextShared);
                    EnableChattingControl(CButtonType.SPEAKERS, OnlineUsers[SelectedUserName].SPEAKERS);
                }


                SelectedUserPanel.Visibility = System.Windows.Visibility.Visible;
            }
            catch { }
        }

        private void AddToUsersList(UserInfoPacket UserInfo)
        {
            try
            {
                if (UserInfo.UserName != WCSServiceName)
                {
                    if (UserInfo.UserName == log.UserName)
                    {
                        UserNameLB.Content = "Welcome, " + UserInfo.UserName;
                    }
                    else if (!OnlineUsers.ContainsKey(UserInfo.UserName))
                    {
                        OnlineUsers[UserInfo.UserName] = new OnlineUser(UserInfo.UserName, false, UserInfo.Role.ToString(), UserInfo.AvatarID);
                        OnlineUsers[UserInfo.UserName].TxtChatWindow = new ChatArea(UserInfo.UserName, log.UserName, log.RoomID, WCSServiceName, false);
                        OnlineUsers[UserInfo.UserName].TxtChatWindow.Position = new Point(10, 200);
                        OnlineUsers[UserInfo.UserName].TxtChatWindow.SendDrawingClicked += new EventHandler(SendDrawingBTN_Click);
                        OnlineUsers[UserInfo.UserName].TxtChatWindow.SendTextClicked += new EventHandler(SendRichBTN_Click);
                        ChattersListbox.Items.Add(OnlineUsers[UserInfo.UserName]);
                    }
                    else if (!ChattersListbox.Items.Contains(OnlineUsers[UserInfo.UserName])) 
                        ChattersListbox.Items.Add(OnlineUsers[UserInfo.UserName]);

                }
            }
            catch { }
        }

        private void DropFromUsersList(string UserName)
        {
            try
            {
                if (OnlineUsers.ContainsKey(UserName))
                {
                    ChattersListbox.Items.Remove(OnlineUsers[UserName]);

                    if (OnlineUsers[UserName].TxtChatWindow!=null) Dashboard.Remove(OnlineUsers[UserName].TxtChatWindow);
                    OnlineUsers.Remove(UserName);
                }

                    if ((CallIsEstablished) && (UserName == SelectedUserName))
                    {
                        CallEnded();
                        SelectUser(OnlineUsers[PublicKey]);
                    }
                    else if (UserName == SelectedUserName) SelectUser(OnlineUsers[PublicKey]);
         
            }
            catch { }
        }

        private void SendRichBTN_Click(object sender, EventArgs e)
        {
            WcsTxtPacket packet = (WcsTxtPacket)sender;
            if (WCSProxy.State == System.ServiceModel.CommunicationState.Opened)
                WCSProxy.PublishTextAsync(packet);
        }

        private void Text_Chat_BTN_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (OnlineUsers.ContainsKey(SelectedUserName))
            {
                OnlineUsers[SelectedUserName].TextShared = !OnlineUsers[SelectedUserName].TextShared;
                EnableChattingControl(CButtonType.TXT, OnlineUsers[SelectedUserName].TextShared);

                if (!Dashboard.Children.Contains(OnlineUsers[SelectedUserName].TxtChatWindow))
                {
                    Dashboard.Add(OnlineUsers[SelectedUserName].TxtChatWindow);
                    OnlineUsers[SelectedUserName].TxtChatWindow.Show();
                }

                if (OnlineUsers[SelectedUserName].TextShared)
                    OnlineUsers[SelectedUserName].TxtChatWindow.RestoreWindow();
                else OnlineUsers[SelectedUserName].TxtChatWindow.MinimizeWindow();

            }

        }

        #endregion TextClient

        #region DrawingClient

        void OnDrawingReceived(object sender, OnDrawingSendReceivedEventArgs e)
        {
            try
            {
                if (e.Error != null)
                {
                    OnlineUsers[PublicKey].TxtChatWindow.ShowErrorMessageBox(e.Error.Message);
                }
                else
                {
                    try
                    {
                        if (e.BinaryPacket.IsPublic)
                        {
                            if (OnlineUsers.ContainsKey(PublicKey))
                            {
                                if (!Dashboard.Children.Contains(OnlineUsers[PublicKey].TxtChatWindow))
                                {
                                    Dashboard.Add(OnlineUsers[PublicKey].TxtChatWindow);
                                    OnlineUsers[PublicKey].TxtChatWindow.Show();
                                    OnlineUsers[PublicKey].TxtChatWindow.RestoreSizeAndPosition();
                                    OnlineUsers[PublicKey].TxtChatWindow.RestoreWindow();
                                }

                                OnlineUsers[PublicKey].TxtChatWindow.DrawingDecoderThread.RunWorkerAsync(e.BinaryPacket);
                            }
                        }

                        else if (OnlineUsers.ContainsKey(e.BinaryPacket.UserName))
                        {

                            if (!Dashboard.Children.Contains(OnlineUsers[e.BinaryPacket.UserName].TxtChatWindow))
                            {
                                Dashboard.Add(OnlineUsers[e.BinaryPacket.UserName].TxtChatWindow);
                                OnlineUsers[e.BinaryPacket.UserName].TxtChatWindow.Show();
                                OnlineUsers[e.BinaryPacket.UserName].TxtChatWindow.RestoreSizeAndPosition();
                                OnlineUsers[e.BinaryPacket.UserName].TxtChatWindow.RestoreWindow();
                            }

                            OnlineUsers[e.BinaryPacket.UserName].TxtChatWindow.DrawingDecoderThread.RunWorkerAsync(e.BinaryPacket);
                        }
                    }
                    catch { }
                }
            }
            catch { }
        }

        private void SendDrawingBTN_Click(object sender, EventArgs e)
        {
            if (WCSProxy.State == System.ServiceModel.CommunicationState.Opened)
                WCSProxy.PublishDrawingAsync((WcsBinaryPacket)sender);
        }

        #endregion DrawingClient

        #region VideoClient

        void WebCamStart(object sender, EventArgs e)
        {
            // Start The Camera
            if (CapturingDevice.AllowUsing & CapturingDevice.HaveCam)
            {
                try
                {
                    localcam.Position = new Point(10, 370);

                    Dashboard.Add(localcam);
                    localcam.Show();
                    localcam.RestoreSizeAndPosition();
                    localcam.RestoreWindow();

                    videoBrush.SetSource(CapturingDevice.Capture_Source);
                    localcam.MyCameraIMG.Fill = videoBrush;
                }
                catch { }
            }
        }

        void WebCamStop(object sender, EventArgs e)
        {
            try
            {
                Dashboard.Remove(localcam);

                CapturingDevice.StopCapturing();
                StopSendingWebCam();
                StopTalking();
            }
            catch { }
        }

        ////////////////////////////// Video Sending and Encoding /////////////////////////////////////////////////////////////////

        void StartSendingWebCam()
        {
            try
            {
                EnableChattingControl(CButtonType.VIDEO, true);
                VideoShared = true;
                VideoSendingTimer.Start();
            }
            catch { }
        }

        void StopSendingWebCam()
        {
            try
            {
                EnableChattingControl(CButtonType.VIDEO, false);
                VideoShared = false;
                VideoSendingTimer.Stop();
            }
            catch { }
        }

        public void Video_Each_Tick(object sender, EventArgs e)
        {
            try
            {
                CapturingDevice.Capture_Source.CaptureImageAsync();

                if (CapturingDevice.FPMS != VideoSendingTimer.Interval.Milliseconds)
                {
                    VideoSendingTimer.Interval = new TimeSpan(0, 0, 0, 0, CapturingDevice.FPMS);
                }
            }
            catch { }
        }

        private void VideoFrameEncoding(object sender, CaptureImageCompletedEventArgs e)
        {
            byte[] buffer = ImageEcoderDecoder.JpegEncode(e.Result.ToImage(), CapturingDevice.ImageQuality, true);

            if (WCSProxy.InnerChannel.State == System.ServiceModel.CommunicationState.Opened)
                if (SelectedUserName != "")
            {
            WCSProxy.PublishVideoAsync(Packetizer.GetObject(SelectedUserName, log.UserName, log.RoomID, buffer, BinaryPayloadType.Video, true, false));
            }
        }

        ////////////////////////////// Video Receiving and Decoding /////////////////////////////////////////////////////////////////

        void OnVideoReceived(object sender, OnVideoSendReceivedEventArgs e)
        {
            try
            {
                if (e.Error != null)
                {
                    OnlineUsers[PublicKey].TxtChatWindow.ShowErrorMessageBox(e.Error.Message);
                }
                else
                {
                    try
                    {
                        WcsBinaryPacket RD = e.BinaryPacket;
                        if (RD.DataBuffer != null)
                        {
                            ReceivedStream rbm = new ReceivedStream();
                            rbm.DataStream = ImageEcoderDecoder.Decoder(RD.DataBuffer, RD.IsCompressed);
                            rbm.SentFrom = RD.UserName;

                            Deployment.Current.Dispatcher.BeginInvoke(() =>
                            {
                                ViewReceivedVideoFrame(rbm);
                            });
                        }
                    }
                    catch { }
                }
            }
            catch { }
        }

        private void ViewReceivedVideoFrame(ReceivedStream RBM)
        {
            try
            {
                if (RBM.DataStream != null)
                {
                    var bi = new BitmapImage();
                    bi.SetSource(RBM.DataStream);

                    if (OnlineUsers.ContainsKey(RBM.SentFrom))
                    {
                       SelectedUserImage.Source = bi;
                       if (IsLargeView) LargeWebCamWindow.ViewReceivedImage(bi);
                    }
                }
            }
            catch { }
        }

        private void Video_Chat_BTN_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (CallIsEstablished)
            {
                if (CapturingDevice.HaveCam)
                    if (!CapturingDevice.AllowUsing)
                    {
                        CapturingDevice.Show();
                    }
                    else
                    {
                        if (!VideoShared)
                            StartSendingWebCam();
                        else StopSendingWebCam();
                    }
            }
        }

        private void RemoteUserWebCam_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ClickCount == 2 & CallIsEstablished)
            {
                LargeWebCamWindow = new FocusedView();
                LargeWebCamWindow.ViewReceivedImage(SelectedUserImage.Source);
                IsLargeView = true;
                LargeWebCamWindow.SetTitle(SelectedUserName);
                LargeWebCamWindow.Show();
                LargeWebCamWindow.Closed += (s, args) =>
                {
                    IsLargeView = false;
                };
            }
        }

        #endregion VideoClient

        #region VoiceClient

        private void VoiceCalling()
        {
            PlayCallingRingin(true);
            TryingToCall = true;
            CallDurationStatusLB.Text = "Calling..";
            SendCMDMessage("CCall", TXTPayloadType.CCall, SelectedUserName, false);
            EnableChattingControl(CButtonType.CallStarted, true);
        }

        private void CallEstablished(string EstablishedWith)
        {
            if (OnlineUsers.ContainsKey(EstablishedWith))
            {

                PlayCallingRingin(false);

                StartCDT();
           
                EnableChattingControl(CButtonType.CallStarted, true);

                if (!CapturingDevice.AllowUsing & CapturingDevice.HaveMic)
                {
                    CapturingDevice.Show();
                    CapturingDevice.Closed += (s, args) =>
                    {
                        if (CapturingDevice.AllowUsing)
                        {
                            StartTalking();
                        }
                    };
                }
                else StartTalking();
            }
        }

        // Call Duration Timer(CDT) 
        System.Windows.Threading.DispatcherTimer CDTTimer = new System.Windows.Threading.DispatcherTimer();
        int Sec = 0;
        int min = 0;
        int hrc = 0;
        public void StartCDT()
        {
            CallIsEstablished = true;

            Sec = 0;
            min = 0;
            hrc = 0;
            CDTTimer = new System.Windows.Threading.DispatcherTimer();
            CDTTimer.Interval = new TimeSpan(0, 0, 0, 0, 1000);
            CDTTimer.Tick += new EventHandler(CDT_Each_Tick);
            CDTTimer.Start();
        }

        public void StopCDT()
        {
            if (CDTTimer != null)
            {
                CDTTimer.Stop();
            }

            StopSendingWebCam();
        }

        public void CDT_Each_Tick(object o, EventArgs sender)
        {
            Sec++;
            if (Sec > 59)
            {
                Sec = 0;
                min++;
            }
            if (min > 59)
                hrc++;
            CallDurationStatusLB.Text = hrc.ToString() + ":" + min.ToString() + ":" + Sec.ToString();
        }

        private void PickTheCall(string CallFrom)
        {

            SelectUser(OnlineUsers[CallFrom]);

            TryingToCall = true;
            IsRinging = true;

            PickCall_Window = new NewCall(CallFrom);

            PickCall_Window.Show();
            PickCall_Window.PlayRingin(true);

            PickCall_Window.Closed += (s, args) =>
            {
                PickedUpOrRejected(PickCall_Window.PickedUp, CallFrom);
            };
        }

        private void PickedUpOrRejected(bool Status, string CallFrom)
        {
            PickCall_Window.PlayRingin(false);
            IsRinging = false;

            if (Status)
            {
                SendCMDMessage("CAccepted", TXTPayloadType.CAccepted, CallFrom, false);
                CallEstablished(CallFrom);
            }
            else
            {
                CallDurationStatusLB.Text = "Call Rejected";
                SendCMDMessage("CRejected", TXTPayloadType.CRejected, CallFrom, false);
            }

            TryingToCall = false;
        }

        private void CallEnded()
        {
            StopCDT();
            StopTalking();

            CallIsEstablished = false;
            TryingToCall = false;

            if (PickCall_Window != null) PickCall_Window.DialogResult = false;
            EnableChattingControl(CButtonType.CallStarted, false);
            PlayCallingRingin(false);
        }

        private void StartTalking()
        {
            try
            {
                if (CapturingDevice.AllowUsing & CapturingDevice.HaveMic & SelectedUserName != "")
                {
                    EnableChattingControl(CButtonType.MIC, true);
                    CapturingDevice.audiSink.IsVoiceSendingStarted = true;
                    VoiceShared = true;
                }
            }
            catch { }
        }

        private void StopTalking()
        {
            
            if (CapturingDevice.audiSink != null)
             CapturingDevice.audiSink.IsVoiceSendingStarted = false;
            EnableChattingControl(CButtonType.MIC, false);
            VoiceShared = false;
            StopSendingWebCam();
        }

        void SendVoiceBuffer(object VoiceBuffer, EventArgs e)
        {
            try
            {
                byte[] EncodedBuffer = (byte[])VoiceBuffer;

                if (CapturingDevice.audiSink != null)
                    if (CapturingDevice.audiSink.IsVoiceSendingStarted & WCSProxy.InnerChannel.State == System.ServiceModel.CommunicationState.Opened & !CapturingDevice.isPlayback)
                {
                    if (SelectedUserName == PublicKey)
                    {

                        WCSProxy.PublishVoiceAsync(Packetizer.GetObject(log.RoomID, log.UserName, log.RoomID, EncodedBuffer, CapturingDevice.BitsPerSample,
                        CapturingDevice.SamplesPerSecond, CapturingDevice.Channels, BinaryPayloadType.Voice, true));
                    }
                    else
                    {
                        WCSProxy.PublishVoiceAsync(Packetizer.GetObject(SelectedUserName, log.UserName, log.RoomID, EncodedBuffer, CapturingDevice.BitsPerSample, 
                         CapturingDevice.SamplesPerSecond, CapturingDevice.Channels, BinaryPayloadType.Voice, false));

                    }

                }
                else if (CapturingDevice.isPlayback)
                {
                    Deployment.Current.Dispatcher.BeginInvoke(() =>
                    {
                        PlayPlaybackBuffer(EncodedBuffer);
                    });
                }
            }
            catch { }
        }

        void InitiateUserVoicePlayback(string FromUserName, int UserBitsPerSample, int UserSamplesPerSecond, int UserChannels)
        {
           if (OnlineUsers.ContainsKey(FromUserName))
           if (OnlineUsers[FromUserName].StreamingMediaSources == null) // If a new user
            {
                try
                {
                    // Initiate a New User Media Source
                    OnlineUsers[FromUserName].StreamingMediaSources = new StreamingMediaSource(UserBitsPerSample, UserSamplesPerSecond, UserChannels);
    
                    // Setup The User MediaElement 
                    OnlineUsers[FromUserName].MediaElement.SetSource(OnlineUsers[FromUserName].StreamingMediaSources);
                    OnlineUsers[FromUserName].MediaElement.Volume = 1.0;
                    OnlineUsers[FromUserName].MediaElement.AutoPlay = true;
                }
                catch { }
            }
            else
            {
                try
                {
                    // Update Voice Format if Changed.
                    OnlineUsers[FromUserName].StreamingMediaSources.UpdateVoiceFormat(UserBitsPerSample, UserSamplesPerSecond, UserChannels);
                }
                catch { }
            }
        }

        void OnVoiceReceived(object sender, OnVoiceSendReceivedEventArgs e)
        {
            try
            {
                if (e.Error != null)
                {
                    OnlineUsers[PublicKey].TxtChatWindow.ShowErrorMessageBox(e.Error.Message);
                }
                else
                {
                    QueueVoiceReceivedBuffer(e.AudioPacket);
                }
            }
            catch { }
        }

        private void PlayPlaybackBuffer(byte[] ByteFullBuffer)
        {
            try
            {
                if (CapturingDevice.PlaybackTestSMSource == null)
                {
                    CapturingDevice.PlaybackTestSMSource = new StreamingMediaSource(CapturingDevice.BitsPerSample, CapturingDevice.SamplesPerSecond, CapturingDevice.Channels);
                    CapturingDevice.PlaybackTestME.SetSource(CapturingDevice.PlaybackTestSMSource);
                    CapturingDevice.PlaybackTestME.Volume = 1.0;
                    CapturingDevice.PlaybackTestME.AutoPlay = true;
                }
                else CapturingDevice.PlaybackTestSMSource.PushBufferToQueue(ByteFullBuffer);
            }
            catch { }
        }

        private void QueueVoiceReceivedBuffer(WcsAudioPacket RD)
        {
            if (RD.DataBuffer != null)
            try
            {
                bool SpeakersOn = true;

                if (RD.IsPublic) SpeakersOn = OnlineUsers[PublicKey].SPEAKERS;
                     else if (OnlineUsers.ContainsKey(RD.UserName)) SpeakersOn = OnlineUsers[RD.UserName].SPEAKERS;

                    if (RD.DataBuffer.Length > 0 & SpeakersOn)
                    {
                        InitiateUserVoicePlayback(RD.UserName, RD.AudioFormatBits, RD.AudioFormatSamples, RD.AudioFormatChannels);
                        OnlineUsers[RD.UserName].StreamingMediaSources.PushBufferToQueue(RD.DataBuffer);
                    }
            }
            catch { }
        }

        private void DevicesSettings_BTN_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            CapturingDevice.Show();
        }

        void PlayCallingRingin(bool value)
        {
            try
            {
                if (value)
                {
                    var RingingStream = Application.GetResourceStream(new Uri("Sounds/Calling.wav", UriKind.RelativeOrAbsolute));

                    if (RingingStream != null)
                    {
                        Microsoft.Xna.Framework.Audio.SoundEffect Ringing = Microsoft.Xna.Framework.Audio.SoundEffect.FromStream(RingingStream.Stream);
                        Ringinginstance = Ringing.CreateInstance();
                        Ringinginstance.IsLooped = true;
                        Ringinginstance.Play();
                    }
                }
                else if (!value & Ringinginstance != null)
                    Ringinginstance.Stop();
            }
            catch { }
        }

        private void VoiceCallBTN_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {

            if (!TryingToCall & !CallIsEstablished)
            {
                if (!CapturingDevice.AllowUsing)
                {
                    CapturingDevice.Show();
                }
                else if (CapturingDevice.HaveMic) VoiceCalling();
            }
            else
            {
                SendCMDMessage("CEnded", TXTPayloadType.CEnded, SelectedUserName, false);
                CallDurationStatusLB.Text = "Call Ended";
                CallEnded();
            }

        }

        private void Voice_Chat_BTN_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (!CallIsEstablished & !TryingToCall)
            {
                if (!CapturingDevice.AllowUsing)
                {
                    CapturingDevice.Show();
                }
                else
                {
                    if (!VoiceShared)
                        StartTalking();
                    else StopTalking();

                }
            }
        }

        private void Mute_Chat_BTN_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (OnlineUsers.ContainsKey(SelectedUserName))
            {
                OnlineUsers[SelectedUserName].SPEAKERS = !OnlineUsers[SelectedUserName].SPEAKERS;
                EnableChattingControl(CButtonType.SPEAKERS, OnlineUsers[SelectedUserName].SPEAKERS);
            }
        }

        #endregion VoiceClient
          
    }
}
