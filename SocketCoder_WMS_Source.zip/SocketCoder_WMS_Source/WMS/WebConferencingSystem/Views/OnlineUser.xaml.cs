﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Shapes;
using MediaStreaming;
using System.Windows.Media.Imaging;

namespace WebConferencingSystem.Views
{
    public partial class OnlineUser : UserControl
    {
        public enum CButtonType { TXT, MIC, VIDEO, Files, UserCamWindow, WhiteBoard, PresentationsViewer, SPEAKERS };

        public MediaElement MediaElement = new MediaElement();
        public ChatArea TxtChatWindow; 
        public StreamingMediaSource StreamingMediaSources;
        public event EventHandler ViewLargeCamClicked;

        public bool IsPublicChat { get; set; }
        public string UserName { get; set; }
        public string AvatarID { get; set; }

        public bool TextShared = true;
        public bool SPEAKERS = true;


        public OnlineUser(string User_Name,bool IsAllUsers,string User_Role,string Avatar_ID)
        {
            InitializeComponent();

            this.UserNameTXT.Text = UserName = User_Name;
            
            IsPublicChat = IsAllUsers;
            AvatarID = Avatar_ID;
            SetAvatarIMG();

            if (IsAllUsers) TextShared = true;
            else TextShared = false;
        }

        private void SetAvatarIMG()
        {
            try
            {
                if (AvatarID.Length > 0)
                 AvatarIMG.Source = new BitmapImage(new Uri("/WebConferencingSystem;component/Views/Avatars/" + AvatarID + ".png", UriKind.Relative));
                else
                 AvatarIMG.Source = new BitmapImage(new Uri("/WebConferencingSystem;component/Views/Avatars/00000.png", UriKind.Relative));
            }
            catch {}
        }

       private void RemoteCam_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (!IsPublicChat)
            if (e.ClickCount == 2)
            {
                if (ViewLargeCamClicked !=null)
                ViewLargeCamClicked(UserName, null);
            }
        }

    }
}
