﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.IO;
using System.Windows.Media.Imaging;
using ImageTools.IO.Jpeg;
using ImageTools;

namespace WebConferencingSystem.Views
{
    public partial class FocusedView : ChildWindow
    {

        public FocusedView()
        {
            InitializeComponent();
        }
        public void SetTitle(string _Title)
        {
            this.Title = _Title + " - Double Click to Save The Current Image";
        }
        public void ViewReceivedImage(BitmapImage RImag)
        {
            UserCam.Source = RImag;
        }

        public void ViewReceivedImage(ImageSource RImag)
        {
            UserCam.Source = RImag;
        }

        private void OKButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = true;
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }

        private void UserCam_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ClickCount == 2)
            {
                try
                {
                    SaveFileDialog saveFileDlg = new SaveFileDialog();
                    ImageTools.IO.Jpeg.JpegEncoder EncodeJpeg = new ImageTools.IO.Jpeg.JpegEncoder();
                    saveFileDlg.DefaultFileName = "Captured " + DateTime.Now.ToFileTime().ToString();
                    saveFileDlg.Filter = "JPEG Files (*.jpg)|*.jpg";
                    saveFileDlg.DefaultExt = ".jpg";

                    if (saveFileDlg.ShowDialog().Value)
                    {
                        using (Stream dstStream = saveFileDlg.OpenFile())
                        {
                            WriteableBitmap bmp = new WriteableBitmap(UserCam, null);
                            EncodeJpeg.Encode(bmp.ToImage(), dstStream);
                        }
                    }
                }
                catch { }
            }
        }

        private void ChildWindow_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            DialogResult = true;
        }
    }
}

