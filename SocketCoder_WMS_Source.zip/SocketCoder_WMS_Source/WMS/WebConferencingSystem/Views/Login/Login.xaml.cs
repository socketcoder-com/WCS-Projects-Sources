﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Browser;

namespace WebConferencingSystem.Views.Login
{
    public partial class Login : ChildWindow
    {

        public Login()
        {
            InitializeComponent();

            if (App.Current.IsRunningOutOfBrowser)
            {
                JoinToPrivate.Visibility = System.Windows.Visibility.Visible;
                ShowGenerator.Visibility = System.Windows.Visibility.Collapsed;
            }
            else
            {
                JoinToPrivate.Visibility = System.Windows.Visibility.Collapsed;
            }
        }

        public string UserName = "";
        public string RoomID = "";
        private Random rnd = new Random(4);
        public bool Isvalid()
        {
            if ((UserName.Trim().Length > 0) & (RoomID.Trim().Length > 0) & (UserName != "*All Users*"))
            {
                if (UserName.Length > 16) UserName = UserName.Substring(0, 16);
                if (RoomID.Length > 16) RoomID = RoomID.Substring(0, 16);

                if (UserName == RoomID) UserName = rnd.Next(10) + "@" + UserName;

                // Replace any not allowed character, For Example:
                    UserName = UserName.Replace('`', '*');
                    UserName = UserName.Replace('#', '*');
                    RoomID = RoomID.Replace('`', '*');
                    RoomID = RoomID.Replace('#', '*');

                //--------------------------*
                // You can add here any other Conditions for the login here
                //--------------------------*

                return true;
            }
            else return false;
        }
        private void JoinBTN_Click(object sender, RoutedEventArgs e)
        {
            if (LoginLayout.Visibility == System.Windows.Visibility.Visible)
                try
                {
                    UserName = NickNameTextBox.Text;

                    ComboBoxItem Selected = (ComboBoxItem)RoomsCombo.SelectedValue;
                    RoomID = Selected.Content.ToString();

                    if (Isvalid())
                    {
                        ErrorMSG.Content = "";
                        this.DialogResult = true;
                    }
                    else
                    {
                        ShowMessageBox("Please Write Your Nickname Correctly!");
                        NickNameTextBox.Focus();
                    }
                }
                catch { }
            else
            {
                UserName = UserNameTXT.Text;

                if (Isvalid())
                {
                    this.DialogResult = true;
                }
            }
        }

        private void ShowMessageBox(string MSG)
        {
            ErrorMSG.Content = MSG;
        }
        private void ChildWindow_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (!Isvalid()) e.Cancel = true;
        }

        void ShowLogin(bool value)
        {
            if (value)
            {
                JoinLayout.Visibility = System.Windows.Visibility.Collapsed;
                GeneratorLayout.Visibility = System.Windows.Visibility.Collapsed;
                LoginLayout.Visibility = System.Windows.Visibility.Visible;
                JointoPrivateLayout.Visibility = System.Windows.Visibility.Collapsed;
            }
            else
            {
                JoinLayout.Visibility = System.Windows.Visibility.Visible;
                GeneratorLayout.Visibility = System.Windows.Visibility.Collapsed;
                LoginLayout.Visibility = System.Windows.Visibility.Collapsed;
                JointoPrivateLayout.Visibility = System.Windows.Visibility.Collapsed;

            }
        }

        private void ChildWindow_Loaded(object sender, RoutedEventArgs e)
        {
            // Get From Login Or QueryString
            try
            {
             if (HtmlPage.Document.QueryString.ContainsKey("id"))
                {
                    if (HtmlPage.Document.QueryString["id"] != "")
                    {
                       
                        RoomID = HtmlPage.Document.QueryString["id"];

                        if (HtmlPage.Document.QueryString.ContainsKey("UserName"))
                            UserNameTXT.Text = HtmlPage.Document.QueryString["UserName"];

                        else
                        {
                            string Rand = DateTime.Now.ToFileTime().ToString();
                            UserNameTXT.Text = "User" + Rand.Substring(Rand.Length -4, 3);
                        }
                        UserName = UserNameTXT.Text;
                        RoomIdLB.Content = "RoomID: " + RoomID;

                        ShowLogin(false);

                    }
                    else ShowLogin(true);

                }
                else ShowLogin(true);
            }
            catch { ShowLogin(true); }
        }

        public string base64Encode(string data)
        {
            try
            {
                byte[] encData_byte = new byte[data.Length];
                encData_byte = System.Text.Encoding.UTF8.GetBytes(data);
                string encodedData = Convert.ToBase64String(encData_byte);
                return encodedData;
            }
            catch
            {
                return "";
            }
        }
        
        private void GenerateBTN_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string rndstring = rnd.Next().ToString();
                string GetTime = DateTime.Now.ToFileTime().ToString();

                string id = GetTime.Substring(GetTime.Length - 4, 4) + rndstring;

                string URL = System.Windows.Browser.HtmlPage.Document.DocumentUri.ToString();
                if (URL.Contains("#"))
                    URL = URL.Substring(0, URL.IndexOf("#"));

                id = base64Encode(id).Trim('=');
                if (id.Length > 16) id = id.Substring(0, 14);

                InvitationURLTXT.Text = URL + "?id=" + id;

                Roomhyperlink.NavigateUri = new Uri(InvitationURLTXT.Text);
            }
            catch { ShowLogin(true); }
        }

        private void ShowGenerator_Click(object sender, RoutedEventArgs e)
        {
            ErrorMSG.Content = "";
            LoginLayout.Visibility = System.Windows.Visibility.Collapsed;
            GeneratorLayout.Visibility = System.Windows.Visibility.Visible;
        }

        private void JoinToPrivate_Click(object sender, RoutedEventArgs e)
        {
            LoginLayout.Visibility = System.Windows.Visibility.Collapsed;
            JointoPrivateLayout.Visibility = System.Windows.Visibility.Visible;
        }

        private void JoinToPrivateBtn_Click(object sender, RoutedEventArgs e)
        {
            if (PrivateRoomID_TXT.Text.Trim().Length > 0)
            try
            {
                RoomID = PrivateRoomID_TXT.Text;
                string Rand = DateTime.Now.ToFileTime().ToString();
                UserNameTXT.Text = "User" + Rand.Substring(Rand.Length - 4, 3);
                UserName = UserNameTXT.Text;
                RoomIdLB.Content = "RoomID: " + RoomID;
                JointoPrivateLayout.Visibility = System.Windows.Visibility.Collapsed;
                JoinLayout.Visibility = System.Windows.Visibility.Visible;
            }
            catch { }
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            ShowLogin(true);
        }


    }
}

