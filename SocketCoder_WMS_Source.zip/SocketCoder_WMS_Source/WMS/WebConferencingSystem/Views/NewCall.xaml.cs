﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace WebConferencingSystem.Views
{
    public partial class NewCall : ChildWindow
    {
        Microsoft.Xna.Framework.Audio.SoundEffectInstance Ringinginstance;

        public void PlayRingin(bool value)
        {
            try
            {
                if (value)
                {
                    var RingingStream = Application.GetResourceStream(new Uri("Sounds/Ringing.wav", UriKind.RelativeOrAbsolute));
                    if (RingingStream != null)
                    {
                        Microsoft.Xna.Framework.Audio.SoundEffect Ringing = Microsoft.Xna.Framework.Audio.SoundEffect.FromStream(RingingStream.Stream);
                        Ringinginstance = Ringing.CreateInstance();
                        Ringinginstance.IsLooped = true;
                        Ringinginstance.Play();
                    }
                }
                else if (!value & Ringinginstance != null)
                    Ringinginstance.Stop();
            }
            catch { }
        }

        public NewCall(string CallFrom)
        {
            InitializeComponent();

            CallFromLB.Content = "A new call from "  +  CallFrom;
        }

        public bool PickedUp = false;

        private void OKButton_Click(object sender, MouseButtonEventArgs e)
        {
            PickedUp = true;
            this.DialogResult = true;
        }

        private void CancelButton_Click(object sender, MouseButtonEventArgs e)
        {
            PickedUp = false;
            this.DialogResult = false;
        }
    }
}

