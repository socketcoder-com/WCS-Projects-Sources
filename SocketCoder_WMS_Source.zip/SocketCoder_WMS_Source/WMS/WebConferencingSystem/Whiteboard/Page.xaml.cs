﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.ComponentModel;
using System.Windows.Controls.Primitives;
using System.Windows.Browser;
using System.Windows.Markup;
using System.Runtime.Serialization.Json;
using System.IO;
using System.Globalization;
using System.Text;
using System.Collections.ObjectModel;
using System.Windows.Media.Imaging;
using ImageTools;
using ImageTools.IO.Jpeg;
using ImageTools.IO.Png;

namespace Whiteboard.Client
{
    public class SenderSyncDrawing
    {
        public byte[] Data_Buffer;
        public string DataType;
    }

    public partial class Page : UserControl
    {

        #region Private
        bool drawing = false;
        DrawingArea drawArea;
        #endregion
        public event EventHandler OnDrawingToSend; 
        public event EventHandler OnDrawingSendClicked;
        public JpegEncoder Jpgencod = new JpegEncoder();
        public PngEncoder Pngencod = new PngEncoder();
        private bool IsPresenter { get; set; }
        public bool AllowUsingWB = false;
        public bool IsCollaborative = false;


        #region Ctor and Methods

        public Page()
        {
            InitializeComponent();
           
            drawArea = new DrawingArea(this.DrawingCanvas);
            drawArea.Tool = CurrentTool.Pencil;
            drawArea.StrokeColor = new SolidColorBrush(Colors.Red);
            drawArea.FillColor = new SolidColorBrush(Colors.Yellow);
            drawArea.StrokeWidth = 5;
            this.DataContext = drawArea;

            drawArea.DataAdded += (data) =>
            {
                OnDrawingSycData(data, "Shape");
            };
        }

        /// <summary>
        /// Initialize the connection
        /// </summary>

        private void OnDrawingSycData(string data, string ControlData)
        {
            if (IsCollaborative & IsPresenter & AllowUsingWB)
            try
            {
                SenderSyncDrawing dataToSend = new SenderSyncDrawing();
                dataToSend.Data_Buffer = QuickLZSharp.QuickLZ.compress(System.Text.UTF8Encoding.UTF8.GetBytes(data));
                dataToSend.DataType = ControlData;
                if (OnDrawingToSend != null)
                    OnDrawingToSend(dataToSend, null);
            }
            catch { }
        }

        public void SetReceivedDrawing(byte[] CompressedBuffer, string dataType)
        {
            try
            {
                if (IsCollaborative)
                {
                    byte[] DecodeBytes = QuickLZSharp.QuickLZ.decompress(CompressedBuffer);

                    if (dataType == "Shape")
                    {
                        string decodedTxt = System.Text.UTF8Encoding.UTF8.GetString(DecodeBytes, 0, DecodeBytes.Length);

                        drawArea.AddObjects(decodedTxt);
                    }
                    else if (dataType == "Image")
                    {
                        LoadImageToDrawingCanvas(DecodeBytes);
                    }
                    else if (dataType == "New")
                    {
                        Clear(false);
                    }
                    else if (dataType == "Undo")
                    {
                        UndoAction(false);
                    }
                    else if (dataType == "BackgroundColor")
                    {
                        string SelectedColor = System.Text.UTF8Encoding.UTF8.GetString(DecodeBytes, 0, DecodeBytes.Length);

                        switch (SelectedColor)
                        {
                            case "0":
                                {
                                    DrawingCanvas.Background = new SolidColorBrush(Colors.White);
                                }
                                break;
                            case "1":
                                {
                                    DrawingCanvas.Background = new SolidColorBrush(Colors.Yellow);
                                }
                                break;
                            case "2":
                                {
                                    DrawingCanvas.Background = new SolidColorBrush(Colors.Black);
                                }
                                break;
                            case "3":
                                {
                                    DrawingCanvas.Background = new SolidColorBrush(Colors.Green);
                                }
                                break;
                        }
                    }
                }
            }
            catch { }
        }

        public void Clear(bool SyncIt)
        {
            drawArea.MessageCollection.Clear();
            this.DrawingCanvas.Children.Clear();

            if (IsCollaborative)
            {
                DrawingCanvas.Height = 475;
                DrawingCanvas.Width = 780;
            }
            else
            {
                DrawingCanvas.Height = 155;
                DrawingCanvas.Width = 583;

            }

            if (SyncIt)
            {
                OnDrawingSycData("New", "New");
            }
       }

        #endregion

        #region Events

        private void ButtonSelect_Click(object sender, RoutedEventArgs e)
        {
            this.ColorPanel.Visibility = Visibility.Collapsed;
        }

        private void ButtonSave_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                WriteableBitmap bitmap = new WriteableBitmap(DrawingCanvas, null);

                if (bitmap != null)
                {
                    SaveFileDialog saveDlg = new SaveFileDialog();
                    saveDlg.DefaultFileName = "Drawing " + DateTime.Now.ToFileTime().ToString();
                    saveDlg.Filter = "Png Image (*.png)|*.png";
                    saveDlg.DefaultExt = ".png";
                    if ((bool)saveDlg.ShowDialog())
                    {
                        using (Stream fs = saveDlg.OpenFile())
                        {
                            SaveToStream(bitmap, fs, saveDlg.DefaultExt);
                        }
                    }
                }
            }
            catch { }

        }
        public WriteableBitmap Read_WB()
        {
            try
            {
                WriteableBitmap bitmap = new WriteableBitmap(DrawingCanvas, null);
                return bitmap;
            }
            catch { return new WriteableBitmap(null); }
        }

        private void SaveToStream(WriteableBitmap bitmap, Stream fs,string ImageType)
        {
            try
            {
                if (ImageType == "jpg")
                {
                    MemoryStream stream = new MemoryStream();
                    Jpgencod.Quality = 70;
                    Jpgencod.Encode(bitmap.ToImage(), stream);
                    byte[] binaryData = stream.GetBuffer();
                    fs.Write(binaryData, 0, binaryData.Length);
                }
                if (ImageType == "png")
                {
                    MemoryStream stream = new MemoryStream();
                    Pngencod.Encode(bitmap.ToImage(), stream);
                    byte[] binaryData = stream.GetBuffer();
                    fs.Write(binaryData, 0, binaryData.Length);
                }

            }
            catch { }
        }

        private void ButtonTool_Click(object sender, RoutedEventArgs e)
        {

            var btn = sender as Button;

            if (btn != null && btn.Tag is string)
            {
                drawArea.Tool = (CurrentTool)Enum.Parse(typeof(CurrentTool), btn.Tag as string, true);
            }
        }

        private void ButtonClear_Click(object sender, RoutedEventArgs e)
        {
            Clear(true);
        }

        private void DrawingCanvas_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (AllowUsingWB)
            {
                drawArea.PrevPoint = e.GetPosition(this.DrawingCanvas);
                drawArea.StartPoint = drawArea.PrevPoint;
                drawArea.TempHolder.Clear();

                if (drawing)
                    drawing = false;
                else
                {
                    drawing = true;
                    var cupt = e.GetPosition(this.DrawingCanvas);
                    e.Handled = true;
                }
            }
        }

        private void DrawingCanvas_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (AllowUsingWB)
            {
                drawing = false;
                var cupt = e.GetPosition(this.DrawingCanvas);
                drawArea.HideVirtualLine();
                cupt = drawArea.DrawOnComplete(cupt);
            }
        }

        private void DrawingCanvas_MouseMove(object sender, MouseEventArgs e)
        {
            if (AllowUsingWB)
            {
                if (drawing && drawArea.PrevPoint != null)
                {
                    var cupt = e.GetPosition(this.DrawingCanvas);
                    cupt = drawArea.DrawOnMove(cupt);
                }
            }
        }

        private void ButtonColor_Click(object sender, MouseButtonEventArgs e)
        {
            if (sender is Canvas)
            {
                this.ColorPanel.Visibility = Visibility.Visible;
                ColorPanel.Tag = sender;
                ColorPicker.ColorChanged += (s, c) =>
                {
                    (ColorPanel.Tag as Canvas).Background = c.newColor;
                };
            }
        }
        #endregion

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Clear(true);
        }

        private void Clear_Click(object sender, RoutedEventArgs e)
        {
            Clear(true);
        }

        private void LoadImg_Click(object sender, RoutedEventArgs e)
        {
            if (AllowUsingWB)
            try
            {
                OpenFileDialog imgOpenFileDialog = new OpenFileDialog { Filter = "Images (Jpg,Png)|*.jpg;*.png" };
                
                if (imgOpenFileDialog.ShowDialog() == true)
                {
                    WriteableBitmap bm = null;

                    if (!imgOpenFileDialog.File.Name.Equals(string.Empty))
                    {
                        FileStream stream = imgOpenFileDialog.File.OpenRead();
                        bm = new WriteableBitmap((int)DrawingCanvas.Width, (int)DrawingCanvas.Height);
                        bm.SetSource(stream);

                        MemoryStream EncodedStream = new MemoryStream();
                        Jpgencod.Quality = 50;
                        Jpgencod.Encode(Resize(bm, (int)DrawingCanvas.Width, (int)DrawingCanvas.Height), EncodedStream);

                        LoadImageToDrawingCanvas(EncodedStream.GetBuffer());

                        if (IsPresenter & IsCollaborative)
                        {
                            SenderSyncDrawing dataToSend = new SenderSyncDrawing();
                            dataToSend.Data_Buffer = QuickLZSharp.QuickLZ.compress(EncodedStream.GetBuffer());
                            dataToSend.DataType = "Image";

                            if (OnDrawingToSend != null)
                                OnDrawingToSend(dataToSend, null);
                        }

                    }
                }
            }
            catch { }
        }

        public static ExtendedImage Resize(WriteableBitmap bmp, int ImgWidth, int ImgHeight)
        {
            try
            {
                return ExtendedImage.Resize(bmp.ToImage(), ImgWidth, ImgHeight, new ImageTools.Filtering.NearestNeighborResizer());
            }
            catch { return null; }
        }

        public void LoadImageToDrawingCanvas(byte[] buffer)
        {
            try
            {
                BitmapImage bm = new BitmapImage();
                bm.SetSource(new MemoryStream(buffer));
                DrawingCanvas.LoadFromBitmapImage(bm);
            }
            catch { }
        }
       
        public void SetIsCollaborative(bool IsPresenter)
        {
            try
            {
                SendDrawingBTN.Visibility = System.Windows.Visibility.Collapsed;
                this.IsCollaborative = true;
                this.IsPresenter = IsPresenter;
            }
            catch { }
        }

        private void SendDrawingBTN_Click(object sender, RoutedEventArgs e)
        {
            if (OnDrawingSendClicked != null)
               OnDrawingSendClicked(sender, e);
              Clear(false);
        }

        private void cmbBackGroundColor_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            if (cmbBackGroundColor != null)
            {
               int SelectedColor = cmbBackGroundColor.SelectedIndex;

                 switch (SelectedColor)
                {
                    case 0:
                        {
                            DrawingCanvas.Background = new SolidColorBrush(Colors.White);
                        }
                        break;
                    case 1:
                        {
                            DrawingCanvas.Background = new SolidColorBrush(Colors.Yellow);
                        }
                        break;
                    case 2:
                        {
                            DrawingCanvas.Background = new SolidColorBrush(Colors.Black);
                        }
                        break;
                    case 3:
                        {
                            DrawingCanvas.Background = new SolidColorBrush(Colors.Green);
                        }
                        break;
                }
 
                 OnDrawingSycData(SelectedColor.ToString(),"BackgroundColor");
            }
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {

            if (IsCollaborative)
            {
                DrawingCanvas.Height = 475;
                DrawingCanvas.Width = 780;
            }
            else
            {
                DrawingCanvas.Height = 155;
                DrawingCanvas.Width = 583;
                
            }
    
        }

        void UndoAction(bool SyncIt)
        {
            try
            {
                int num = DrawingCanvas.Children.Count();

                if (num >= 1)
                    DrawingCanvas.Children.RemoveAt(num-1);
                else if (num == 0) Clear(false);

                if (SyncIt)
                    OnDrawingSycData("Undo", "Undo");
            }
            catch { }
        }

        private void Undo_Click(object sender, RoutedEventArgs e)
        {
            UndoAction(true);
        }

    }
}
